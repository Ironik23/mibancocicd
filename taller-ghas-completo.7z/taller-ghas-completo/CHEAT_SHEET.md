# 📋 CHEAT SHEET - Taller 7 GHAS

Comandos y referencias rápidas para el taller

## 🚀 Setup Rápido

```powershell
# Activar entorno
.\venv\Scripts\Activate.ps1

# Validar setup
python scripts/validate-setup.py

# Abrir guía (elegir una)
code GUIA_EJECUCION_GHAS_QE.md  # Para QE
code GUIA_EJECUCION_GHAS_DS.md  # Para DS
```

## 💬 GitHub Copilot

| Acción | Atajo |
|--------|-------|
| Abrir Chat | `Ctrl + Shift + I` |
| Inline Chat | `Ctrl + I` |
| Sugerencias múltiples | `Ctrl + Enter` |
| Aceptar sugerencia | `Tab` |
| Siguiente sugerencia | `Alt + ]` |
| Sugerencia anterior | `Alt + [` |

## 🔍 CodeQL

```powershell
# Ver workflow
code .github/workflows/codeql-analysis.yml

# Ver custom queries
ls .codeql/custom-queries/

# Ver resultados en GitHub
# GitHub.com → Tu Repo → Security → Code scanning
```

## 📦 Dependabot

```powershell
# Ver configuración
code .github/dependabot.yml

# Ver alertas en GitHub
# GitHub.com → Tu Repo → Security → Dependabot alerts
```

## 🐍 Scripts Útiles

```powershell
# Validar setup
python scripts/validate-setup.py

# Detectar bias en modelo
python scripts/detect-model-bias.py --model models/sample_model.pkl --data examples/python/test_data.csv

# Limpiar secrets de notebooks
python scripts/clean-notebook-secrets.py examples/python/vulnerable_ml_notebook.ipynb

# Validar dependencias
python scripts/validate-ml-dependencies.py
```

## 📓 Jupyter Notebooks

```powershell
# Iniciar Jupyter
jupyter notebook

# Abrir notebook específico
jupyter notebook examples/python/vulnerable_ml_notebook.ipynb

# Listar kernels
jupyter kernelspec list

# Instalar kernel del venv
python -m ipykernel install --user --name=venv
```

## 🧪 Tests

```powershell
# Ejecutar todos los tests
pytest

# Ejecutar tests específicos
pytest tests/test_secure_pickle.py

# Ejecutar con coverage
pytest --cov=src --cov-report=html
```

## 📊 Pre-commit Hooks

```powershell
# Instalar hooks
pre-commit install

# Ejecutar manualmente
pre-commit run --all-files

# Ejecutar hook específico
pre-commit run black --all-files
```

## 🔐 Security Tools

```powershell
# Bandit - Security linter
bandit -r src/ scripts/

# Safety - Check vulnerabilities
safety check

# Pip-audit - Audit dependencies
pip-audit
```

## 📁 Estructura Rápida

```
taller-ghas-completo/
├── labs/               # 6 laboratorios
├── examples/           # Código vulnerable
├── scripts/            # Scripts automatización
├── src/
│   ├── vulnerable/     # Código con bugs
│   └── secure/         # Código corregido
├── tests/              # Tests
└── .github/workflows/  # GitHub Actions
```

## 🎯 Labs QE

```powershell
cd labs/lab-1-codeql          # CodeQL (20 min)
cd labs/lab-2-dependabot      # Dependabot (20 min)
cd labs/lab-3-policies        # Policies (15 min)
cd labs/lab-4-overview        # Dashboard (15 min)
cd labs/lab-5-remediation     # Fixes (20 min)
cd labs/lab-6-queries         # Custom (30 min)
```

## 🤖 Módulos DS

| Módulo | Tema | Tiempo |
|--------|------|--------|
| 1 | ML Security | 15 min |
| 2 | CodeQL DS | 25 min |
| 3 | Dependencies | 20 min |
| 4 | Bias & Fairness | 30 min |
| 5 | Secrets | 15 min |
| 6 | ML Pipeline | 15 min |

## 🔑 Prompts PACES

Ver `LIBRERIA_PROMPTS_GHAS.md` para 30+ prompts

Estructura PACES:
- **P**ropósito: Qué quieres lograr
- **A**udiencia: Para quién
- **C**ontexto: Situación actual
- **E**jemplos: Casos específicos
- **S**cope: Alcance esperado

## 🐛 Troubleshooting

| Problema | Solución |
|----------|----------|
| pip install falla | Ver `INSTALLATION_GUIDE.md` |
| PowerShell policy | `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` |
| Jupyter no abre | `pip install --upgrade jupyter notebook` |
| CodeQL sin resultados | Push código a GitHub primero |
| Import errors | Verificar venv activado |

## 📚 Documentación

| Archivo | Contenido |
|---------|-----------|
| `README.md` | Información general |
| `GETTING_STARTED.md` | Setup inicial |
| `GUIA_EJECUCION_GHAS_QE.md` | Guía completa QE |
| `GUIA_EJECUCION_GHAS_DS.md` | Guía completa DS |
| `LIBRERIA_PROMPTS_GHAS.md` | Prompts listos |
| `EJEMPLOS_GHAS_CODIGO.md` | Código ejecutable |

## 🔗 Links Rápidos

- [GitHub GHAS Docs](https://docs.github.com/en/code-security)
- [CodeQL Docs](https://codeql.github.com/docs/)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Fairness ML](https://fairmlbook.org/)

## ✅ Checklist Rápida

**Antes de cada lab:**
- [ ] Venv activado
- [ ] En la carpeta correcta
- [ ] README del lab abierto
- [ ] Copilot Chat listo

**Después de cada lab:**
- [ ] Objetivos cumplidos
- [ ] Código commiteado
- [ ] Tests pasando
- [ ] Notas documentadas

## 🎯 Objetivos por Audiencia

### QE - Al finalizar tendrás:
- ✅ CodeQL detectando 10+ vulnerabilidades
- ✅ Dependabot auto-merging security patches
- ✅ Branch policies configuradas
- ✅ Security dashboard activo
- ✅ Custom queries funcionando
- ✅ CI/CD con security gates

### DS - Al finalizar tendrás:
- ✅ Pipeline ML con 6 stages
- ✅ Bias detection implementado
- ✅ SHAP explainability
- ✅ Secrets protegidos
- ✅ Dependencies validadas
- ✅ Fairness metrics > 0.8

---

**Tip:** Imprime esta página para tenerla a mano durante el taller 📄
