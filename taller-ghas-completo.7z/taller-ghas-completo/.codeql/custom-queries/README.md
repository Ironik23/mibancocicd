# Custom CodeQL Queries para MI Banco

Esta carpeta contiene queries personalizadas de CodeQL específicas para detectar vulnerabilidades en aplicaciones bancarias y sistemas de Machine Learning.

## 📋 Queries Disponibles

### 1. python-hardcoded-credentials.ql
**Detecta:** Credenciales hardcodeadas en el código (passwords, API keys, tokens)

**Severidad:** 🔴 Error (8.0/10)

**CWE:** CWE-798 (Use of Hard-coded Credentials)

**Ejemplo detectado:**
```python
DB_PASSWORD = "Admin123!"  # ❌ Detectado
API_KEY = "sk-1234567890abcdef"  # ❌ Detectado
```

**Remediación:**
```python
import os
DB_PASSWORD = os.getenv("DB_PASSWORD")  # ✅ Correcto
API_KEY = os.getenv("API_KEY")  # ✅ Correcto
```

---

### 2. python-sql-injection.ql
**Detecta:** Construcción de queries SQL con input del usuario sin sanitizar

**Severidad:** 🔴 Error (9.0/10)

**CWE:** CWE-089 (SQL Injection)

**Ejemplo detectado:**
```python
query = f"SELECT * FROM users WHERE id = '{user_id}'"  # ❌ Vulnerable
cursor.execute(query)
```

**Remediación:**
```python
query = "SELECT * FROM users WHERE id = ?"  # ✅ Correcto
cursor.execute(query, (user_id,))
```

---

### 3. python-unsafe-pickle.ql
**Detecta:** Deserialización insegura con pickle de fuentes no confiables

**Severidad:** 🔴 Error (9.0/10)

**CWE:** CWE-502 (Deserialization of Untrusted Data)

**Ejemplo detectado:**
```python
import pickle
data = request.data
model = pickle.loads(data)  # ❌ Puede ejecutar código arbitrario
```

**Remediación:**
```python
import joblib
import hmac
# Validar checksum antes de deserializar
if hmac.compare_digest(received_checksum, expected_checksum):
    model = joblib.load(file)  # ✅ Más seguro con validación
```

---

### 4. python-ml-unvalidated-input.ql
**Detecta:** Modelos ML que reciben input sin validación desde HTTP requests

**Severidad:** 🟡 Warning (6.0/10)

**CWE:** CWE-20 (Improper Input Validation)

**Ejemplo detectado:**
```python
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    prediction = model.predict(data)  # ❌ Sin validación
    return jsonify(prediction)
```

**Remediación:**
```python
@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    # Validar shape y tipos
    if not isinstance(data, list) or len(data) != expected_features:
        return "Invalid input", 400
    # Validar rangos
    validated_data = validate_input_ranges(data)
    prediction = model.predict(validated_data)  # ✅ Con validación
    return jsonify(prediction)
```

---

### 5. python-ml-missing-seed.ql
**Detecta:** Modelos ML entrenados sin random_state/seed (problemas de reproducibilidad)

**Severidad:** 🟡 Warning (4.0/10)

**CWE:** No aplica (Mantenibilidad)

**Ejemplo detectado:**
```python
model = RandomForestClassifier()  # ❌ Sin random_state
X_train, X_test = train_test_split(X, y)  # ❌ Sin random_state
```

**Remediación:**
```python
model = RandomForestClassifier(random_state=42)  # ✅ Reproducible
X_train, X_test = train_test_split(X, y, random_state=42)  # ✅ Reproducible
```

---

### 6. python-sensitive-data-in-logs.ql
**Detecta:** Logging de información sensible (passwords, PINs, PII)

**Severidad:** 🔴 Error (7.0/10)

**CWE:** CWE-532 (Information Exposure Through Log Files)

**Ejemplo detectado:**
```python
logging.info(f"User login: {username}, password: {password}")  # ❌ Password en logs
print(f"PIN: {pin}")  # ❌ PIN en logs
```

**Remediación:**
```python
logging.info(f"User login: {username}")  # ✅ Sin password
# No loguear PINs, passwords, tokens nunca
```

---

## 🚀 Cómo Usar las Queries

### Opción 1: En GitHub Actions (Recomendado)

```yaml
name: "CodeQL Custom Queries"

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  analyze:
    name: Analyze with Custom Queries
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout repository
      uses: actions/checkout@v3
      
    - name: Initialize CodeQL
      uses: github/codeql-action/init@v2
      with:
        languages: python
        queries: ./.codeql/custom-queries  # Ruta a queries personalizadas
        
    - name: Perform CodeQL Analysis
      uses: github/codeql-action/analyze@v2
```

### Opción 2: CodeQL CLI Local

```bash
# 1. Instalar CodeQL CLI
choco install codeql

# 2. Crear database
codeql database create python-db --language=python --source-root=.

# 3. Ejecutar queries personalizadas
codeql database analyze python-db \
  --format=sarif-latest \
  --output=results.sarif \
  ./.codeql/custom-queries/

# 4. Ver resultados
codeql bqrs decode python-db/results/*.bqrs --format=text
```

### Opción 3: Ejecutar Query Individual

```bash
# Ejecutar solo una query
codeql query run ./.codeql/custom-queries/python-hardcoded-credentials.ql \
  --database=python-db \
  --output=hardcoded-creds.bqrs

# Decodificar resultados
codeql bqrs decode hardcoded-creds.bqrs --format=text
```

---

## 📊 Resultados Esperados

Al ejecutar estas queries en el código vulnerable del taller, deberían detectarse:

| Query | Detecciones Esperadas | Archivos Afectados |
|-------|----------------------|-------------------|
| hardcoded-credentials | 6-8 | vulnerable_api.py, vulnerable_training.py |
| sql-injection | 4-6 | vulnerable_api.py |
| unsafe-pickle | 2-3 | vulnerable_api.py, vulnerable_training.py |
| ml-unvalidated-input | 2-3 | vulnerable_api.py |
| ml-missing-seed | 3-5 | vulnerable_training.py |
| sensitive-data-in-logs | 4-6 | vulnerable_api.py |

---

## 🎓 Objetivos de Aprendizaje (Lab 6)

Al completar el Lab 6 con estas queries, los participantes podrán:

1. ✅ Entender la estructura de una query CodeQL
2. ✅ Identificar sources, sinks y sanitizers
3. ✅ Usar taint tracking para seguir flujo de datos
4. ✅ Crear queries personalizadas para casos específicos
5. ✅ Integrar queries personalizadas en CI/CD
6. ✅ Interpretar resultados y priorizar remediaciones

---

## 🔧 Modificar Queries

### Estructura de una Query CodeQL

```ql
/**
 * @name Nombre descriptivo
 * @description Qué detecta la query
 * @kind problem | path-problem
 * @problem.severity error | warning | recommendation
 * @security-severity 0.0-10.0
 * @precision high | medium | low
 * @id identificador-unico
 * @tags security, cwe-XXX
 */

import python
import semmle.python.dataflow.new.DataFlow

// Lógica de la query
from ... where ... select ...
```

### Conceptos Clave

**Source:** Origen de datos potencialmente peligrosos
```ql
class UserInputSource extends DataFlow::Node {
  UserInputSource() {
    // Definir qué es user input
  }
}
```

**Sink:** Punto donde se usa el dato de forma peligrosa
```ql
class DangerousSink extends DataFlow::Node {
  DangerousSink() {
    // Definir operaciones peligrosas
  }
}
```

**Sanitizer:** Validación que previene vulnerabilidades
```ql
override predicate isSanitizer(DataFlow::Node node) {
  // Definir validaciones seguras
}
```

---

## 📚 Recursos Adicionales

- [CodeQL Documentation](https://codeql.github.com/docs/)
- [CodeQL for Python](https://codeql.github.com/docs/codeql-language-guides/codeql-for-python/)
- [Writing CodeQL Queries](https://codeql.github.com/docs/writing-codeql-queries/)
- [CodeQL Query Help](https://codeql.github.com/codeql-query-help/)
- [Python Standard Library](https://codeql.github.com/codeql-standard-libraries/python/)

---

## 🛠️ Troubleshooting

### Error: "No se puede importar módulo"
```bash
# Verificar que las librerías estén instaladas
codeql resolve library-path
codeql resolve languages
```

### Error: "Query no válida"
```bash
# Validar sintaxis
codeql query format --in-place <query>.ql
```

### Error: "No se encuentran resultados"
```bash
# Verificar que el database incluye los archivos correctos
codeql database info python-db
```

---

**Nota:** Estas queries están optimizadas para detectar vulnerabilidades específicas de aplicaciones bancarias y sistemas de ML. Se recomienda ajustarlas según las necesidades específicas del proyecto.
