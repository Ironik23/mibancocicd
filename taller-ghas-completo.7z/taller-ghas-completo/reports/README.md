# Reports Directory

Esta carpeta almacena los reportes generados durante el taller.

## Tipos de Reportes

### Reportes de Seguridad
- `code-quality-reports/` - Resultados de linting, bandit, etc.
- `dependency-reports/` - Vulnerabilidades de dependencias
- `secrets-reports/` - Detección de secrets

### Reportes ML
- `bias-report.json` - Métricas de fairness
- `fairness-report.html` - Dashboard de bias
- `explainability-report.json` - SHAP values

### Reportes de Compliance
- `sbs-report.txt` - Compliance SBS
- `gdpr-report.txt` - GDPR compliance
- `security-dashboard.html` - Dashboard general

## Generación

Los reportes se generan automáticamente por:
- GitHub Actions workflows
- Scripts locales (`scripts/`)
- Ejecución de labs

## .gitkeep

Esta carpeta incluye `.gitkeep` para mantenerla en Git aunque esté vacía.
