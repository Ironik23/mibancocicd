# Installation Guide for Restricted Environments
# Mi Banco - GHAS Workshop for Data Science

## Quick Decision Tree

**Can you access PyPI (pip.org)?**
- ✅ YES → Use `requirements.txt` (full installation)
- ❌ NO → Continue below

**Can you install Python packages at all?**
- ✅ YES (with restrictions) → Try `requirements-minimal.txt`
- ❌ NO (completely blocked) → Use `requirements-github-only.txt`

**Don't want to deal with installation?**
- Use GitHub-only modules (2, 3, 5) → Use `requirements-github-only.txt`

---

## Option 1: Full Installation (Ideal)

```powershell
pip install -r requirements.txt
```

**Modules you can complete:** All (1-6)

---

## Option 2: Minimal Installation (Restricted Networks)

```powershell
pip install -r requirements-minimal.txt
```

**What's included:**
- Core DS libraries (pandas, numpy, scikit-learn)
- Security tools (bandit, safety)
- Jupyter for notebooks
- Testing tools (pytest)

**What's excluded:**
- Advanced ML libraries (tensorflow, pytorch)
- SHAP (can be added later if needed)
- Non-essential dependencies

**Modules you can complete:** All (1-6)
**Estimated size:** ~150MB vs ~1.5GB for full installation

---

## Option 3: GitHub-Only (Zero Local Installation)

```powershell
# Optional - only if you want to validate configs
pip install -r requirements-github-only.txt
```

**Modules you can complete:**
- ✅ Module 1: Theory (no installation needed)
- ✅ Module 2: CodeQL (runs in GitHub Actions)
- ✅ Module 3: Dependabot (runs in GitHub)
- ✅ Module 5: Secret Scanning (runs in GitHub)
- ⚠️ Module 4: Skip or use Copilot to generate code only
- ⚠️ Module 6: Skip or use Copilot to generate workflows only

**Coverage:** 60% of workshop content without any installation

---

## Option 4: Corporate PyPI (If Available)

```powershell
# Ask IT for your corporate PyPI URL
pip config set global.index-url https://pypi-interno.mibanco.com/simple
pip config set global.trusted-host pypi-interno.mibanco.com

# Then use any requirements file
pip install -r requirements-minimal.txt
```

---

## Option 5: Offline Installation (Pre-downloaded Packages)

**Step 1:** Ask IT to download packages (on a machine with internet):
```powershell
# IT runs this on a machine with internet
pip download -r requirements-minimal.txt -d C:\paquetes-python\
```

**Step 2:** Copy `C:\paquetes-python\` to your restricted machine

**Step 3:** Install offline:
```powershell
pip install --no-index --find-links=C:\paquetes-python\ -r requirements-minimal.txt
```

---

## Option 6: Proxy Configuration

```powershell
# Ask IT for proxy details
$env:HTTP_PROXY = "http://proxy.mibanco.com:8080"
$env:HTTPS_PROXY = "http://proxy.mibanco.com:8080"

# If authentication required
$env:HTTP_PROXY = "http://username:password@proxy.mibanco.com:8080"
$env:HTTPS_PROXY = "http://username:password@proxy.mibanco.com:8080"

# Then install
pip install -r requirements-minimal.txt
```

---

## Validation Script

**After installation, run this to verify:**

```powershell
python -c "
import sys
print(f'✅ Python {sys.version.split()[0]}')

try:
    import pandas; print(f'✅ pandas {pandas.__version__}')
except: print('⚠️ pandas not installed (needed for Module 4)')

try:
    import numpy; print(f'✅ numpy {numpy.__version__}')
except: print('⚠️ numpy not installed (needed for Module 4)')

try:
    import sklearn; print(f'✅ scikit-learn {sklearn.__version__}')
except: print('⚠️ scikit-learn not installed (needed for Module 4)')

try:
    import jupyter; print(f'✅ jupyter installed')
except: print('⚠️ jupyter not installed (needed for Module 1)')

try:
    import bandit; print(f'✅ bandit installed')
except: print('⚠️ bandit not installed (nice to have)')

try:
    import dotenv; print(f'✅ python-dotenv installed')
except: print('⚠️ python-dotenv not installed (needed for Module 5)')

print('\n' + '='*50)
print('SUMMARY:')
print('  If you see mostly ✅ → You are ready!')
print('  If you see many ⚠️ → Try requirements-github-only.txt')
print('  Focus on GitHub-based modules (2, 3, 5)')
print('='*50)
"
```

---

## What to Do If Nothing Works

1. **Focus on GitHub-only modules** (2, 3, 5)
   - These work 100% in the cloud
   - No local installation needed
   - Still covers 60% of workshop content

2. **Use GitHub Codespaces** (if available)
   - Request access from IT
   - Fully configured cloud environment
   - All packages pre-installed

3. **Request a pre-configured VM from IT**
   - Ask for Python 3.8+ with data science libraries
   - Reference this workshop as the use case

4. **Pair with a colleague** who has a working environment
   - They run the scripts
   - You review the results and learn the concepts

---

## Support Contacts

If you're stuck:
- **IT Help Desk:** Open ticket for Python package access
- **Slack:** #it-support or #data-science-help
- **Workshop Facilitator:** Mention your restriction during the session
- **Alternative:** Use workshop time to learn theory, install packages later

---

## Summary Table

| Option | Installation Size | Time | Modules Covered | Best For |
|--------|------------------|------|-----------------|----------|
| Full (`requirements.txt`) | ~1.5GB | 10-20 min | All (1-6) | Unrestricted environments |
| Minimal (`requirements-minimal.txt`) | ~150MB | 5-10 min | All (1-6) | Restricted networks, limited space |
| GitHub-only (`requirements-github-only.txt`) | ~5MB | 1 min | 1,2,3,5 (60%) | Severely restricted, or no installation preference |
| No installation | 0MB | 0 min | 1,2,3,5 (theory) | Completely blocked, learning concepts only |

**Recommendation for Mi Banco restricted environment:** Start with **requirements-minimal.txt**
