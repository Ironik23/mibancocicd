# Collections Directory

Esta carpeta contiene colecciones Postman/Newman para testing de APIs.

## Colecciones Incluidas

### Banking API Security Tests
- **Archivo:** `Banking-API-Security-Tests.json`
- **Descripción:** Tests de seguridad OWASP Top 10
- **Endpoints:** 15+ tests

### Uso con Postman

1. Abrir Postman Desktop
2. File → Import
3. Seleccionar archivo .json
4. Ejecutar colección

### Uso con Newman (CLI)

```bash
# Instalar Newman
npm install -g newman

# Ejecutar colección
newman run collections/Banking-API-Security-Tests.json

# Con environment
newman run collections/Banking-API-Security-Tests.json \
  -e environments/dev.postman_environment.json

# Con reporte HTML
newman run collections/Banking-API-Security-Tests.json \
  --reporters cli,html \
  --reporter-html-export reports/api-tests.html
```

## Environments

Los environments se almacenan en `../environments/`:
- `dev.postman_environment.json`
- `staging.postman_environment.json`

## Tests Incluidos

- ✅ SQL Injection
- ✅ Authentication bypass
- ✅ Authorization flaws
- ✅ XSS vulnerabilities
- ✅ CSRF protection
- ✅ Rate limiting
- ✅ Input validation
- ✅ Error handling

## Para QE Track

Ver `GUIA_EJECUCION_GHAS_QE.md` para instrucciones detalladas de uso.
