# 🔐 TALLER 7: GitHub Advanced Security (GHAS) - Proyecto Completo

**Duración:** 2 horas | **Nivel:** Intermedio-Avanzado | **Público:** QE y DS

## 🎯 Objetivos del Taller

Este proyecto contiene todo lo necesario para completar el Taller 7 de GitHub Advanced Security, diseñado para Quality Engineers y Data Scientists en entornos bancarios.

### Para Quality Engineers (QE)
- ✅ Configurar CodeQL para detectar vulnerabilidades en APIs
- ✅ Crear security tests automatizados con Postman/Newman
- ✅ Implementar quality gates de seguridad en CI/CD
- ✅ Validar dependencias con Dependabot
- ✅ Generar reportes ejecutivos de seguridad

### Para Data Scientists (DS)
- ✅ Detectar vulnerabilidades en código ML/Python
- ✅ Medir y mitigar bias en modelos predictivos
- ✅ Implementar explicabilidad con SHAP
- ✅ Proteger secrets en notebooks Jupyter
- ✅ Crear pipelines ML seguros con validaciones

## 🚀 Quick Start

### 1. Requisitos Previos

**Obligatorios:**
- Git instalado
- Python 3.8+
- GitHub account con GHAS habilitado
- VS Code con GitHub Copilot

**Para QE adicional:**
- Postman Desktop o Newman CLI
- Node.js 16+ (para Newman)

**Para DS adicional:**
- Jupyter Notebook / JupyterLab
- Conocimientos de pandas, scikit-learn

### 2. Setup Inicial

```powershell
# Clonar o fork este repositorio
git clone <your-repo-url>
cd taller-ghas-completo

# Crear entorno virtual
python -m venv venv
.\venv\Scripts\Activate.ps1

# Instalar dependencias
pip install -r requirements.txt

# Verificar instalación
python scripts/validate-setup.py
```

### 3. Elegir tu Ruta

#### 🧪 Para QE (Quality Engineers):
```powershell
# Abrir guía QE
code GUIA_EJECUCION_GHAS_QE.md

# Comenzar Lab 1
cd labs/lab-1-codeql
code README.md
```

#### 🤖 Para DS (Data Scientists):
```powershell
# Abrir guía DS
code GUIA_EJECUCION_GHAS_DS.md

# Explorar notebooks vulnerables
jupyter notebook examples/python/vulnerable_ml_notebook.ipynb
```

## 📚 Estructura del Proyecto

```
taller-ghas-completo/
├── .github/
│   ├── workflows/              # GitHub Actions workflows
│   │   ├── codeql-analysis.yml
│   │   ├── ml-security-pipeline.yml
│   │   └── security-tests.yml
│   ├── dependabot.yml          # Configuración Dependabot
│   └── ISSUE_TEMPLATE/         # Templates de issues
├── .codeql/
│   └── custom-queries/         # 6 queries personalizadas CodeQL
│       ├── python-unsafe-pickle.ql
│       ├── python-sql-injection.ql
│       └── ...
├── scripts/                    # Scripts de automatización
│   ├── validate-setup.py
│   ├── detect-model-bias.py
│   ├── clean-notebook-secrets.py
│   ├── validate-ml-dependencies.py
│   └── evaluate-security-gates.py
├── src/
│   ├── vulnerable/             # Código con vulnerabilidades (para practicar)
│   │   ├── vulnerable_api.py
│   │   └── vulnerable_app.py
│   └── secure/                 # Código corregido (referencia)
│       └── secure_app.py
├── examples/
│   ├── python/                 # Ejemplos Python/ML
│   │   ├── vulnerable_ml_notebook.ipynb
│   │   ├── vulnerable_api.py
│   │   ├── vulnerable_training.py
│   │   └── test_data.csv
│   └── javascript/             # Ejemplos JavaScript/Node
│       └── vulnerable-banking-api.js
├── tests/                      # Tests automatizados
│   ├── test_secure_pickle.py
│   └── security_tests/
├── collections/                # Colecciones Postman
│   └── Banking-API-Security-Tests.json
├── labs/                       # 6 Laboratorios prácticos
│   ├── lab-1-codeql/
│   ├── lab-2-dependabot/
│   ├── lab-3-policies/
│   ├── lab-4-overview/
│   ├── lab-5-remediation/
│   └── lab-6-queries/
├── docs/                       # Documentación adicional
├── config/                     # Configuraciones
├── reports/                    # Reportes generados
├── models/                     # Modelos ML
├── requirements.txt            # Dependencias Python
├── .gitignore
├── .pre-commit-config.yaml
├── README.md                   # Este archivo
├── GUIA_EJECUCION_GHAS_QE.md  # Guía completa para QE
├── GUIA_EJECUCION_GHAS_DS.md  # Guía completa para DS
├── LIBRERIA_PROMPTS_GHAS.md   # 30+ prompts PACES
└── EJEMPLOS_GHAS_CODIGO.md    # Código ejecutable

```

## 📖 Documentación Principal

| Documento | Descripción | Audiencia | Duración |
|-----------|-------------|-----------|----------|
| [GUIA_EJECUCION_GHAS_QE.md](GUIA_EJECUCION_GHAS_QE.md) | Guía paso a paso para QE | QE | 2 hrs |
| [GUIA_EJECUCION_GHAS_DS.md](GUIA_EJECUCION_GHAS_DS.md) | Guía paso a paso para DS | DS | 2 hrs |
| [LIBRERIA_PROMPTS_GHAS.md](LIBRERIA_PROMPTS_GHAS.md) | 30+ prompts PACES listos | Ambos | Referencia |
| [EJEMPLOS_GHAS_CODIGO.md](EJEMPLOS_GHAS_CODIGO.md) | Código ejecutable | Ambos | Referencia |
| [GETTING_STARTED.md](GETTING_STARTED.md) | Inicio rápido | Ambos | 10 min |

## 🎓 Laboratorios Prácticos

Cada laboratorio incluye:
- 📝 README con instrucciones paso a paso
- 💻 Código de ejemplo para practicar
- ✅ Checklist de validación
- 🎯 Objetivos de aprendizaje claros

| Lab | Tema | Duración | Dificultad | Audiencia |
|-----|------|----------|-----------|-----------|
| **Lab 1** | CodeQL: Análisis de código | 20 min | ⭐⭐ | Ambos |
| **Lab 2** | Dependabot: Vulnerabilidades | 20 min | ⭐⭐ | Ambos |
| **Lab 3** | Branch Protection Policies | 15 min | ⭐ | QE |
| **Lab 4** | Security Overview Dashboard | 15 min | ⭐ | Ambos |
| **Lab 5** | Remediación de código | 20 min | ⭐⭐⭐ | Ambos |
| **Lab 6** | Custom CodeQL Queries | 30 min | ⭐⭐⭐ | Avanzado |

## 🛠️ Contenido Incluido

### 1. Workflows de GitHub Actions ✅
- **codeql-analysis.yml**: Análisis de seguridad con CodeQL
- **ml-security-pipeline.yml**: Pipeline completo ML con 6 stages
- **security-tests.yml**: Tests automatizados de seguridad
- **dependabot-auto-merge.yml**: Auto-merge de parches de seguridad

### 2. Custom CodeQL Queries ✅
- `python-unsafe-pickle.ql`: Detecta pickle.load() inseguro
- `python-sql-injection.ql`: Detecta SQL injection en pandas
- `python-hardcoded-credentials.ql`: Detecta credenciales hardcoded
- `python-sensitive-data-in-logs.ql`: Detecta PII en logs
- `python-ml-missing-seed.ql`: Detecta falta de random seeds
- `python-ml-unvalidated-input.ql`: Detecta input sin validar

### 3. Scripts de Automatización 🐍
- `validate-setup.py`: Valida instalación completa
- `detect-model-bias.py`: Mide fairness metrics (DI, EO, EOD)
- `clean-notebook-secrets.py`: Limpia secrets de notebooks
- `validate-ml-dependencies.py`: Valida compatibilidad de deps
- `evaluate-security-gates.py`: Evalúa quality gates

### 4. Código Vulnerable de Ejemplo ⚠️
- APIs REST con 8+ vulnerabilidades OWASP Top 10
- Notebooks ML con secrets, data leakage, bias
- Código Python con pickle inseguro, SQL injection
- Aplicaciones bancarias con vulnerabilidades reales

### 5. Tests de Seguridad ✅
- Tests unitarios de seguridad
- Colecciones Postman para API testing
- Tests de bias y fairness
- Tests de reproducibilidad

## ✅ Checklist de Inicio

Antes de comenzar el taller, verifica:

**Setup Básico:**
- [ ] Python 3.8+ instalado (`python --version`)
- [ ] Git configurado (`git --version`)
- [ ] Repositorio clonado
- [ ] Dependencias instaladas (`pip install -r requirements.txt`)
- [ ] Script de validación ejecutado (`python scripts/validate-setup.py`)

**GitHub:**
- [ ] Cuenta GitHub con GHAS habilitado
- [ ] Repositorio forked o pusheado a GitHub
- [ ] GitHub Copilot configurado en VS Code
- [ ] Permisos para habilitar GHAS features

**Para QE adicional:**
- [ ] Postman instalado o Newman CLI
- [ ] Node.js instalado (para Newman)

**Para DS adicional:**
- [ ] Jupyter instalado (`jupyter --version`)
- [ ] Notebooks abren correctamente

## 🎯 Flujo Recomendado

### Para QE:

**Día 1 - Setup y Fundamentos (1 hora)**
1. ✅ Setup inicial y validación
2. 📚 Leer introducción GUIA_EJECUCION_GHAS_QE.md
3. 🧪 Lab 1: CodeQL básico (20 min)
4. 📦 Lab 2: Dependabot (20 min)

**Día 2 - Implementación (1 hora)**
5. 🔒 Lab 3: Branch Protection (15 min)
6. 📊 Lab 4: Security Dashboard (15 min)
7. 🔧 Lab 5: Remediación práctica (20 min)
8. 💡 Lab 6: Custom Queries (10 min exploración)

### Para DS:

**Día 1 - Setup y Seguridad Básica (1 hora)**
1. ✅ Setup inicial y validación
2. 📚 Leer GUIA_EJECUCION_GHAS_DS.md
3. 🔍 Módulo 1: Riesgos de ML Security (15 min)
4. 🤖 Módulo 2: CodeQL para Python DS (25 min)
5. 📦 Módulo 3: Dependency Security (20 min)

**Día 2 - IA Responsable y Automatización (1 hora)**
6. ⚖️ Módulo 4: Bias y Fairness (30 min)
7. 🔐 Módulo 5: Secrets en Notebooks (15 min)
8. 🔄 Módulo 6: Pipeline ML Security (15 min)

## 💡 Tips para el Taller

### Uso de GitHub Copilot

Durante todo el taller, usa Copilot para:
- 🤖 Generar código corregido de vulnerabilidades
- 📝 Explicar conceptos de seguridad
- 🔍 Analizar código vulnerable
- ✅ Crear tests de seguridad

**Atajos útiles:**
- `Ctrl + Shift + I`: Abrir Copilot Chat
- `Ctrl + I`: Inline chat
- `Ctrl + Enter`: Sugerencias múltiples

### Prompts PACES

Todos los prompts están en formato PACES:
- **P**ropósito: Qué quieres lograr
- **A**udiencia: A quién va dirigido
- **C**ontexto: Situación actual
- **E**jemplos: Casos concretos
- **S**cope: Alcance de la respuesta

Ver `LIBRERIA_PROMPTS_GHAS.md` para 30+ prompts listos.

### Troubleshooting

**Problema: pip install falla**
- Solución: Ver sección "ENTORNOS RESTRINGIDOS" en guías

**Problema: CodeQL no detecta código**
- Solución: Verificar que archivos estén pusheados a GitHub

**Problema: Jupyter no abre notebooks**
- Solución: `pip install --upgrade jupyter notebook`

## 📞 Soporte y Recursos

### Documentación
- 📚 **Guías completas**: Ver `GUIA_EJECUCION_GHAS_*.md`
- 💬 **Copilot Chat**: Usa `Ctrl + Shift + I` para ayuda
- 📖 **Prompts**: Ver `LIBRERIA_PROMPTS_GHAS.md`
- 💻 **Código**: Ver `EJEMPLOS_GHAS_CODIGO.md`

### Links Útiles
- [GitHub Advanced Security Docs](https://docs.github.com/en/code-security)
- [CodeQL Documentation](https://codeql.github.com/docs/)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Fairness in ML](https://fairmlbook.org/)

### Community
- GitHub Discussions (en tu repo)
- Slack channel (si aplica)
- GitHub Copilot Chat integrado

## 🎉 Comienza Ahora

### Para QE:
```powershell
# Validar setup
python scripts/validate-setup.py

# Abrir guía QE
code GUIA_EJECUCION_GHAS_QE.md

# Comenzar Lab 1
cd labs/lab-1-codeql
code README.md
```

### Para DS:
```powershell
# Validar setup
python scripts/validate-setup.py

# Abrir guía DS
code GUIA_EJECUCION_GHAS_DS.md

# Explorar notebook vulnerable
jupyter notebook examples/python/vulnerable_ml_notebook.ipynb
```

## 📊 Métricas de Éxito

Al finalizar el taller, deberías tener:

**Para QE:**
- ✅ CodeQL configurado y ejecutando
- ✅ 10+ vulnerabilidades detectadas y remediadas
- ✅ Dependabot activo con auto-merge
- ✅ Branch protection rules configuradas
- ✅ Security tests automatizados
- ✅ Reportes ejecutivos generados

**Para DS:**
- ✅ Pipeline ML con 6 stages de seguridad
- ✅ Bias detectado y mitigado
- ✅ Explicabilidad implementada (SHAP)
- ✅ Secrets migrados a variables de entorno
- ✅ Dependencias validadas automáticamente
- ✅ Modelo con fairness metrics > 0.8

## 🏆 Certificación

Al completar todos los labs y módulos:
1. Genera screenshot de tu Security Overview
2. Exporta tu reporte de bias detection
3. Comparte tu pipeline ML en GitHub
4. Documenta 3 vulnerabilidades encontradas y remediadas

## 📄 Licencia

Este material es para fines educativos en el contexto de Mi Banco - Taller 7 GHAS.

---

**Última actualización:** Diciembre 2024  
**Versión:** 1.0  
**Estado:** ✅ Listo para usar

**¡Buena suerte con el taller! 🚀**

Para cualquier duda, usa GitHub Copilot Chat (`Ctrl + Shift + I`) 💬
