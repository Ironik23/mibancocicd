# 📑 Índice Completo del Proyecto - Taller 7 GHAS

## Navegación Rápida

### 🚀 Para Empezar
- **[README.md](README.md)** - Inicio aquí
- **[GETTING_STARTED.md](GETTING_STARTED.md)** - Setup rápido (10 min)
- **[PROYECTO_COMPLETO.md](PROYECTO_COMPLETO.md)** - Resumen del contenido

### 📖 Guías Principales

#### Para Quality Engineers (QE)
- **[GUIA_EJECUCION_GHAS_QE.md](GUIA_EJECUCION_GHAS_QE.md)** - Guía completa 2 horas
  - Módulo 1: CodeQL Setup
  - Módulo 2: Dependabot
  - Módulo 3: Branch Protection
  - Módulo 4: Security Dashboard
  - Módulo 5: Remediación
  - Módulo 6: API Security Testing

#### Para Data Scientists (DS)
- **[GUIA_EJECUCION_GHAS_DS.md](GUIA_EJECUCION_GHAS_DS.md)** - Guía completa 2 horas
  - Módulo 1: ML Security Risks
  - Módulo 2: CodeQL para Python DS
  - Módulo 3: Dependency Security
  - Módulo 4: Bias & Fairness
  - Módulo 5: Secrets en Notebooks
  - Módulo 6: ML Security Pipeline

### 💬 Recursos de Copilot
- **[LIBRERIA_PROMPTS_GHAS.md](LIBRERIA_PROMPTS_GHAS.md)** - 30+ prompts PACES
  - Prompts para CodeQL
  - Prompts para remediación
  - Prompts para ML security
  - Prompts para documentación

### 💻 Ejemplos de Código
- **[EJEMPLOS_GHAS_CODIGO.md](EJEMPLOS_GHAS_CODIGO.md)** - Código ejecutable
  - Ejemplos vulnerable
  - Ejemplos corregidos
  - Custom queries
  - Scripts de automatización

### 🛠️ Instalación y Setup
- **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** - Guía instalación detallada
  - Windows, Mac, Linux
  - Entornos corporativos
  - Troubleshooting
  - Opciones offline

### 🔄 CI/CD y Automatización
- **[EJEMPLOS_CICD_AUTOMATION.md](EJEMPLOS_CICD_AUTOMATION.md)** - Workflows
  - GitHub Actions
  - Pipeline ML Security
  - Quality Gates
  - Reportes automatizados

### 📊 Para Gestión
- **[RESUMEN_EJECUTIVO.md](RESUMEN_EJECUTIVO.md)** - Para stakeholders
- **[DISTRIBUCION.md](DISTRIBUCION.md)** - Cómo distribuir el taller

## Estructura de Carpetas

### `.github/`
GitHub configuration files

```
.github/
├── workflows/
│   ├── codeql-analysis.yml          # CodeQL workflow
│   └── ml-security-pipeline.yml     # ML pipeline (6 stages)
├── dependabot.yml                    # Dependabot config
└── ISSUE_TEMPLATE/                   # Issue templates
```

### `.codeql/`
Custom CodeQL queries

```
.codeql/
└── custom-queries/
    ├── python-unsafe-pickle.ql
    ├── python-sql-injection.ql
    ├── python-hardcoded-credentials.ql
    ├── python-sensitive-data-in-logs.ql
    ├── python-ml-missing-seed.ql
    └── python-ml-unvalidated-input.ql
```

### `scripts/`
Automation scripts

```
scripts/
├── validate-setup.py                 # Setup validation
├── detect-model-bias.py              # Bias detection
├── clean-notebook-secrets.py         # Secret cleaning
├── validate-ml-dependencies.py       # Dependency validation
└── evaluate-security-gates.py        # Gate evaluation
```

### `src/`
Source code examples

```
src/
├── vulnerable/                       # Para practicar
│   ├── vulnerable_api.py
│   └── vulnerable_app.py
└── secure/                           # Referencia
    └── secure_app.py
```

### `examples/`
Complete examples

```
examples/
├── python/
│   ├── vulnerable_ml_notebook.ipynb
│   ├── vulnerable_api.py
│   ├── vulnerable_training.py
│   ├── create_sample_model.py
│   └── test_data.csv
└── javascript/
    └── vulnerable-banking-api.js
```

### `tests/`
Test files

```
tests/
├── test_secure_pickle.py
└── security_tests/
```

### `labs/`
6 practical labs

```
labs/
├── lab-1-codeql/          # CodeQL basics
├── lab-2-dependabot/      # Dependency management
├── lab-3-policies/        # Branch protection
├── lab-4-overview/        # Security dashboard
├── lab-5-remediation/     # Code remediation
└── lab-6-queries/         # Custom queries
```

### `collections/`
Postman collections (QE)

```
collections/
├── Banking-API-Security-Tests.json
└── README.md
```

### `config/`
Configuration files

```
config/
└── [Configuration files]
```

### `docs/`
Additional documentation

```
docs/
└── [Additional guides]
```

### `models/`
ML models

```
models/
├── .gitkeep
└── README.md
```

### `reports/`
Generated reports

```
reports/
├── .gitkeep
└── README.md
```

## Archivos de Configuración Raíz

| Archivo | Descripción |
|---------|-------------|
| `.gitignore` | Files to ignore in Git |
| `.pre-commit-config.yaml` | Pre-commit hooks |
| `.env.example` | Environment variables template |
| `requirements.txt` | Python dependencies |

## Roadmap de Uso

### Primera Vez (Setup)

1. **[README.md](README.md)** - Entender el proyecto
2. **[GETTING_STARTED.md](GETTING_STARTED.md)** - Setup técnico
3. `python scripts/validate-setup.py` - Validar

### Durante el Taller

#### Track QE:
1. **[GUIA_EJECUCION_GHAS_QE.md](GUIA_EJECUCION_GHAS_QE.md)** - Seguir guía
2. `labs/lab-1-codeql/` → `lab-6-queries/` - Completar labs
3. **[LIBRERIA_PROMPTS_GHAS.md](LIBRERIA_PROMPTS_GHAS.md)** - Consultar prompts
4. **[EJEMPLOS_GHAS_CODIGO.md](EJEMPLOS_GHAS_CODIGO.md)** - Referencias

#### Track DS:
1. **[GUIA_EJECUCION_GHAS_DS.md](GUIA_EJECUCION_GHAS_DS.md)** - Seguir guía
2. Módulos 1-6 - Completar en orden
3. **[LIBRERIA_PROMPTS_GHAS.md](LIBRERIA_PROMPTS_GHAS.md)** - Consultar prompts
4. `examples/python/` - Practicar con ejemplos

### Troubleshooting

1. **[INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)** - Problemas de setup
2. Guías QE/DS - Sección troubleshooting
3. `scripts/validate-setup.py` - Re-validar

### Post-Taller

1. Implementar en proyectos reales
2. **[EJEMPLOS_CICD_AUTOMATION.md](EJEMPLOS_CICD_AUTOMATION.md)** - Workflows
3. Consultar **[LIBRERIA_PROMPTS_GHAS.md](LIBRERIA_PROMPTS_GHAS.md)** para casos específicos

## Búsqueda Rápida

### Por Tema

**CodeQL:**
- Guías: QE Módulo 1-2, DS Módulo 2
- Labs: `labs/lab-1-codeql/`, `labs/lab-6-queries/`
- Queries: `.codeql/custom-queries/`
- Workflows: `.github/workflows/codeql-analysis.yml`

**Dependabot:**
- Guías: QE Módulo 2, DS Módulo 3
- Labs: `labs/lab-2-dependabot/`
- Config: `.github/dependabot.yml`
- Scripts: `scripts/validate-ml-dependencies.py`

**Secrets:**
- Guías: DS Módulo 5
- Scripts: `scripts/clean-notebook-secrets.py`
- Config: `.pre-commit-config.yaml`

**Bias & Fairness:**
- Guías: DS Módulo 4
- Scripts: `scripts/detect-model-bias.py`
- Examples: `examples/python/vulnerable_ml_notebook.ipynb`

**API Security:**
- Guías: QE Módulo 6
- Collections: `collections/Banking-API-Security-Tests.json`
- Examples: `examples/python/vulnerable_api.py`

### Por Rol

**QE:** 
- Primary: [GUIA_EJECUCION_GHAS_QE.md](GUIA_EJECUCION_GHAS_QE.md)
- Labs: `labs/lab-1` → `lab-6`
- Collections: `collections/`

**DS:**
- Primary: [GUIA_EJECUCION_GHAS_DS.md](GUIA_EJECUCION_GHAS_DS.md)
- Examples: `examples/python/`
- Scripts: `scripts/detect-model-bias.py`

**Instructor:**
- [RESUMEN_EJECUTIVO.md](RESUMEN_EJECUTIVO.md)
- [DISTRIBUCION.md](DISTRIBUCION.md)
- [PROYECTO_COMPLETO.md](PROYECTO_COMPLETO.md)

**Manager/Stakeholder:**
- [RESUMEN_EJECUTIVO.md](RESUMEN_EJECUTIVO.md)
- [README.md](README.md)

## Estadísticas del Proyecto

- **Archivos totales:** 63+
- **Líneas de código:** ~8,000+
- **Documentación:** ~6,000+ líneas
- **Workflows:** 2
- **Custom queries:** 6
- **Scripts:** 5+
- **Labs:** 6
- **Guías:** 7+

## Contacto y Soporte

Durante el taller:
- 💬 Copilot Chat: `Ctrl + Shift + I`
- 📚 Documentación: Este índice
- 🔍 Search: `Ctrl + Shift + F` en VS Code

Post-taller:
- 📧 Email: instructor@mibanco.com
- 💬 Slack: #taller-7-ghas
- 📖 GitHub Discussions

---

**Última actualización:** Diciembre 2024  
**Versión:** 1.0  
**Total archivos:** 63+  
**Estado:** ✅ Completo
