# Configuration Files

Esta carpeta contiene archivos de configuración para el taller.

## Archivos de configuración comunes

Durante el taller, podrás crear aquí:

### Para Python
- `logging.conf` - Configuración de logging
- `database.ini` - Configuración de base de datos (usar .gitignore)
- `.env` - Variables de entorno (NUNCA commitear)

### Para CodeQL
- `codeql-config.yml` - Configuración custom de CodeQL (mejor en .github/codeql/)

### Para Docker
- `docker-compose.yml` - Configuración de servicios
- `.dockerignore` - Archivos a ignorar en build

## ⚠️ IMPORTANTE

**NUNCA** commitear archivos con:
- Credenciales
- API keys
- Passwords
- Tokens
- Datos sensibles

Usar siempre variables de entorno y `.env.example` como template.

## Ejemplo: .env.example

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=mi_banco_dev
DB_USER=your_username
DB_PASSWORD=your_password

# API Keys
OPENAI_API_KEY=your_openai_key
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret

# Application
DEBUG=false
SECRET_KEY=your_secret_key
ENVIRONMENT=development
```

---

**Nota:** Esta carpeta permanece vacía intencionalmente. Los archivos de configuración se crean según necesidad durante el desarrollo.
