#!/usr/bin/env python3
"""
Código SEGURO - Versión corregida del vulnerable_app.py
Propósito: Mostrar las mejores prácticas de seguridad
"""

import sqlite3
import subprocess
import os
from pathlib import Path
import logging
import hashlib
import secrets
from typing import Optional
import configparser

# ============================================================
# CONFIGURACIÓN SEGURA
# ============================================================

# 1. NUNCA hardcodear secrets en el código
# Usar variables de entorno o archivos de configuración
config = configparser.ConfigParser()
config.read('.env')  # Cargar desde archivo externo

API_KEY = os.getenv('API_KEY')  # ✅ Desde variable de entorno
DATABASE_PASSWORD = os.getenv('DB_PASSWORD')  # ✅ Desde variable de entorno

logger = logging.getLogger(__name__)


# ============================================================
# FIX 1: SQL Injection → Prepared Statements
# ============================================================

def get_user_by_email(email: str) -> list:
    """✅ SEGURO: Usando prepared statements"""
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Usar ? placeholders para parametrización
    query = "SELECT * FROM users WHERE email = ?"
    cursor.execute(query, (email,))
    return cursor.fetchall()


# ============================================================
# FIX 2: Command Injection → Safer methods
# ============================================================

def process_file(filename: str) -> str:
    """✅ SEGURO: Usando safe methods sin shell"""
    # Usar Path para manipulación segura
    filepath = Path(filename)
    
    # Validar que existe y es accesible
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {filepath}")
    
    # Usar subprocess sin shell=True
    result = subprocess.run(['cat', str(filepath)], 
                          capture_output=True, 
                          shell=False,  # ✅ IMPORTANTE
                          timeout=5)
    
    return result.stdout.decode()


# ============================================================
# FIX 3: Deserialization → JSON parsing
# ============================================================

import json

def deserialize_user(data: str) -> dict:
    """✅ SEGURO: Usando JSON en lugar de pickle"""
    # JSON es seguro, no ejecuta código
    return json.loads(data)


# ============================================================
# FIX 4: Weak Cryptography → Strong hashing
# ============================================================

def hash_password(password: str) -> str:
    """✅ SEGURO: Usando PBKDF2 con salt"""
    import hashlib
    
    # Generar salt aleatorio
    salt = secrets.token_hex(32)
    
    # Usar PBKDF2 (diseñado para passwords)
    pwd_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode(),
        salt.encode(),
        100000  # iteraciones
    )
    
    return f"{salt}:{pwd_hash.hex()}"

def verify_password(password: str, hashed: str) -> bool:
    """✅ SEGURO: Verificar password con timing-safe comparison"""
    salt, hash_value = hashed.split(':')
    pwd_hash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode(),
        salt.encode(),
        100000
    )
    
    # Usar secrets.compare_digest para evitar timing attacks
    return secrets.compare_digest(pwd_hash.hex(), hash_value)


# ============================================================
# FIX 5: Dangerous imports → Safe alternatives
# ============================================================

def run_command(cmd: list) -> str:
    """✅ SEGURO: Usando subprocess sin shell"""
    # Pasar comando como lista, no como string
    result = subprocess.run(cmd, 
                          capture_output=True,
                          shell=False,  # ✅ NUNCA shell=True
                          timeout=10)
    
    if result.returncode != 0:
        logger.error(f"Command failed: {result.stderr.decode()}")
        raise RuntimeError("Command execution failed")
    
    return result.stdout.decode()


# ============================================================
# FIX 6: Path Traversal → Validated paths
# ============================================================

SAFE_DOCUMENTS_DIR = Path("/var/www/documents")

def read_file_from_user_path(user_input: str) -> str:
    """✅ SEGURO: Validar que ruta está dentro del directorio permitido"""
    # Resolver ruta relativa y validar
    requested_path = (SAFE_DOCUMENTS_DIR / user_input).resolve()
    
    # Verificar que está dentro del directorio permitido
    if not str(requested_path).startswith(str(SAFE_DOCUMENTS_DIR)):
        raise ValueError("Path traversal attempt detected")
    
    # Verificar que existe
    if not requested_path.exists():
        raise FileNotFoundError(f"File not found: {requested_path}")
    
    with open(requested_path, 'r') as f:
        return f.read()


# ============================================================
# FIX 7: Unsafe Logging → Filter sensitive data
# ============================================================

class SensitiveDataFilter(logging.Filter):
    """Filtro que elimina datos sensibles de los logs"""
    
    PATTERNS = [
        r'password["\']?\s*[:=]\s*["\']?[^"\']*["\']?',
        r'api[_-]?key["\']?\s*[:=]\s*["\']?[^"\']*["\']?',
        r'token["\']?\s*[:=]\s*["\']?[^"\']*["\']?',
    ]
    
    def filter(self, record: logging.LogRecord) -> bool:
        import re
        message = record.getMessage()
        for pattern in self.PATTERNS:
            message = re.sub(pattern, r'\g<0>=***REDACTED***', message, flags=re.IGNORECASE)
        record.msg = message
        return True


# Agregar filtro a logger
logger.addFilter(SensitiveDataFilter())

def login_user(username: str, password: str) -> bool:
    """✅ SEGURO: NO loguear datos sensibles"""
    logger.info(f"User {username} login attempt")
    # ✅ NO incluir password en logs
    
    # Validaciones
    if not username or not password:
        logger.warning(f"Login attempt with missing credentials")
        return False
    
    # Verificar contra base de datos
    # (código de verificación de password aquí)
    
    return True


# ============================================================
# FIX 8: Validación de Entrada
# ============================================================

def validate_email(email: str) -> bool:
    """✅ SEGURO: Validación de email"""
    import re
    
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_username(username: str) -> bool:
    """✅ SEGURO: Validación de username"""
    # Solo alphanumerics y guiones bajos
    return bool(re.match(r'^[a-zA-Z0-9_]{3,20}$', username))


# ============================================================
# FIX 9: Input Sanitization
# ============================================================

def sanitize_input(user_input: str, max_length: int = 255) -> str:
    """✅ SEGURO: Sanitizar entrada del usuario"""
    # Limitar longitud
    sanitized = user_input[:max_length]
    
    # Remover caracteres peligrosos
    dangerous_chars = [';', '\\', '"', "'", '<', '>', '`']
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, '')
    
    return sanitized.strip()


# ============================================================
# FIX 10: Rate Limiting
# ============================================================

from datetime import datetime, timedelta
from collections import defaultdict

login_attempts = defaultdict(list)
MAX_ATTEMPTS = 5
WINDOW = timedelta(minutes=15)

def check_rate_limit(username: str) -> bool:
    """✅ SEGURO: Implementar rate limiting"""
    now = datetime.now()
    
    # Limpiar intentos antiguos
    login_attempts[username] = [
        attempt for attempt in login_attempts[username]
        if now - attempt < WINDOW
    ]
    
    # Verificar límite
    if len(login_attempts[username]) >= MAX_ATTEMPTS:
        logger.warning(f"Rate limit exceeded for user: {username}")
        return False
    
    # Registrar nuevo intento
    login_attempts[username].append(now)
    return True


if __name__ == "__main__":
    print("✅ Código SEGURO para TALLER 7")
    print("Ver: labs/lab-5-remediation para mejoras")
    print("\nCONTRAST:")
    print("- Antes:  vulnerable_app.py (8 vulnerabilidades)")
    print("- Después: secure_app.py (todas corregidas)")
