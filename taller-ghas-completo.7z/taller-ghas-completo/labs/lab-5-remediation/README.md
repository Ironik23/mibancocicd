# Lab 5: Remediation & Copilot Autofix

**Duración:** 20 minutos | **Nivel:** ⭐⭐⭐ | **Objetivo:** Corregir vulnerabilidades usando GitHub Copilot Autofix

---

## 🎯 Objetivo del Lab

En este lab aprenderás a:
- ✅ Usar GitHub Copilot Autofix para corregir vulnerabilidades
- ✅ Entender el flujo de remediación
- ✅ Validar correcciones con tests
- ✅ Documentar cambios de seguridad
- ✅ Suprimir false positives correctamente

---

## 📋 Requisitos Previos

- GitHub Copilot activo
- CodeQL ejecutado con alertas
- VS Code con Copilot Chat
- Conocimiento de patrones seguros

---

## 🚀 Paso 1: Entender Copilot Autofix (3 min)

### ¿Qué es Copilot Autofix?

```
CodeQL detecta vulnerabilidad
         ↓
Copilot Autofix analiza:
  - Código vulnerable
  - Contexto
  - Patrones seguros
         ↓
Genera corrección automática
         ↓
Developer revisa y aplica
```

### Ejemplo Visual

```python
# ❌ ANTES: CodeQL detecta SQL Injection
def get_user(email):
    query = f"SELECT * FROM users WHERE email = '{email}'"
    cursor.execute(query)
    
# 🤖 Copilot Autofix sugiere:
def get_user(email):
    query = "SELECT * FROM users WHERE email = ?"
    cursor.execute(query, (email,))
    
# ✅ Developer aplica fix
```

---

## 🔍 Paso 2: Remediar SQL Injection (5 min)

### Escenario Real

Tienes esta vulnerabilidad en `src/vulnerable/app.py`:

```python
def search_transactions(customer_id, date_from, date_to):
    """❌ VULNERABLE: SQL Injection en múltiples parámetros"""
    query = f"""
        SELECT t.* 
        FROM transactions t
        WHERE t.customer_id = '{customer_id}'
        AND t.date BETWEEN '{date_from}' AND '{date_to}'
        ORDER BY t.date DESC
    """
    return db.execute(query).fetchall()
```

### Paso a paso con Copilot

#### 1. Abrir alerta en GitHub

```
🔴 CRITICAL: SQL Injection
File: src/vulnerable/app.py:45
Rule: py/sql-injection

This query is built using string formatting with 
data that comes from user input. An attacker can 
inject SQL commands to access unauthorized data.
```

#### 2. Click en "Suggest fix with Copilot"

Copilot analiza y sugiere:

```python
def search_transactions(customer_id, date_from, date_to):
    """✅ SEGURO: Prepared statements con placeholders"""
    query = """
        SELECT t.* 
        FROM transactions t
        WHERE t.customer_id = ?
        AND t.date BETWEEN ? AND ?
        ORDER BY t.date DESC
    """
    # Validar inputs
    if not isinstance(customer_id, (int, str)):
        raise ValueError("Invalid customer_id")
    
    # Validar formato de fechas
    try:
        datetime.strptime(date_from, '%Y-%m-%d')
        datetime.strptime(date_to, '%Y-%m-%d')
    except ValueError:
        raise ValueError("Invalid date format. Use YYYY-MM-DD")
    
    return db.execute(query, (customer_id, date_from, date_to)).fetchall()
```

#### 3. Revisar cambios

**✅ Lo que hizo bien:**
- Usa placeholders `?` en vez de f-strings
- Parámetros pasados como tuple
- Agregó validación de inputs
- Validación de formato de fechas

**📝 Mejoras adicionales:**
```python
# Agregar logging seguro (sin PII)
logger.info(f"Searching transactions for date range: {date_from} to {date_to}")

# Agregar type hints
def search_transactions(
    customer_id: Union[int, str], 
    date_from: str, 
    date_to: str
) -> List[Dict]:
```

#### 4. Aplicar fix

```bash
git add src/vulnerable/app.py
git commit -m "fix: SQL injection in search_transactions

- Use prepared statements with placeholders
- Add input validation for customer_id and dates
- Validate date format before query execution

Fixes: GHSA-xxxx-yyyy-zzzz"
```

---

## 🛡️ Paso 3: Remediar Command Injection (4 min)

### Código Vulnerable

```python
def backup_database(db_name, output_path):
    """❌ VULNERABLE: Command Injection"""
    cmd = f"pg_dump {db_name} > {output_path}"
    subprocess.run(cmd, shell=True)  # PELIGRO!
```

### Copilot Autofix sugiere

```python
import subprocess
import shlex
from pathlib import Path

def backup_database(db_name: str, output_path: str) -> None:
    """✅ SEGURO: No shell, validación de inputs"""
    
    # Validar db_name (solo alphanumeric + underscore)
    if not re.match(r'^[a-zA-Z0-9_]+$', db_name):
        raise ValueError("Invalid database name")
    
    # Validar output_path
    output = Path(output_path).resolve()
    if not output.parent.exists():
        raise ValueError("Output directory does not exist")
    
    # ✅ No shell=True, argumentos como lista
    cmd = [
        'pg_dump',
        '--dbname', db_name,
        '--file', str(output)
    ]
    
    try:
        result = subprocess.run(
            cmd,
            shell=False,  # ✅ Crucial!
            check=True,
            capture_output=True,
            timeout=300  # 5 min timeout
        )
        logger.info(f"Database backup completed: {db_name}")
        return result.returncode
    except subprocess.CalledProcessError as e:
        logger.error(f"Backup failed: {e.stderr.decode()}")
        raise
    except subprocess.TimeoutExpired:
        logger.error("Backup timeout exceeded")
        raise
```

### Por qué es seguro

```
❌ Con shell=True:
   cmd = "pg_dump mydb; rm -rf /"  # ← Inyección!
   
✅ Sin shell=True:
   cmd = ['pg_dump', 'mydb; rm -rf /']
   # Se pasa literal como nombre de DB, falla sin daño
```

---

## 🔐 Paso 4: Remediar Secrets Hardcoded (3 min)

### Código Vulnerable

```python
# ❌ VULNERABLE: API keys hardcoded
API_KEY = "sk-proj-abc123xyz789..."
AWS_SECRET = "wJalrXUtn..."
DB_PASSWORD = "SuperSecret123"

def connect_to_api():
    headers = {'Authorization': f'Bearer {API_KEY}'}
    return requests.get('https://api.example.com', headers=headers)
```

### Copilot Autofix sugiere

```python
import os
from dotenv import load_dotenv

# ✅ Cargar desde variables de entorno
load_dotenv()

API_KEY = os.getenv('API_KEY')
AWS_SECRET = os.getenv('AWS_SECRET_ACCESS_KEY')
DB_PASSWORD = os.getenv('DB_PASSWORD')

# Validar que existen
required_vars = ['API_KEY', 'AWS_SECRET_ACCESS_KEY', 'DB_PASSWORD']
missing = [var for var in required_vars if not os.getenv(var)]
if missing:
    raise EnvironmentError(f"Missing required env vars: {missing}")

def connect_to_api():
    """✅ SEGURO: Usa env vars"""
    if not API_KEY:
        raise ValueError("API_KEY not set")
    
    headers = {'Authorization': f'Bearer {API_KEY}'}
    return requests.get('https://api.example.com', headers=headers)
```

### Crear .env.example

```bash
# .env.example
API_KEY=your_api_key_here
AWS_SECRET_ACCESS_KEY=your_aws_secret_here
DB_PASSWORD=your_database_password_here
```

### Actualizar .gitignore

```bash
# Secrets
.env
.env.local
*.pem
*.key
secrets/
```

---

## ✅ Paso 5: Validar Correcciones (3 min)

### Crear Tests de Seguridad

```python
# tests/test_security_fixes.py
import pytest
from src.secure.app import search_transactions, backup_database

class TestSQLInjectionFixes:
    """Validar que SQL injection está corregido"""
    
    def test_sql_injection_attempt_blocked(self):
        """Intentar inyección SQL debe fallar o sanitizarse"""
        malicious_input = "1' OR '1'='1"
        
        # Debería lanzar error o no encontrar nada
        with pytest.raises(ValueError):
            search_transactions(malicious_input, '2024-01-01', '2024-12-31')
    
    def test_valid_input_works(self):
        """Input legítimo debe funcionar"""
        result = search_transactions('12345', '2024-01-01', '2024-12-31')
        assert result is not None
    
    def test_date_validation(self):
        """Fechas inválidas deben rechazarse"""
        with pytest.raises(ValueError):
            search_transactions('12345', 'invalid-date', '2024-12-31')


class TestCommandInjectionFixes:
    """Validar que command injection está corregido"""
    
    def test_command_injection_blocked(self):
        """Intentar inyección de comando debe fallar"""
        malicious_db = "mydb; rm -rf /"
        
        with pytest.raises(ValueError):
            backup_database(malicious_db, '/tmp/backup.sql')
    
    def test_valid_database_name(self):
        """Nombre válido debe funcionar"""
        # Mock subprocess para testing
        result = backup_database('valid_db_name', '/tmp/backup.sql')
        assert result == 0


class TestSecretsFixed:
    """Validar que secrets no están hardcoded"""
    
    def test_no_hardcoded_secrets_in_code(self):
        """Verificar que no hay secrets en el código"""
        import ast
        import inspect
        from src.secure import app
        
        source = inspect.getsource(app)
        tree = ast.parse(source)
        
        # Buscar strings que parezcan API keys
        for node in ast.walk(tree):
            if isinstance(node, ast.Str):
                value = node.s
                # Patrones de API keys
                if re.match(r'sk-[a-zA-Z0-9]{40,}', value):
                    pytest.fail(f"Potential API key found: {value[:10]}...")
                if re.match(r'AKIA[0-9A-Z]{16}', value):
                    pytest.fail(f"AWS access key found")
```

### Ejecutar Tests

```bash
pytest tests/test_security_fixes.py -v

# Output esperado:
# test_sql_injection_attempt_blocked ✅ PASSED
# test_valid_input_works ✅ PASSED
# test_date_validation ✅ PASSED
# test_command_injection_blocked ✅ PASSED
# test_valid_database_name ✅ PASSED
# test_no_hardcoded_secrets_in_code ✅ PASSED
```

---

## 🚫 Paso 6: Suprimir False Positives (2 min)

### Cuándo suprimir

```
✅ Suprimir SI:
   - False positive confirmado
   - No es explotable en tu contexto
   - Mitigación alternativa implementada

❌ NO suprimir SI:
   - Vulnerabilidad real
   - No entiendes la alerta
   - "Después lo arreglo"
```

### Cómo suprimir correctamente

```python
def safe_eval_expression(expr: str, allowed_vars: dict) -> Any:
    """
    Evalúa expresión matemática simple de forma segura.
    
    CodeQL alerta sobre eval(), pero está mitigado porque:
    1. Solo acepta expresiones matemáticas (+, -, *, /)
    2. Scope limitado a variables permitidas
    3. Validación de AST antes de eval
    """
    import ast
    
    # Validar que solo tiene operaciones matemáticas
    tree = ast.parse(expr, mode='eval')
    for node in ast.walk(tree):
        if not isinstance(node, (ast.Expression, ast.BinOp, ast.Num, 
                                 ast.Name, ast.Add, ast.Sub, ast.Mult, ast.Div)):
            raise ValueError(f"Operación no permitida: {type(node)}")
    
    # Evaluar con scope limitado
    # codeql[py/code-injection] - Mitigado: AST validado, scope limitado
    return eval(expr, {"__builtins__": {}}, allowed_vars)
```

### En GitHub UI

1. Ve a la alerta
2. Click **Dismiss alert**
3. Selecciona razón:
   - **False positive**
   - **Won't fix** (con justificación)
   - **Used in tests** (si es código de test)
4. Agrega comentario explicando **por qué** es seguro
5. Confirm

---

## 📝 Ejercicio Final: Remediar Todo

### Tu misión

Archivo: `examples/python/vulnerable_api.py`

Tiene **16 vulnerabilidades**. Tu objetivo:

1. ✅ Identificar todas (usa CodeQL)
2. ✅ Usar Copilot Autofix para corregir
3. ✅ Crear tests de seguridad
4. ✅ Validar que todas están corregidas
5. ✅ Crear PR con las correcciones

### Checklist de correcciones

```markdown
- [ ] SQL Injection (línea 45)
- [ ] Hardcoded credentials (líneas 12-14)
- [ ] Insecure pickle loading (línea 68)
- [ ] eval() con input de usuario (línea 89)
- [ ] exec() con código arbitrario (línea 103)
- [ ] No authentication en endpoints (línea 52)
- [ ] No file validation (línea 72)
- [ ] SQL injection en query params (línea 115)
- [ ] Exposing error details (línea 125)
- [ ] Timing attack (línea 143)
- [ ] Secrets en funciones (línea 156)
- [ ] Weak random (línea 168)
- [ ] Debug mode en producción (línea 17)
- [ ] Logging PII (línea 48)
- [ ] No rate limiting (línea 142)
- [ ] Running on 0.0.0.0 (línea 172)
```

---

## ✅ Checklist de Validación

- [ ] Usé Copilot Autofix en al menos 3 vulnerabilidades
- [ ] Entiendo por qué cada corrección es segura
- [ ] Creé tests para validar las correcciones
- [ ] Documenté cambios en commits
- [ ] Sé cuándo suprimir false positives

---

## ❓ Preguntas Frecuentes

**P1: ¿Copilot Autofix siempre genera código seguro?**
R: No al 100%. Siempre revisa y valida:
- ¿La corrección elimina la vulnerabilidad?
- ¿No introduce nuevos bugs?
- ¿Sigue las best practices del equipo?

**P2: ¿Qué hago si no estoy seguro de una corrección?**
R:
1. Pedir revisión de senior/security team
2. Consultar documentación (OWASP, CWE)
3. Crear prueba de concepto para validar
4. Nunca aplicar sin entender

**P3: ¿Cómo priorizar remediación?**
R: Orden:
1. CRITICAL en producción → HOY
2. HIGH en producción → Esta semana
3. CRITICAL en dev → Esta semana
4. MEDIUM/HIGH en dev → Este mes
5. LOW → Backlog

**P4: ¿Cuántos fixes en un PR?**
R: Depende:
- Similar type (ej: 5 SQL injections) → 1 PR
- Different types → PRs separados
- Mega refactor → Múltiples PRs pequeños

---

## 💡 Best Practices

### 1. Commit Messages Descriptivos

```bash
# ❌ Malo
git commit -m "fix bugs"

# ✅ Bueno
git commit -m "fix: SQL injection in search_transactions

- Replace f-string with prepared statement
- Add input validation for customer_id
- Add date format validation
- Add unit tests for injection attempts

Fixes: GHSA-xxxx-yyyy-zzzz
CWE-89"
```

### 2. Documentar Decisiones

```python
def legacy_api_call(user_input):
    """
    SECURITY NOTE: Esta función usa eval() por compatibilidad
    con sistema legacy que requiere expresiones dinámicas.
    
    Mitigaciones implementadas:
    1. Whitelist de funciones permitidas
    2. AST validation antes de eval
    3. Timeout de 1 segundo
    4. Scope aislado sin builtins
    
    Deprecation: Remover en v3.0 (2025-Q2)
    Alternative: Migrar a expression evaluator seguro
    
    Risk: LOW (mitigado)
    Reviewed: 2024-12-10 by Security Team
    """
```

### 3. Tests de Regresión

```python
# Después de corregir, agregar test que evite regresión
def test_sql_injection_not_reintroduced():
    """Evitar que SQL injection sea reintroducido en el futuro"""
    # Este test falla si alguien quita el prepared statement
    assert 'execute(query, (' in inspect.getsource(search_transactions)
```

---

## 📚 Recursos Adicionales

- [Copilot Autofix Docs](https://docs.github.com/en/code-security/code-scanning/managing-code-scanning-alerts/about-autofix-for-codeql-code-scanning)
- [OWASP Secure Coding](https://owasp.org/www-project-secure-coding-practices-quick-reference-guide/)
- [CWE Top 25](https://cwe.mitre.org/top25/)

---

**¡Felicidades! Completaste Lab 5** 🎉

¿Listo para Lab 6? → `cd ../lab-6-queries && cat README.md`
