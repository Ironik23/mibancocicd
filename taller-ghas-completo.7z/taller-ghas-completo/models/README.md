# Models Directory

Esta carpeta contiene modelos ML de ejemplo para el taller.

## Modelos Incluidos

Los modelos se generan durante el taller usando:
- `examples/python/create_sample_model.py`
- Scripts de entrenamiento en notebooks

## Uso

```python
import pickle

# Cargar modelo
with open('models/sample_model.pkl', 'rb') as f:
    model = pickle.load(f)

# Hacer predicciones
predictions = model.predict(X_test)
```

⚠️ **Nota de Seguridad:** Los modelos pickle pueden ser inseguros. Ver Lab 5 para aprender a cargarlos de forma segura.
