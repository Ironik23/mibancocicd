"""
Tests para la función de carga segura de modelos pickle.

Estos tests validan que la función load_model_secure:
- Carga modelos legítimos correctamente
- Rechaza archivos con hash incorrecto
- Bloquea clases no autorizadas
- Registra intentos sospechosos
"""

import unittest
import tempfile
import os
import pickle
import logging
from unittest.mock import patch
from sklearn.ensemble import RandomForestClassifier
import numpy as np

# Importar las funciones del módulo vulnerable (que ahora incluye la segura)
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'examples', 'python'))
from vulnerable_training import load_model_secure, compute_file_hash, save_model


class TestSecurePickleLoading(unittest.TestCase):
    """Test suite para validación de carga segura de modelos."""

    def setUp(self):
        """Configurar datos de test."""
        # Crear un modelo de ejemplo
        self.model = RandomForestClassifier(n_estimators=10, random_state=42)
        X = np.random.rand(100, 4)
        y = np.random.randint(0, 2, 100)
        self.model.fit(X, y)

        # Crear archivo temporal para el modelo
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pkl')
        self.temp_file.close()
        self.model_path = self.temp_file.name

        # Guardar modelo legítimo
        save_model(self.model, self.model_path)
        self.expected_hash = compute_file_hash(self.model_path)

    def tearDown(self):
        """Limpiar archivos temporales."""
        if os.path.exists(self.model_path):
            os.unlink(self.model_path)

    def test_load_legitimate_model(self):
        """Test: Carga exitosa de modelo legítimo con hash correcto."""
        # Act
        loaded_model = load_model_secure(self.model_path, self.expected_hash)

        # Assert
        self.assertIsInstance(loaded_model, RandomForestClassifier)
        self.assertEqual(loaded_model.n_estimators, 10)

    def test_reject_wrong_hash(self):
        """Test: Rechaza modelo con hash incorrecto."""
        wrong_hash = "abcd" * 16  # Hash inválido

        # Act & Assert
        with self.assertRaises(ValueError) as context:
            load_model_secure(self.model_path, wrong_hash)

        self.assertIn("integrity check failed", str(context.exception))

    def test_reject_manipulated_file(self):
        """Test: Rechaza archivo pickle manipulado."""
        # Manipular el archivo pickle
        with open(self.model_path, 'wb') as f:
            f.write(b"malicious content")

        # Act & Assert
        with self.assertRaises(ValueError):
            load_model_secure(self.model_path, self.expected_hash)

    def test_reject_unauthorized_class(self):
        """Test: Bloquea clases no autorizadas en pickle."""
        # Crear pickle con clase de módulo no permitido
        import os
        malicious_data = os.system  # Función del módulo 'os' que no está permitido
        
        malicious_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pkl')
        try:
            pickle.dump(malicious_data, malicious_file)
            malicious_file.close()
            
            # Act & Assert
            with self.assertRaises(ValueError) as context:
                load_model_secure(malicious_file.name, None)
            
            self.assertIn("not allowed", str(context.exception))
        finally:
            if os.path.exists(malicious_file.name):
                os.unlink(malicious_file.name)

    def test_logging_suspicious_attempts(self):
        """Test: Registra intentos sospechosos en logs."""
        with patch('vulnerable_training.logging.getLogger') as mock_get_logger:
            mock_logger = mock_get_logger.return_value
            
            # Intentar cargar con hash incorrecto
            try:
                load_model_secure(self.model_path, "wrong_hash")
            except ValueError:
                pass

            # Verificar que se registró el warning
            mock_logger.warning.assert_called()

    def test_file_not_found(self):
        """Test: Maneja correctamente archivos inexistentes."""
        with self.assertRaises(FileNotFoundError):
            load_model_secure("nonexistent_file.pkl", None)

    def test_load_without_hash_validation(self):
        """Test: Carga funciona sin validación de hash (menos seguro)."""
        # Act
        loaded_model = load_model_secure(self.model_path, None)

        # Assert
        self.assertIsInstance(loaded_model, RandomForestClassifier)


if __name__ == '__main__':
    # Configurar logging para tests
    logging.basicConfig(level=logging.DEBUG)

    # Ejecutar tests
    unittest.main(verbosity=2)