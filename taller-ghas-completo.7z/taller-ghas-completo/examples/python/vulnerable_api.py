"""
Código Python vulnerable para demostración - Credit Scoring API
================================================================

Este archivo contiene vulnerabilidades intencionalmente para el Taller 7.
NO usar en producción.

Vulnerabilidades incluidas:
- SQL Injection
- Insecure deserialization (pickle)
- Hardcoded credentials
- Eval/exec usage
- Missing input validation
- Logging sensitive data
"""

import pickle
import sqlite3
import os
from flask import Flask, request, jsonify
from simpleeval import SimpleEval

app = Flask(__name__)

# ❌ VULNERABILIDAD 1: Hardcoded credentials
DATABASE_URL = "postgresql://admin:SuperSecret123@prod-db.banco.com:5432/customers"
API_SECRET_KEY = "sk-prod-1234567890abcdefghijklmnopqrstuvwxyz"
AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE"

# ❌ VULNERABILIDAD 2: Debug mode en producción
app.config['DEBUG'] = True
app.config['SECRET_KEY'] = 'easy_to_guess_secret'


@app.route('/predict', methods=['POST'])
def predict_credit_score():
    """
    Endpoint para predecir score crediticio.
    
    ❌ VULNERABILIDADES:
    - No input validation
    - SQL injection
    - Logging sensitive data
    """
    data = request.json
    customer_id = data.get('customer_id')
    
    # ❌ VULNERABILIDAD 3: SQL Injection
    conn = sqlite3.connect('banking.db')
    query = f"SELECT * FROM customers WHERE id = '{customer_id}'"  # Vulnerable!
    cursor = conn.execute(query)
    customer = cursor.fetchone()
    
    # ❌ VULNERABILIDAD 4: Logging PII
    app.logger.info(f"Processing request for customer: {customer}")
    
    # ❌ VULNERABILIDAD 5: Insecure pickle loading
    model = load_model_unsafe('models/credit_model.pkl')
    
    # Hacer predicción
    features = [customer[2], customer[3], customer[4]]  # income, age, credit_history
    prediction = model.predict([features])[0]
    
    conn.close()
    
    return jsonify({
        'customer_id': customer_id,
        'credit_score': prediction,
        'customer_data': customer  # ❌ Exponiendo PII
    })


@app.route('/update_model', methods=['POST'])
def update_model():
    """
    Actualiza el modelo ML.
    
    ❌ VULNERABILIDADES:
    - No authentication
    - Arbitrary file upload
    - Code execution via pickle
    """
    # ❌ VULNERABILIDAD 6: No authentication
    if 'model' not in request.files:
        return jsonify({'error': 'No model provided'}), 400
    
    model_file = request.files['model']
    
    # ❌ VULNERABILIDAD 7: No file validation
    model_path = f'models/{model_file.filename}'
    model_file.save(model_path)
    
    # ❌ VULNERABILIDAD 8: Loading untrusted pickle
    with open(model_path, 'rb') as f:
        model = pickle.load(f)  # Can execute arbitrary code!
    
    return jsonify({'message': 'Model updated successfully'})


@app.route('/calculate', methods=['POST'])
def calculate_dynamic():
    """
    Calcula métricas dinámicamente.
    
    ❌ VULNERABILIDADES:
    - eval() con input de usuario
    - Code injection
    """
    data = request.json
    formula = data.get('formula')  # ej: "income * 0.3 + age * 100"
    
    # ❌ VULNERABILIDAD 9: eval() permite code injection
    # Un atacante podría enviar: "__import__('os').system('rm -rf /')"
    try:
        s = SimpleEval()
        s.names = data
        result = s.eval(formula)
    except Exception as e:
        return jsonify({'error': f'Invalid formula: {str(e)}'}), 400
    
    return jsonify({'result': result})


@app.route('/execute', methods=['POST'])
def execute_code():
    """
    Ejecuta código Python arbitrario.
    
    ❌ VULNERABILIDAD CRÍTICA:
    - exec() con input de usuario
    """
    code = request.json.get('code')
    
    # ❌ VULNERABILIDAD 10: exec() ejecuta cualquier código
    exec(code)
    
    return jsonify({'message': 'Code executed'})


@app.route('/query', methods=['GET'])
def query_database():
    """
    Query a la base de datos.
    
    ❌ VULNERABILIDADES:
    - SQL injection en query params
    - No parameterized queries
    """
    table = request.args.get('table', 'customers')
    condition = request.args.get('where', '1=1')
    
    # ❌ VULNERABILIDAD 11: SQL injection en query params
    conn = sqlite3.connect('banking.db')
    query = f"SELECT * FROM {table} WHERE {condition}"
    
    try:
        cursor = conn.execute(query)
        results = cursor.fetchall()
        return jsonify({'results': results})
    except Exception as e:
        # ❌ VULNERABILIDAD 12: Exposing error details
        return jsonify({'error': str(e), 'query': query}), 500
    finally:
        conn.close()


def load_model_unsafe(path):
    """
    Carga modelo sin validación.
    
    ❌ VULNERABILIDAD:
    - No integrity check (hash, signature)
    - Pickle deserialization attack
    """
    with open(path, 'rb') as f:
        return pickle.load(f)


def get_customer_data(customer_id):
    """
    Obtiene datos de cliente.
    
    ❌ VULNERABILIDAD: SQL injection
    """
    conn = sqlite3.connect('banking.db')
    
    # ❌ String concatenation en SQL
    query = f"SELECT name, email, dni, account_number, balance FROM customers WHERE id = '{customer_id}'"
    
    cursor = conn.execute(query)
    result = cursor.fetchone()
    conn.close()
    
    return result


def validate_credentials(username, password):
    """
    Valida credenciales de usuario.
    
    ❌ VULNERABILIDADES:
    - Timing attack
    - No rate limiting
    - Weak password check
    """
    conn = sqlite3.connect('banking.db')
    
    # ❌ VULNERABILIDAD 13: SQL injection + timing attack
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
    cursor = conn.execute(query)
    user = cursor.fetchone()
    
    # ❌ Comparación directa (timing attack vulnerable)
    if user and user[2] == password:
        return True
    return False


# ❌ VULNERABILIDAD 14: Secrets en código
def connect_to_external_api():
    """Conecta a API externa con credenciales hardcoded."""
    import requests
    
    headers = {
        'Authorization': f'Bearer {API_SECRET_KEY}',
        'X-AWS-Access-Key': AWS_ACCESS_KEY
    }
    
    response = requests.get('https://api.external.com/data', headers=headers)
    return response.json()


# ❌ VULNERABILIDAD 15: Weak random
def generate_session_token():
    """Genera token de sesión con random débil."""
    import random
    
    # ❌ random.random() no es criptográficamente seguro
    token = ''.join([str(random.randint(0, 9)) for _ in range(16)])
    return token


if __name__ == '__main__':
    # ❌ VULNERABILIDAD 16: Running on 0.0.0.0 with debug
    app.run(host='0.0.0.0', port=5000, debug=True)
