# Java Examples - Vulnerable Banking API

Este directorio contiene ejemplos de código Java con **vulnerabilidades intencionales** para el Taller 7 de GitHub Advanced Security.

⚠️ **ADVERTENCIA:** Este código es VULNERABLE por diseño educativo. **NO USAR EN PRODUCCIÓN.**

## 📁 Contenido

### VulnerableBankingAPI.java
API REST bancaria implementada con Spring Boot que contiene **18 vulnerabilidades** de seguridad intencionales.

**Tecnologías:**
- Java 11
- Spring Boot 2.7.0
- MySQL Connector 5.1.46 (versión vulnerable)

**Vulnerabilidades incluidas:**

#### 🔐 Gestión de Credenciales
1. **Hardcoded Credentials** - Passwords y API keys en el código
2. **Información sensible en logs** - PIN y passwords en System.out

#### 💉 Injection Attacks
3. **SQL Injection** - Concatenación de strings en queries (línea 49)
4. **SQL Injection en login** - Bypass de autenticación con `' OR '1'='1` (línea 67)
5. **Command Injection** - Ejecución de comandos con input del usuario (línea 90)
6. **LDAP Injection** - Construcción de filtros LDAP sin validación (línea 220)
7. **XXE (XML External Entity)** - Parser XML sin protección (línea 231)

#### 🚪 Path Traversal & File Access
8. **Path Traversal** - Acceso a archivos con `../../etc/passwd` (línea 100)

#### 🔓 Insecure Deserialization
9. **Unsafe Deserialization** - ObjectInputStream sin validación (línea 115)

#### 🌐 Web Vulnerabilities
10. **XSS (Cross-Site Scripting)** - Output sin sanitizar (línea 128)
11. **SSRF (Server-Side Request Forgery)** - Requests a URLs del usuario (línea 244)

#### 🔒 Cryptography Issues
12. **Weak Cryptography** - MD5 para hashear passwords (línea 199)
13. **Weak Random** - Semilla hardcodeada en Random (línea 82)

#### 💸 Transaction Issues
14. **No usa transacciones** - Riesgo de perder dinero (línea 149)
15. **Race Condition** - Acceso concurrente a balance sin lock (línea 162)

#### 📊 Information Disclosure
16. **Debug endpoint** - Expone configuración completa (línea 264)

#### 💥 Denial of Service
17. **No valida tamaño de input** - OutOfMemoryError (línea 280)

## 🚀 Cómo Ejecutar

### Prerrequisitos

```bash
# Instalar Java 11+
java -version

# Instalar Maven
mvn -version
```

### Compilar

```bash
cd examples/java

# Compilar con Maven
mvn clean package

# O con wrapper (si existe)
./mvnw clean package
```

### Ejecutar

```bash
# Ejecutar con Maven
mvn spring-boot:run

# O ejecutar el JAR
java -jar target/vulnerable-banking-api-1.0-SNAPSHOT.jar
```

La API estará disponible en: http://localhost:8080

## 🧪 Probar Vulnerabilidades

### 1. SQL Injection

```bash
# Obtener todas las cuentas (bypass de seguridad)
curl "http://localhost:8080/api/account/1' OR '1'='1"

# Login sin password
curl -X POST "http://localhost:8080/api/login" \
  -d "username=admin' OR '1'='1&password=any"
```

### 2. Command Injection

```bash
# Inyectar comando malicioso
curl "http://localhost:8080/api/export/test;rm -rf /"
```

### 3. Path Traversal

```bash
# Acceder a archivos del sistema
curl "http://localhost:8080/api/download/../../etc/passwd"
```

### 4. XSS

```bash
# Inyectar JavaScript
curl "http://localhost:8080/api/profile/<script>alert('XSS')</script>"
```

### 5. SSRF

```bash
# Acceder a recursos internos
curl "http://localhost:8080/api/fetch?url=http://localhost:8080/debug/config"
```

### 6. Information Disclosure

```bash
# Ver credenciales hardcodeadas
curl "http://localhost:8080/api/debug/config"
```

## 🔍 Detección con CodeQL

### Configurar CodeQL en GitHub Actions

```yaml
name: "CodeQL Analysis"

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  analyze:
    name: Analyze Java
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout repository
      uses: actions/checkout@v3
      
    - name: Set up Java
      uses: actions/setup-java@v3
      with:
        java-version: '11'
        distribution: 'temurin'
        
    - name: Initialize CodeQL
      uses: github/codeql-action/init@v2
      with:
        languages: java
        queries: security-and-quality
        
    - name: Build with Maven
      run: |
        cd examples/java
        mvn clean package -DskipTests
        
    - name: Perform CodeQL Analysis
      uses: github/codeql-action/analyze@v2
```

### Ejecutar CodeQL Localmente

```bash
# Instalar CodeQL CLI
choco install codeql

# Crear database
codeql database create java-db --language=java \
  --command="mvn clean package -DskipTests"

# Ejecutar queries de seguridad
codeql database analyze java-db \
  --format=sarif-latest \
  --output=results.sarif \
  codeql/java-queries:codeql-suites/java-security-and-quality.qls

# Ver resultados
codeql bqrs decode java-db/results/*.bqrs --format=text
```

## 📋 Vulnerabilidades Detectables por CodeQL

| Vulnerabilidad | CWE | Severidad | Query CodeQL |
|----------------|-----|-----------|--------------|
| SQL Injection | CWE-89 | Alta | `java/sql-injection` |
| Command Injection | CWE-78 | Crítica | `java/command-injection` |
| Path Traversal | CWE-22 | Alta | `java/path-injection` |
| Hardcoded Credentials | CWE-798 | Media | `java/hardcoded-credential-api-call` |
| Weak Crypto | CWE-327 | Media | `java/weak-cryptographic-algorithm` |
| XSS | CWE-79 | Media | `java/xss` |
| XXE | CWE-611 | Alta | `java/xxe` |
| Unsafe Deserialization | CWE-502 | Crítica | `java/unsafe-deserialization` |
| SSRF | CWE-918 | Alta | `java/ssrf` |
| LDAP Injection | CWE-90 | Alta | `java/ldap-injection` |

## 🛠️ Remediación

Para cada vulnerabilidad detectada, CodeQL proporcionará:
- Descripción del problema
- Ubicación exacta en el código
- Recomendaciones de remediación
- Links a documentación (CWE, OWASP)

### Ejemplo: Remediación de SQL Injection

**Código vulnerable:**
```java
String query = "SELECT * FROM accounts WHERE user_id = '" + userId + "'";
Statement stmt = conn.createStatement();
ResultSet rs = stmt.executeQuery(query);
```

**Código seguro:**
```java
String query = "SELECT * FROM accounts WHERE user_id = ?";
PreparedStatement stmt = conn.prepareStatement(query);
stmt.setString(1, userId);
ResultSet rs = stmt.executeQuery();
```

## 📚 Recursos Adicionales

- [CodeQL for Java](https://codeql.github.com/docs/codeql-language-guides/codeql-for-java/)
- [Java Security Queries](https://github.com/github/codeql/tree/main/java/ql/src/Security)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [CWE Top 25](https://cwe.mitre.org/top25/)

## 🎯 Objetivos de Aprendizaje

Al completar este ejercicio, los participantes podrán:
1. ✅ Identificar 18 tipos de vulnerabilidades en código Java
2. ✅ Configurar CodeQL para análisis automático
3. ✅ Interpretar resultados de CodeQL
4. ✅ Aplicar remediaciones seguras
5. ✅ Integrar análisis de seguridad en CI/CD

---

**Nota:** Este código está diseñado exclusivamente para propósitos educativos. Todas las vulnerabilidades son intencionales y sirven para demostrar las capacidades de detección de GitHub Advanced Security.
