# 📚 Librería de Prompts PACES - GitHub Advanced Security (GHAS)

**Descripción:** Colección de prompts efectivos para implementar seguridad con GHAS  
**Objetivo:** Usar prompts listos para producción en Copilot Chat  
**Tecnologías:** CodeQL, Dependabot, Secret Scanning, Copilot Autofix  
**Audiencias:** QE (Quality Engineering) y DS (Data Science)

---

## 🎯 CÓMO USAR ESTA LIBRERÍA

1. **Identifica tu rol** (QE o DS) y busca prompts relevantes
2. **Busca el prompt** por categoría (CodeQL, Dependencies, Secrets, etc.)
3. **Copia el prompt completo** (incluye PACES)
4. **Pega en Copilot Chat** (`Ctrl + Shift + I`)
5. **Reemplaza [PLACEHOLDER]** con tu contenido específico
6. **Personaliza** Audiencia y Contexto según tu caso

---

## 📊 TABLA DE CONTENIDOS

| # | Categoría | Prompt | Audiencia | Duración | Nivel |
|---|-----------|--------|-----------|----------|-------|
| **PARA QE** |
| 1.0 | CODEQL | Setup CodeQL Básico | QE | 10 min | Principiante |
| 1.1 | CODEQL | Análisis de Alertas QE | QE | 15 min | Intermedio |
| 1.2 | CODEQL | Custom Queries API Testing | QE | 20 min | Avanzado |
| 2.0 | DEPENDENCIES | Configurar Dependabot | QE | 10 min | Principiante |
| 2.1 | DEPENDENCIES | Quality Gates de Deps | QE | 15 min | Intermedio |
| 3.0 | SECURITY TESTING | Tests de Seguridad Postman | QE | 20 min | Intermedio |
| 3.1 | SECURITY TESTING | OWASP Top 10 Automation | QE | 25 min | Avanzado |
| 4.0 | GATES | Security Gates Evaluator | QE | 15 min | Intermedio |
| 5.0 | REPORTING | Executive Security Report | QE | 10 min | Intermedio |
| **PARA DS** |
| 6.0 | CODEQL | Setup CodeQL para ML | DS | 15 min | Intermedio |
| 6.1 | CODEQL | Queries Custom ML | DS | 20 min | Avanzado |
| 7.0 | FAIRNESS | Detectar Bias en Modelos | DS | 20 min | Intermedio |
| 7.1 | FAIRNESS | Mitigar Bias | DS | 25 min | Avanzado |
| 8.0 | EXPLAINABILITY | Implementar SHAP | DS | 20 min | Intermedio |
| 8.1 | EXPLAINABILITY | Model Lineage | DS | 15 min | Avanzado |
| 9.0 | SECRETS | Limpiar Notebooks | DS | 15 min | Intermedio |
| 10.0 | GOVERNANCE | ML Pipeline Security | DS | 25 min | Avanzado |
| **COMPARTIDOS** |
| 11.0 | SECRETS | Secret Scanning Setup | Ambos | 10 min | Principiante |
| 12.0 | COMPLIANCE | Compliance Checker | Ambos | 20 min | Avanzado |

---

## 🔒 SECCIÓN QE (Quality Engineering)

### 1.0 - CODEQL SETUP BÁSICO (QE)

**Cuando usarlo:** Primera configuración de CodeQL para testing  
**Tiempo:** 10 minutos  
**Output:** Workflow YAML ejecutable

```markdown
PROPÓSITO: Configurar CodeQL para detectar vulnerabilidades en APIs bancarias
AUDIENCIA: QE que configura seguridad en CI/CD por primera vez
CONTEXTO: Proyecto Python/JavaScript, APIs REST, necesito detectar SQL injection, XSS, etc.
EJEMPLOS: Push código → CodeQL analiza → Alertas en PR → Bloquea merge si CRITICAL
SCOPE: Workflow YAML completo, queries security-extended, integración con PR checks

---

Crea workflow de CodeQL para proyecto de testing:

REQUISITOS:
1️⃣ Triggers
   - push a [BRANCHES: main, develop]
   - pull_request a main
   - schedule: [HORA: 2 AM] análisis diario

2️⃣ Lenguajes
   - [LENGUAJES: python, javascript]

3️⃣ Queries
   - security-extended (incluye OWASP Top 10)
   - security-and-quality (más cobertura)

4️⃣ Exclusiones
   - node_modules/
   - venv/
   - tests/fixtures/
   - mock-data/

5️⃣ Configuración
   - Subir resultados a GitHub Security
   - Generar SARIF para integración
   - Fallar build si hay vulnerabilidades CRITICAL
   - Notificar en [CANAL: Slack/Teams] si falla

6️⃣ Comentarios en español explicando cada step

ENTREGA: Archivo .github/workflows/codeql-analysis.yml completo y funcional
```

---

### 1.1 - ANÁLISIS DE ALERTAS CODEQL (QE)

**Cuando usarlo:** Entender y documentar alertas de CodeQL  
**Tiempo:** 15 minutos  
**Output:** Documento de análisis + test cases

```markdown
PROPÓSITO: Analizar alerta de CodeQL desde perspectiva de QE
AUDIENCIA: QE que necesita entender impacto funcional de vulnerabilidades
CONTEXTO: Alerta de [TIPO: SQL Injection] en endpoint [ENDPOINT: /api/login]
EJEMPLOS: Alerta técnica → Impacto en negocio → Test case para validar
SCOPE: Explicación simple, escenario de explotación, test case Gherkin

---

Analiza esta alerta de CodeQL:

[PEGA LA ALERTA COMPLETA AQUÍ]

ANÁLISIS REQUERIDO:
1️⃣ Explicación Simple
   - ¿Qué es esta vulnerabilidad? (sin jerga técnica)
   - ¿Cómo funciona el ataque?

2️⃣ Impacto en Negocio Bancario
   - ¿Qué puede hacer un atacante?
   - ¿Qué datos están en riesgo?
   - ¿Cómo afecta a clientes?
   - Severidad real: CRÍTICA/ALTA/MEDIA/BAJA

3️⃣ Escenario de Explotación
   - Request malicioso paso a paso
   - Response esperado si vulnerable
   - Código de ejemplo del ataque

4️⃣ Test Case de Validación
   - Formato Gherkin (Given/When/Then)
   - Test para confirmar vulnerabilidad
   - Test para validar que fix funciona

5️⃣ Recomendación de Remediación
   - ¿Cómo corregir? (para desarrolladores)
   - ¿Cómo validar el fix? (para QE)
   - Regresión tests a agregar

FORMATO: Markdown con código ejecutable en Postman/Newman
```

---

### 2.0 - CONFIGURAR DEPENDABOT (QE)

**Cuando usarlo:** Monitorear vulnerabilidades en dependencias  
**Tiempo:** 10 minutos  
**Output:** Archivo dependabot.yml

```markdown
PROPÓSITO: Configurar Dependabot para monitoreo de dependencias de testing
AUDIENCIA: QE configurando seguridad de supply chain
CONTEXTO: Proyecto con [LENGUAJE: Python/Node.js], dependencies en [ARCHIVO: requirements.txt/package.json]
EJEMPLOS: Librería vulnerable detectada → PR automático → Review y merge
SCOPE: dependabot.yml funcional con auto-merge de security patches

---

Crea configuración de Dependabot:

REQUISITOS:
1️⃣ Ecosistema
   - [ECOSISTEMA: pip, npm, etc.]
   - Directorio: [DIRECTORIO: / o /tests]

2️⃣ Schedule
   - [FRECUENCIA: daily, weekly, monthly]
   - Timezone: [ZONA: America/Lima]
   - Hora: [HORA: 00:00]

3️⃣ Grupos de dependencias
   - testing-tools: pytest, newman, etc.
   - security-libs: cryptography, jwt, etc.
   - frameworks: flask, express, etc.

4️⃣ Auto-merge rules
   - Security patches: siempre
   - Patch updates: solo si tests pasan
   - Minor/Major: review manual

5️⃣ Configuración
   - Revisores: [EQUIPO: @mi-banco-qe-team]
   - Labels: dependencies, security, [AREA]
   - Límite PRs abiertos: [NUMERO: 5]
   - Prefijo commits: "chore(deps):"

6️⃣ Alerts
   - Severity threshold: [NIVEL: medium]
   - Notificar: [CANAL: Slack]

ENTREGA: .github/dependabot.yml completo
```

---

### 2.1 - QUALITY GATES DE DEPENDENCIAS (QE)

**Cuando usarlo:** Automatizar validación de dependencias en PR  
**Tiempo:** 15 minutos  
**Output:** Script Python ejecutable

```markdown
PROPÓSITO: Crear quality gate que valide dependencias en PRs
AUDIENCIA: QE automatizando security gates
CONTEXTO: CI/CD bancario, necesito bloquear PRs con dependencias vulnerables
EJEMPLOS: PR con librería vulnerable → Gate FAIL → PR bloqueado hasta remediar
SCOPE: Script Python con exit codes, consulta GitHub API, integrable en workflow

---

Crea scripts/validate-dependencies.py:

VALIDACIONES:
1️⃣ Vulnerabilidades conocidas
   - Consultar GitHub Dependency Graph API
   - Obtener vulnerabilidades por severidad
   - Clasificar: CRITICAL, HIGH, MEDIUM, LOW

2️⃣ Gate Rules
   - CRITICAL: 0 permitidas → EXIT 1 (FAIL)
   - HIGH: 0 permitidas → EXIT 1 (FAIL)
   - MEDIUM: max [NUMERO: 2] → EXIT 2 (WARNING)
   - LOW: reportar solo → EXIT 0

3️⃣ Licencias
   - Validar contra allowlist: [LICENCIAS: MIT, Apache-2.0, BSD]
   - Bloquear copyleft: GPL si no es compatible
   - EXIT 1 si licencia no permitida

4️⃣ Dependency Confusion
   - Verificar que packages vienen de registry oficial
   - Detectar typosquatting (nombres similares)
   - Alertar si package es nuevo (<30 días)

5️⃣ Output
   - JSON con resultados detallados
   - Tabla Markdown para PR comment
   - GitHub Actions outputs (::set-output)
   - Métricas: vulnerabilidades por severidad

REQUISITOS:
- Argumentos: --file requirements.txt, --threshold medium
- Usar GitHub REST API (token desde env)
- Timeout 60 segundos
- Retry con backoff si API falla
- Cache de resultados (24h)
- Comentarios en español

ENTREGA: Script Python completo + ejemplo de uso
```

---

### 3.0 - TESTS DE SEGURIDAD POSTMAN (QE)

**Cuando usarlo:** Crear suite de security tests  
**Tiempo:** 20 minutos  
**Output:** Colección Postman con tests

```markdown
PROPÓSITO: Crear tests de seguridad para APIs bancarias usando Postman
AUDIENCIA: QE creando security test cases automáticos
CONTEXTO: APIs REST de [PROYECTO: Mi Banco], necesito validar OWASP Top 10
EJEMPLOS: Test funcional de login → Test de SQL injection en login
SCOPE: Colección Postman v2.1 con 15+ security tests, ejecutable con Newman

---

Genera colección Postman de security testing:

VULNERABILIDADES A TESTEAR:
1️⃣ Injection Attacks
   - SQL Injection en parámetros: [ENDPOINTS]
   - NoSQL Injection
   - Command Injection
   - LDAP Injection

2️⃣ Broken Authentication
   - Brute force protection
   - Weak passwords acceptance
   - Session fixation
   - Missing JWT validation

3️⃣ Sensitive Data Exposure
   - PII en responses
   - Error messages con stack traces
   - Debug info en headers
   - Unencrypted transmissions

4️⃣ XML External Entities (XXE)
   - XML parsing vulnerabilities
   - File disclosure via XXE

5️⃣ Broken Access Control
   - IDOR (Insecure Direct Object Reference)
   - Missing authorization
   - Path traversal
   - Forced browsing

6️⃣ Security Misconfiguration
   - Default credentials
   - Unnecessary HTTP methods
   - Missing security headers
   - CORS misconfiguration

7️⃣ Cross-Site Scripting (XSS)
   - Reflected XSS
   - Stored XSS
   - DOM-based XSS

8️⃣ Insecure Deserialization
   - Unsafe object deserialization

9️⃣ Using Components with Known Vulnerabilities
   - Outdated libraries detection

🔟 Insufficient Logging & Monitoring
   - Verificar que se loguean intentos maliciosos

PARA CADA TEST:
- Request con payload malicioso específico
- Pre-request script (si necesario)
- Test script que valida:
  ```javascript
  pm.test("Should block SQL injection", function() {
      pm.response.to.have.status(400);
      pm.response.to.not.have.jsonBody("users");
  });
  ```
- Assertions esperadas (lo que NO debe pasar)
- Documentación del test

CONFIGURACIÓN:
- Environment variables para URLs
- Datos de test en variables
- Tokens/auth en environment

ENTREGA: Colección JSON Postman v2.1 importable
```

---

### 4.0 - SECURITY GATES EVALUATOR (QE)

**Cuando usarlo:** Automatizar decisiones de merge basadas en seguridad  
**Tiempo:** 15 minutos  
**Output:** Script Python con exit codes

```markdown
PROPÓSITO: Crear evaluador de security gates para CI/CD bancario
AUDIENCIA: QE automatizando control de calidad y seguridad
CONTEXTO: Banco regulado, gates críticos: vulnerabilidades, secrets, compliance
EJEMPLOS: JSON results → evaluación → PASS/FAIL → exit code → bloquea/permite merge
SCOPE: Script Python con 6+ gates, reporte JSON, exit codes, GitHub API

---

Crea scripts/evaluate-security-gates.py:

GATES REQUERIDOS:
1️⃣ codeql_vulnerabilities
   - Threshold CRITICAL: 0
   - Threshold HIGH: 0
   - Threshold MEDIUM: max [NUMERO: 2]
   - Bloquea merge: SÍ si CRITICAL/HIGH
   - Input: GitHub API CodeQL alerts

2️⃣ dependency_vulnerabilities
   - Threshold CRITICAL: 0
   - Threshold HIGH: 0
   - Bloquea merge: SÍ
   - Input: Dependabot alerts API

3️⃣ secrets_exposed
   - Threshold: 0 secrets
   - Bloquea merge: SÍ
   - Input: Secret scanning API
   - Excluir: test fixtures, mock data

4️⃣ security_tests_passing
   - Threshold: 100% tests pasados
   - Min tests: [NUMERO: 10]
   - Bloquea merge: SÍ
   - Input: Newman/test results JSON

5️⃣ compliance_checks
   - SBS requirements: 100%
   - PCI DSS: requeridos si procesa pagos
   - GDPR: si maneja PII
   - Bloquea merge: SÍ
   - Input: compliance scan results

6️⃣ auth_security
   - Tests de autenticación: 100% OK
   - JWT validation: presente
   - Rate limiting: habilitado
   - Bloquea merge: NO (warning)
   - Input: auth test results

7️⃣ audit_logging
   - Logging de operaciones críticas: presente
   - PII no logueado: validado
   - Bloquea merge: NO (warning)
   - Input: code analysis

REQUISITOS:
- Argumentos: --github-token, --repo, --pr-number
- Leer datos de GitHub REST API
- Evaluar cada gate con lógica específica
- Mostrar en consola: ✅/❌/⚠️ por gate
- Generar JSON detallado: reports/security-gates.json
- Exit codes:
  * 0: Todos OK
  * 1: Al menos un gate FAIL (bloquea merge)
  * 2: Warnings pero no bloqueantes
- Comentar en PR con resumen tabla Markdown
- Métricas: tiempo de evaluación, gates passed/failed

FORMATO OUTPUT:
```json
{
  "timestamp": "2024-12-08T...",
  "pr_number": 123,
  "overall_status": "FAIL",
  "can_merge": false,
  "gates": [
    {
      "name": "codeql_vulnerabilities",
      "status": "FAIL",
      "blocking": true,
      "details": {
        "critical": 1,
        "high": 0,
        "threshold_critical": 0
      },
      "message": "1 vulnerabilidad CRITICAL encontrada",
      "remediation": "Revisar alertas en Security tab"
    }
  ]
}
```

ENTREGA: Script Python ejecutable con clase SecurityGateEvaluator
```

---

### 5.0 - EXECUTIVE SECURITY REPORT (QE)

**Cuando usarlo:** Traducir métricas de seguridad para stakeholders  
**Tiempo:** 10 minutos  
**Output:** Script generador de reporte Markdown

```markdown
PROPÓSITO: Crear reporte ejecutivo de seguridad para stakeholders
AUDIENCIA: QE Manager, Security Officer, CTO, Auditoría
CONTEXTO: Resultados de CodeQL, Dependabot, Security tests, necesitan insight de riesgo
EJEMPLOS: "5 vulnerabilities" → "Riesgo ALTO: Datos de clientes expuestos"
SCOPE: Script Python, output Markdown, recomendaciones de deploy

---

Crea scripts/generate-security-report.py:

SECCIONES REQUERIDAS:
1️⃣ Resumen Ejecutivo
   - Estado general: 🟢 BAJO / 🟡 MEDIO / 🟠 ALTO / 🔴 CRÍTICO
   - Tabla con métricas clave:
     | Métrica | Valor | Threshold | Status |
   - Vulnerabilidades críticas: número y tipo
   - Recomendación principal: DEPLOY / HOLD / BLOCK

2️⃣ Análisis de Vulnerabilidades
   - Por severidad: gráfico de barras ASCII
   - Por tipo: Injection, Auth, XSS, etc.
   - Top 5 más críticas con impacto de negocio
   - Tendencia: mejorando/empeorando vs última semana

3️⃣ Estado de Dependencias
   - Total dependencias: [NUMERO]
   - Vulnerables: [NUMERO] ([PORCENTAJE]%)
   - Actualizadas últimos 30 días: [NUMERO]
   - Licencias problemáticas: [NUMERO]

4️⃣ Security Testing Results
   - Tests ejecutados: [NUMERO]
   - Tests pasados: [NUMERO] ([PORCENTAJE]%)
   - Vulnerabilidades encontradas: por tipo
   - Coverage de OWASP Top 10: [PORCENTAJE]%

5️⃣ Compliance Status
   - SBS: ✅/❌ + detalles
   - PCI DSS: ✅/❌ + detalles
   - GDPR: ✅/❌ + detalles
   - Auditoría lista: SÍ/NO

6️⃣ Impacto en Negocio
   - Riesgo de exposición de datos: BAJO/MEDIO/ALTO
   - Potencial impacto financiero: [ESTIMADO]
   - Riesgo reputacional: BAJO/MEDIO/ALTO
   - Riesgo regulatorio: BAJO/MEDIO/ALTO

7️⃣ Recomendación de Deploy
   - ✅ SEGURO PARA DEPLOY
     * Justificación en 3 puntos
     * Próximos pasos
   - ⚠️ DEPLOY CON PRECAUCIÓN
     * Issues no bloqueantes
     * Monitoreo adicional requerido
   - ❌ NO SEGURO PARA DEPLOY
     * Issues críticos a resolver
     * Tiempo estimado de remediación
     * Siguiente acción

8️⃣ Items Accionables (Top 5)
   - Lista priorizada de acciones
   - Owner sugerido
   - Tiempo estimado
   - Impacto si no se resuelve

9️⃣ Métricas de Progreso
   - Vulnerabilidades corregidas esta semana: [NUMERO]
   - Mean Time To Remediation (MTTR): [DIAS]
   - Security debt: [HORAS] de remediación pendiente

FORMATO:
- Markdown compatible con GitHub
- Emojis para visualización (🟢🟡🟠🔴✅❌⚠️)
- Tablas para métricas
- Gráficos ASCII simples
- Links a Security tab para detalles
- NO usar jerga técnica compleja

REQUISITOS:
- Input: JSON de CodeQL, Dependabot, tests
- Generar: reports/security-executive-report.md
- Incluir timestamp y metadata
- PDF export opcional (usando markdown-pdf)

ENTREGA: Script Python con clase SecurityReportGenerator
```

---

## 🤖 SECCIÓN DS (Data Science)

### 6.0 - CODEQL SETUP PARA ML (DS)

**Cuando usarlo:** Configurar análisis de seguridad para proyectos ML  
**Tiempo:** 15 minutos  
**Output:** Workflow YAML + queries custom

```markdown
PROPÓSITO: Configurar CodeQL específico para Data Science y ML
AUDIENCIA: Data Scientist configurando seguridad en notebooks y modelos
CONTEXTO: Proyecto Python con notebooks, pandas, scikit-learn, [FRAMEWORK: tensorflow/pytorch]
EJEMPLOS: Detectar pickle inseguro, eval() en notebooks, SQL injection en pandas
SCOPE: Workflow YAML + custom queries para vulnerabilidades específicas de ML

---

Crea workflow CodeQL optimizado para Data Science:

REQUISITOS:
1️⃣ Triggers
   - push a [BRANCHES: main, develop]
   - pull_request a main
   - schedule: [HORA: 3 AM] análisis nocturno

2️⃣ Lenguaje
   - Python con foco en librerías DS

3️⃣ Paths a analizar
   - src/models/
   - notebooks/ (si están en repo)
   - scripts/
   - Incluir .ipynb como Python

4️⃣ Exclusiones
   - .ipynb_checkpoints/
   - data/
   - datasets/
   - *.pkl (model artifacts)
   - *.h5 (keras models)
   - venv/

5️⃣ Queries específicas DS
   - Insecure deserialization (pickle.load sin validar)
   - Use of eval/exec (común en notebooks)
   - SQL injection en pandas.read_sql
   - Hardcoded secrets en notebooks
   - Unvalidated user input en modelos
   - Missing random seeds (reproducibilidad)
   - PII leakage en logs/prints

6️⃣ Custom queries (crear archivo .ql)
   Para cada vulnerabilidad específica ML

7️⃣ Configuración avanzada
   - Upload SARIF a GitHub Security
   - Generar reporte específico DS
   - Notificar en [CANAL] si CRITICAL
   - Integrar con model registry

ENTREGA:
- .github/workflows/codeql-ds-analysis.yml
- .github/codeql/codeql-config.yml (opcional)
- queries/ml-security.ql (queries custom)
```

---

### 7.0 - DETECTAR BIAS EN MODELOS (DS)

**Cuando usarlo:** Validar fairness de modelos ML  
**Tiempo:** 20 minutos  
**Output:** Script de análisis de bias

```markdown
PROPÓSITO: Detectar y medir bias en modelo de [TIPO: credit scoring / fraud detection]
AUDIENCIA: Data Scientist validando fairness y cumplimiento regulatorio
CONTEXTO: Modelo [NOMBRE] para banca, grupos protegidos: género, edad, zona geográfica
EJEMPLOS: Modelo rechaza más mujeres que hombres con mismo perfil → Disparate impact
SCOPE: Script Python que calcula 5+ métricas de fairness con visualizaciones

---

Crea scripts/detect-model-bias.py:

MÉTRICAS DE FAIRNESS:
1️⃣ Disparate Impact (DI)
   - Ratio de positive outcomes entre grupos
   - Fórmula: P(Y=1|A=unprivileged) / P(Y=1|A=privileged)
   - Threshold: 0.8 ≤ DI ≤ 1.25 (regla 80%)
   - Grupos protegidos: [ATRIBUTOS: gender, age, region]

2️⃣ Equal Opportunity Difference
   - Diferencia en True Positive Rate entre grupos
   - Fórmula: TPR_unprivileged - TPR_privileged
   - Threshold: |difference| < 0.10

3️⃣ Average Odds Difference
   - Promedio de diferencias en TPR y FPR
   - Threshold: |difference| < 0.10

4️⃣ Statistical Parity Difference
   - Diferencia en positive rate entre grupos
   - Threshold: |difference| < 0.10

5️⃣ Theil Index
   - Medida de desigualdad entre grupos
   - Threshold: < 0.1

ANÁLISIS POR GRUPO:
- Calcular métricas para cada atributo protegido
- Interseccionalidad: combinaciones (ej: mujer + joven)
- Visualizaciones:
  * Bar charts de métricas por grupo
  * Confusion matrices por grupo
  * Distribution plots de scores

VALIDACIONES:
- P-value < 0.05 indica bias significativo
- Bootstrap confidence intervals
- Multiple testing correction (Bonferroni)

REQUISITOS:
- Input: --model [PATH], --data [PATH], --protected-attributes [LIST]
- Usar fairlearn o aequitas library
- Generar reporte HTML interactivo
- Exportar métricas a JSON
- Exit codes:
  * 0: No bias detectado
  * 1: Bias encontrado (viola thresholds)
  * 2: Bias marginal (cerca de thresholds)
- Logging de análisis completo

OUTPUT STRUCTURE:
```json
{
  "overall_fairness": "BIASED",
  "metrics": {
    "disparate_impact": {
      "gender": {"M": 1.0, "F": 0.65, "threshold": 0.8, "status": "FAIL"},
      "age": {...}
    },
    "equal_opportunity": {...}
  },
  "recommendations": [
    "Reweighting: aumentar peso de grupo F",
    "Threshold optimization: ajustar threshold por grupo"
  ]
}
```

ENTREGA: Script Python con clase BiasDetector + notebook de ejemplo
```

---

### 7.1 - MITIGAR BIAS (DS)

**Cuando usarlo:** Corregir bias detectado en modelos  
**Tiempo:** 25 minutos  
**Output:** Código de mitigación ejecutable

```markdown
PROPÓSITO: Mitigar bias detectado en modelo manteniendo performance
AUDIENCIA: Data Scientist aplicando técnicas de fairness
CONTEXTO: Bias detectado con disparate impact de [VALOR], necesito corregir
EJEMPLOS: Reweighting, threshold optimization, adversarial debiasing
SCOPE: Código ejecutable que reduce bias, métricas antes/después

---

Genera código de mitigación para bias en [MODELO]:

TÉCNICAS A IMPLEMENTAR:
1️⃣ Reweighting (Pre-processing)
   - Ajustar pesos de training samples
   - Balancear representación de grupos
   - Preservar distribución original lo más posible

2️⃣ Resampling (Pre-processing)
   - Oversampling de grupo underrepresented
   - Undersampling de grupo overrepresented
   - SMOTE si es necesario

3️⃣ Threshold Optimization (Post-processing)
   - Diferentes thresholds por grupo protegido
   - Optimizar para equalized odds
   - Mantener accuracy global > [THRESHOLD]%

4️⃣ Adversarial Debiasing (In-processing)
   - Red adversaria que intenta predecir grupo protegido
   - Penalizar predicciones que revelan grupo
   - Lambda parameter para balance fairness/accuracy

5️⃣ Fairness Constraints (In-processing)
   - Agregar constraints al entrenamiento
   - Demographic parity o equalized odds
   - Usar fairlearn, aif360

REQUISITOS:
- Código Python completo para cada técnica
- Comparación de métricas:
  ```python
  results = {
      "baseline": {
          "accuracy": 0.85,
          "disparate_impact": 0.65,
          "equal_opportunity_diff": 0.15
      },
      "reweighting": {...},
      "threshold_opt": {...},
      "adversarial": {...}
  }
  ```
- Visualizar trade-off: accuracy vs fairness
- Notebook ejecutable con explicaciones
- Recomendación final de técnica a usar

TRADE-OFF ANALYSIS:
- Accuracy no debe bajar más de [PORCENTAJE: 5]%
- Fairness debe mejorar significativamente
- Complejidad de implementación
- Interpretabilidad del modelo

VALIDACIÓN:
- Re-calcular todas las métricas de fairness
- Validar en dataset de test independiente
- Cross-validation con grupos balanceados
- Verificar que bias no se transfirió a otro grupo

ENTREGA: Notebook Jupyter con 4 técnicas implementadas y comparadas
```

---

### 8.0 - IMPLEMENTAR EXPLICABILIDAD CON SHAP (DS)

**Cuando usarlo:** Agregar explicabilidad a modelos ML  
**Tiempo:** 20 minutos  
**Output:** Código de explicabilidad ejecutable

```markdown
PROPÓSITO: Implementar explicabilidad en modelo [TIPO] usando SHAP
AUDIENCIA: Data Scientist cumpliendo con right-to-explanation (GDPR/SBS)
CONTEXTO: Modelo [NOMBRE] debe explicar decisiones a clientes y auditores
EJEMPLOS: "Crédito rechazado porque: ingresos (35%), historial (30%), deuda (25%)"
SCOPE: Integración de SHAP en pipeline, API de explicaciones, visualizaciones

---

Crea scripts/explain-model.py con SHAP:

IMPLEMENTACIÓN:
1️⃣ Setup de SHAP Explainer
   - Elegir tipo: TreeExplainer, KernelExplainer, LinearExplainer
   - Para [TIPO_MODELO: sklearn/xgboost/neural net]
   - Background dataset: [N_SAMPLES: 100] representativo

2️⃣ Explicaciones Globales
   - SHAP summary plot (importancia de features)
   - SHAP dependence plots (relación feature-prediction)
   - Feature importance ranking
   - Interacciones entre features

3️⃣ Explicaciones Locales (por predicción)
   - SHAP waterfall plot (contribución de cada feature)
   - Force plot (visualización de fuerzas)
   - Decision plot
   - Individual feature contributions

4️⃣ Traducción a Lenguaje Natural
   ```python
   def explain_in_plain_language(shap_values, feature_names, prediction):
       explanation = f"Predicción: {prediction}\n\n"
       explanation += "Factores principales:\n"
       
       # Top 3 features positivos
       top_positive = shap_values.top_positive(3)
       for feature, value in top_positive:
           explanation += f"  ✅ {feature}: incrementó probabilidad en {value*100:.1f}%\n"
       
       # Top 3 features negativos
       top_negative = shap_values.top_negative(3)
       for feature, value in top_negative:
           explanation += f"  ❌ {feature}: redujo probabilidad en {abs(value)*100:.1f}%\n"
       
       return explanation
   ```

5️⃣ Exportar Explicaciones
   - JSON para API
   ```json
   {
     "prediction": 0.75,
     "prediction_label": "APPROVED",
     "explanation": {
       "top_features": [
         {"feature": "income", "contribution": 0.25, "direction": "positive"},
         {"feature": "credit_history", "contribution": 0.18, "direction": "positive"}
       ],
       "base_value": 0.50,
       "natural_language": "..."
     }
   }
   ```
   - HTML para auditoría
   - PDF para cliente (con gráficos)

6️⃣ Validación de Explicaciones
   - Sumar SHAP values debe ≈ prediction
   - Consistencia: mismos inputs → mismas explicaciones
   - Completeness: todas las features relevantes incluidas
   - Plausibilidad: explicaciones tienen sentido de negocio

INTEGRACIÓN CON API:
```python
@app.route('/predict-explain', methods=['POST'])
def predict_with_explanation():
    data = request.json
    
    # Predecir
    prediction = model.predict_proba([data])[0][1]
    
    # Explicar con SHAP
    shap_values = explainer.shap_values(data)
    explanation = generate_explanation(shap_values, feature_names)
    
    return {
        'prediction': float(prediction),
        'label': 'APPROVED' if prediction > 0.5 else 'REJECTED',
        'confidence': float(abs(prediction - 0.5) * 2),
        'explanation': explanation,
        'metadata': {
            'model_version': MODEL_VERSION,
            'timestamp': datetime.now().isoformat()
        }
    }
```

REQUISITOS:
- Compatible con [MODELO_TIPO]
- Performance: explicación en < [TIEMPO: 200]ms
- Cacheable para requests repetidos
- Logging de explicaciones para auditoría
- Unit tests para validar explicaciones

ENTREGA: Script + API endpoint + notebook de ejemplos
```

---

### 9.0 - LIMPIAR SECRETS DE NOTEBOOKS (DS)

**Cuando usarlo:** Evitar exponer credenciales en notebooks  
**Tiempo:** 15 minutos  
**Output:** Pre-commit hook ejecutable

```markdown
PROPÓSITO: Detectar y eliminar secrets de notebooks antes de commit
AUDIENCIA: Data Scientist evitando exponer API keys, passwords, tokens
CONTEXTO: Notebooks Jupyter con [TIPO_SECRETS: AWS keys, DB passwords, API tokens] hardcoded
EJEMPLOS: API_KEY = "sk-abc123" → API_KEY = os.getenv("OPENAI_API_KEY")
SCOPE: Pre-commit hook que escanea notebooks, script de limpieza, migración a env vars

---

Crea scripts/clean-notebook-secrets.py:

DETECCIÓN DE SECRETS:
1️⃣ Patterns de API Keys
   - AWS: AKIA[0-9A-Z]{16}
   - OpenAI: sk-[a-zA-Z0-9]{48}
   - Stripe: (sk|pk)_(test|live)_[a-zA-Z0-9]{24}
   - Google: AIza[0-9A-Za-z_-]{35}
   - GitHub: ghp_[a-zA-Z0-9]{36}
   - Custom: [PATTERN_CUSTOM]

2️⃣ Passwords y Tokens
   ```python
   # Regex patterns
   password_pattern = r'(password|passwd|pwd)\s*=\s*["\'][^"\']+["\']'
   token_pattern = r'(token|auth_token|access_token)\s*=\s*["\'][^"\']+["\']'
   api_key_pattern = r'(api_key|apikey|api_secret)\s*=\s*["\'][^"\']+["\']'
   ```

3️⃣ Connection Strings
   - Database URLs: postgres://user:pass@host/db
   - MongoDB: mongodb://user:pass@host:port/db
   - Redis: redis://:password@host:port
   - S3: s3://bucket?aws_access_key_id=...

4️⃣ PII (Datos Personales)
   - Emails: regex de emails
   - Phone numbers: +51 XXX XXX XXX
   - DNI/RUC: patrones peruanos
   - Account numbers: [PATTERN]

ACCIONES DE LIMPIEZA:
1️⃣ Reemplazar con env vars
   ```python
   # Antes
   API_KEY = "sk-abc123xyz789"
   
   # Después
   import os
   from dotenv import load_dotenv
   load_dotenv()
   API_KEY = os.getenv("OPENAI_API_KEY")
   if not API_KEY:
       raise ValueError("OPENAI_API_KEY not set")
   ```

2️⃣ Generar .env.example
   ```bash
   # .env.example (auto-generado)
   OPENAI_API_KEY=your_key_here
   AWS_ACCESS_KEY_ID=your_aws_key
   DATABASE_URL=postgresql://user:pass@localhost/db
   ```

3️⃣ Actualizar .gitignore
   ```
   # Secrets
   .env
   .env.local
   credentials.json
   secrets.yaml
   
   # Jupyter
   .ipynb_checkpoints/
   *-checkpoint.ipynb
   ```

4️⃣ Crear notebook seguro
   - Copiar notebook original → nombre_safe.ipynb
   - Aplicar reemplazos
   - Validar que ejecuta sin errores

PRE-COMMIT HOOK:
```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: clean-notebook-secrets
        name: Clean Secrets from Notebooks
        entry: python scripts/clean-notebook-secrets.py
        language: system
        files: '\.ipynb$'
        pass_filenames: true
        args: ['--fail-on-secrets']
```

REQUISITOS:
- Escanear celdas de código (ignorar Markdown)
- Detectar en: code, outputs, metadata
- Exit codes:
  * 0: No secrets encontrados
  * 1: Secrets encontrados (bloquea commit)
  * 2: Warnings (posibles secrets)
- Output: lista de secrets encontrados con línea/celda
- Sugerencias de remediación por cada secret
- Logging para auditoría

TESTING:
- Notebook con secrets de prueba
- Validar detección de todos los patterns
- Validar que código limpio ejecuta correctamente
- False positives mínimos

ENTREGA:
- scripts/clean-notebook-secrets.py
- .pre-commit-config.yaml
- .env.example template
- README con instrucciones
```

---

### 10.0 - ML PIPELINE SECURITY (DS)

**Cuando usarlo:** Implementar seguridad end-to-end en ML pipeline  
**Tiempo:** 25 minutos  
**Output:** Workflow YAML + scripts de validación

```markdown
PROPÓSITO: Crear pipeline CI/CD con validaciones de seguridad para ML
AUDIENCIA: Data Scientist/MLOps Engineer implementando MLSecOps
CONTEXTO: Pipeline de modelo [NOMBRE] desde entrenamiento hasta deploy en producción
EJEMPLOS: Commit → Tests → Security → Fairness → Model validation → Deploy
SCOPE: Workflow GitHub Actions con 7 stages, gates de seguridad, rollback automático

---

Crea .github/workflows/ml-security-pipeline.yml:

STAGES DEL PIPELINE:
1️⃣ Code Quality & Security (5 min)
   - Checkout código
   - Setup Python [VERSION]
   - Install dependencies
   - Linting: flake8, black, isort
   - Type checking: mypy
   - Security scan: bandit
   - CodeQL analysis
   - Exit si CRITICAL vulnerabilities

2️⃣ Dependency Security (3 min)
   - Check Dependabot alerts
   - License compliance check
   - Known vulnerabilities: safety check
   - Dependency confusion check
   - Generate SBOM (Software Bill of Materials)

3️⃣ Secrets & PII Detection (2 min)
   - Secret scanning en notebooks
   - PII detection en datasets
   - Environment variables validation
   - Credentials rotation check

4️⃣ Data Validation (8 min)
   - Data schema validation (Great Expectations)
   - Data quality checks
   - Data drift detection
   - Outlier detection
   - PII encryption verification
   - Data lineage tracking

5️⃣ Model Training & Validation (15 min)
   - Load training data (versioned)
   - Set random seeds (reproducibility)
   - Train model
   - Calculate metrics:
     * Performance: accuracy, precision, recall, F1
     * Fairness: disparate impact, equal opportunity
     * Explainability: SHAP importance check
   - Model validation:
     * Performance > baseline
     * Fairness within thresholds
     * No data leakage
     * Reproducible results

6️⃣ Security Gates Evaluation (5 min)
   - Evaluate all security gates:
     * Code vulnerabilities: 0 CRITICAL
     * Dependencies: 0 CRITICAL/HIGH
     * Secrets: 0 exposed
     * Fairness: disparate impact 0.8-1.25
     * Explainability: > [THRESHOLD]% coverage
     * Compliance: SBS/GDPR OK
   - Generate gate report
   - Comment on PR with results
   - Block if any CRITICAL gate fails

7️⃣ Model Registration & Deploy (variable)
   - Register model in MLflow/registry
   - Tag with version, metrics, metadata
   - Generate model card
   - Deploy to [ENVIRONMENT: staging]
   - Smoke tests en staging
   - [MANUAL_APPROVAL] para producción
   - Deploy to production
   - Monitor deployment

CONFIGURACIÓN AVANZADA:
```yaml
env:
  PYTHON_VERSION: '3.9'
  MODEL_NAME: 'credit_scoring_v2'
  MIN_ACCURACY: 0.85
  MAX_DISPARATE_IMPACT_DEVIATION: 0.2
  FAIRNESS_PROTECTED_ATTRS: 'gender,age,region'

jobs:
  code-security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: ${{ env.PYTHON_VERSION }}
      
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install bandit flake8 mypy safety
      
      - name: Security scan with Bandit
        run: bandit -r src/ -ll -f json -o reports/bandit.json
      
      - name: Check for high severity issues
        run: |
          high_issues=$(jq '[.results[] | select(.issue_severity == "HIGH")] | length' reports/bandit.json)
          if [ "$high_issues" -gt 0 ]; then
            echo "Found $high_issues high severity issues"
            exit 1
          fi

  model-fairness:
    needs: [code-security, dependency-security]
    runs-on: ubuntu-latest
    steps:
      - name: Train model
        run: python scripts/train_model.py --config config/model_config.yaml
      
      - name: Detect bias
        run: |
          python scripts/detect-model-bias.py \
            --model models/trained_model.pkl \
            --data data/test_data.csv \
            --protected-attributes ${{ env.FAIRNESS_PROTECTED_ATTRS }} \
            --output reports/fairness-report.json
      
      - name: Evaluate fairness gates
        run: |
          python scripts/evaluate-fairness-gates.py \
            --report reports/fairness-report.json \
            --max-deviation ${{ env.MAX_DISPARATE_IMPACT_DEVIATION }}

  deploy-staging:
    needs: [model-fairness, security-gates]
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - name: Deploy to staging
        run: |
          python scripts/deploy_model.py \
            --environment staging \
            --model-path models/trained_model.pkl \
            --version ${{ github.sha }}
      
      - name: Smoke tests
        run: python tests/smoke_tests.py --environment staging
```

GATES DE SEGURIDAD:
```python
# scripts/evaluate-ml-security-gates.py
class MLSecurityGates:
    gates = {
        'code_vulnerabilities': {'threshold': 0, 'severity': 'CRITICAL'},
        'dependency_vulns': {'threshold': 0, 'severity': 'CRITICAL'},
        'secrets_exposed': {'threshold': 0, 'severity': 'CRITICAL'},
        'fairness_disparate_impact': {'min': 0.8, 'max': 1.25, 'severity': 'HIGH'},
        'model_accuracy': {'min': 0.85, 'severity': 'MEDIUM'},
        'explainability_coverage': {'min': 0.80, 'severity': 'MEDIUM'},
        'data_drift': {'max': 0.15, 'severity': 'HIGH'},
        'pii_encrypted': {'required': True, 'severity': 'CRITICAL'}
    }
```

ROLLBACK AUTOMÁTICO:
```yaml
  - name: Monitor production deployment
    if: steps.deploy.outcome == 'success'
    run: |
      python scripts/monitor_deployment.py \
        --duration 600 \
        --rollback-on-error
    continue-on-error: false
```

NOTIFICACIONES:
```yaml
  - name: Notify on failure
    if: failure()
    uses: slackapi/slack-github-action@v1
    with:
      payload: |
        {
          "text": "❌ ML Security Pipeline Failed",
          "blocks": [
            {
              "type": "section",
              "text": {
                "type": "mrkdwn",
                "text": "*Pipeline:* ${{ github.workflow }}\n*Status:* Failed\n*Stage:* ${{ job.status }}"
              }
            }
          ]
        }
    env:
      SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK }}
```

ENTREGA:
- Workflow YAML completo
- Scripts de validación (7+)
- Configuración de gates
- README con arquitectura del pipeline
```

---

## 🔐 SECCIÓN COMPARTIDA (QE + DS)

### 11.0 - SECRET SCANNING SETUP

**Cuando usarlo:** Configurar detección de secrets  
**Tiempo:** 10 minutos  
**Output:** Configuración activa

```markdown
PROPÓSITO: Habilitar y configurar secret scanning en repositorio
AUDIENCIA: QE o DS configurando prevención de leaks
CONTEXTO: Proyecto [NOMBRE] con código, notebooks, configs potencialmente con secrets
EJEMPLOS: API key en código → Alerta inmediata → Revocar key → Migrar a env var
SCOPE: Configuración GitHub + custom patterns + alertas

---

Configura Secret Scanning:

PASOS:
1️⃣ Habilitar en GitHub
   - Settings → Security → Code security
   - Secret scanning: Enable
   - Push protection: Enable (bloquea pushes con secrets)

2️⃣ Custom Patterns (para secrets internos)
   - Settings → Security → Secret scanning → Custom patterns
   - Agregar patterns:
     ```regex
     # Internal API Key
     name: Internal API Key
     pattern: INTERNAL_API_[A-Z0-9]{32}
     test_string: INTERNAL_API_ABC123XYZ789ABC123XYZ789AB
     
     # Database Connection String
     name: Database Connection
     pattern: (postgresql|mysql)://[^:]+:[^@]+@[^/]+/\w+
     test_string: postgresql://user:password@localhost:5432/mydb
     
     # Custom patterns para tu organización
     [TU_PATTERN]
     ```

3️⃣ Configurar Alertas
   - Notificar en [CANAL: email, Slack, Teams]
   - Asignar a [EQUIPO: security-team]
   - Severity: CRITICAL (bloquea deploy)

4️⃣ Excepciones Legítimas
   - Crear allow-list para false positives:
     * Test fixtures: tests/fixtures/*.json
     * Mock data: mocks/*.py
     * Documentation: docs/examples/*.md
   - Archivo: .github/secret-scanning-allow-list.yml

5️⃣ Remediación de Secrets Existentes
   - Escanear historial de Git
   - Revocar secrets expuestos
   - Rotar credenciales
   - Migrar a secrets manager

VALIDACIÓN:
- Intentar commit con secret → debe fallar
- Validar que alertas llegan
- Verificar que allow-list funciona

ENTREGA: Configuración activa + documentación de proceso
```

---

### 12.0 - COMPLIANCE CHECKER

**Cuando usarlo:** Automatizar validación de compliance  
**Tiempo:** 20 minutos  
**Output:** Script de compliance + reporte

```markdown
PROPÓSITO: Crear script que valide compliance regulatorio (SBS, GDPR, PCI DSS)
AUDIENCIA: QE y DS validando cumplimiento normativo
CONTEXTO: Proyecto bancario sujeto a [REGULACIONES: SBS, GDPR, PCI DSS, OWASP]
EJEMPLOS: Código con PII sin encriptar → Compliance FAIL → Bloquear deploy
SCOPE: Script Python con checks específicos, reporte detallado, integrable en CI/CD

---

Crea scripts/check-compliance.py:

COMPLIANCE CHECKS:

🏦 SBS (Superintendencia de Banca y Seguros - Perú)
1️⃣ Seguridad de Información
   - Encriptación de datos en tránsito (TLS 1.2+)
   - Encriptación de datos en reposo
   - Autenticación multifactor habilitada
   - Segregación de ambientes (dev/staging/prod)

2️⃣ Auditoría y Trazabilidad
   - Logging de operaciones críticas
   - Audit trail de cambios
   - Retención de logs (mínimo [DIAS: 180] días)
   - No logs de PII sin ofuscar

3️⃣ Gestión de Riesgos
   - Análisis de vulnerabilidades periódico
   - Plan de respuesta a incidentes
   - Backup y recuperación probados
   - Documentación de procesos

🇪🇺 GDPR (Regulación Europea de Protección de Datos)
1️⃣ Protección de Datos Personales
   - PII identificado y clasificado
   - PII encriptado o anonimizado
   - Consentimiento documentado
   - Capacidad de exportar datos (data portability)

2️⃣ Derechos de los Titulares
   - Right to access: API para obtener datos
   - Right to erasure: capacidad de borrar datos
   - Right to rectification: actualización de datos
   - Right to explanation: modelos ML explicables

3️⃣ Seguridad y Notificación
   - Breach notification < 72 horas
   - Data Protection Impact Assessment (DPIA)
   - Privacy by design implementado

💳 PCI DSS (Payment Card Industry Data Security Standard)
1️⃣ Protección de Datos de Tarjetas
   - No almacenar CVV nunca
   - Tokenización de números de tarjeta
   - Encriptación fuerte (AES-256)
   - Mínimo almacenamiento (necesidad de negocio)

2️⃣ Controles de Acceso
   - Autenticación fuerte
   - Mínimo privilegio
   - Logging de accesos a datos de tarjetas

3️⃣ Testing de Seguridad
   - Scans de vulnerabilidades trimestrales
   - Penetration testing anual
   - Code review con foco en seguridad

🛡️ OWASP Top 10
1️⃣ Validar ausencia de:
   - A01: Broken Access Control
   - A02: Cryptographic Failures
   - A03: Injection
   - A04: Insecure Design
   - A05: Security Misconfiguration
   - A06: Vulnerable Components
   - A07: Identification & Auth Failures
   - A08: Software & Data Integrity Failures
   - A09: Security Logging Failures
   - A10: Server-Side Request Forgery

IMPLEMENTACIÓN:
```python
class ComplianceChecker:
    def __init__(self, config_file):
        self.config = load_config(config_file)
        self.results = {}
    
    def check_sbs_compliance(self):
        checks = {
            'encryption_in_transit': self._check_tls(),
            'encryption_at_rest': self._check_encryption(),
            'mfa_enabled': self._check_mfa(),
            'audit_logging': self._check_audit_logs(),
            'log_retention': self._check_log_retention(180)
        }
        return self._evaluate_checks('SBS', checks)
    
    def check_gdpr_compliance(self):
        checks = {
            'pii_encrypted': self._check_pii_encryption(),
            'data_portability': self._check_data_export_api(),
            'right_to_erasure': self._check_delete_capability(),
            'right_to_explanation': self._check_model_explainability(),
            'breach_notification': self._check_incident_response()
        }
        return self._evaluate_checks('GDPR', checks)
    
    def check_pci_dss_compliance(self):
        checks = {
            'no_cvv_storage': self._check_no_cvv(),
            'card_tokenization': self._check_tokenization(),
            'strong_encryption': self._check_aes256(),
            'access_logging': self._check_card_access_logs()
        }
        return self._evaluate_checks('PCI_DSS', checks)
    
    def generate_report(self):
        report = {
            'timestamp': datetime.now().isoformat(),
            'overall_compliant': all(r['compliant'] for r in self.results.values()),
            'regulations': self.results,
            'action_items': self._generate_action_items()
        }
        return report
```

CHECKS ESPECÍFICOS:
```python
def _check_tls(self):
    """Verifica TLS 1.2+ en endpoints"""
    # Leer configuración de servidores
    # Validar versión TLS mínima
    # Verificar certificados válidos
    pass

def _check_pii_encryption(self):
    """Verifica que PII esté encriptado"""
    # Escanear código por campos PII
    # Validar que tienen encriptación
    # Verificar uso de secrets manager
    pass

def _check_model_explainability(self):
    """Verifica que modelos ML sean explicables (GDPR)"""
    # Buscar implementación de SHAP/LIME
    # Validar documentación de modelos
    # Verificar API de explicaciones
    pass
```

EXIT CODES:
- 0: Compliant con todas las regulaciones
- 1: Non-compliant (bloquea deploy a producción)
- 2: Parcialmente compliant (warnings, permite deploy con aprobación)

OUTPUT:
```json
{
  "timestamp": "2024-12-08T...",
  "overall_compliant": false,
  "regulations": {
    "SBS": {
      "compliant": true,
      "checks_passed": 5,
      "checks_total": 5
    },
    "GDPR": {
      "compliant": false,
      "checks_passed": 3,
      "checks_total": 5,
      "failures": [
        {
          "check": "right_to_explanation",
          "severity": "HIGH",
          "message": "Modelos ML no tienen explicabilidad implementada",
          "remediation": "Implementar SHAP en scripts/explain-model.py"
        }
      ]
    }
  },
  "action_items": [
    {
      "priority": "HIGH",
      "regulation": "GDPR",
      "item": "Implementar explicabilidad en modelos",
      "owner": "DS Team",
      "deadline": "2024-12-15"
    }
  ]
}
```

INTEGRACIÓN CI/CD:
```yaml
- name: Compliance Check
  run: |
    python scripts/check-compliance.py \
      --config config/compliance-config.yml \
      --regulations SBS,GDPR,PCI_DSS,OWASP \
      --output reports/compliance-report.json
      
    # Fail si no compliant
    python -c "import json; report = json.load(open('reports/compliance-report.json')); exit(0 if report['overall_compliant'] else 1)"
```

ENTREGA:
- scripts/check-compliance.py
- config/compliance-config.yml (con thresholds)
- Reporte detallado en JSON y Markdown
- Integración en workflow
```

---

## 📋 GUÍA RÁPIDA DE USO

### Para QE
1. Comienza con **1.0 CodeQL Setup**
2. Aprende a analizar alertas con **1.1 Análisis de Alertas**
3. Automatiza con **2.0 Dependabot** y **4.0 Security Gates**
4. Crea tests de seguridad con **3.0 Security Testing**
5. Reporta con **5.0 Executive Report**

### Para DS
1. Inicia con **6.0 CodeQL para ML**
2. Valida fairness con **7.0 Detectar Bias**
3. Agrega explicabilidad con **8.0 SHAP**
4. Protege secrets con **9.0 Limpiar Notebooks**
5. Integra todo con **10.0 ML Pipeline Security**

### Para Ambos
- Siempre configura **11.0 Secret Scanning**
- Valida compliance con **12.0 Compliance Checker**

---

## 💡 TIPS PARA MEJORES RESULTADOS

1. **Personaliza el CONTEXTO**
   - Usa nombres reales de tu proyecto
   - Incluye tecnologías específicas
   - Menciona regulaciones aplicables

2. **Proporciona EJEMPLOS concretos**
   - Mejora la relevancia de la respuesta
   - Copilot entiende mejor tu necesidad

3. **Define SCOPE claramente**
   - Evita respuestas genéricas
   - Obtén código ejecutable directamente

4. **Itera en el prompt**
   - Si la respuesta no es perfecta, refina
   - Agrega más contexto o ejemplos

---

**LIBRERÍA DE PROMPTS GHAS COMPLETA** ✅

GitHub Advanced Security para QE y DS  
Mi Banco | Taller 7
