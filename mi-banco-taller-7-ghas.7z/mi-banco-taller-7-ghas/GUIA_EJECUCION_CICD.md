# 🎯 Guía de Ejecución Práctica - Taller CI/CD y Automatización QA

**Facilitador:** GitHub Copilot  
**Objetivo:** Implementar pipelines CI/CD inteligentes para QA bancario  
**Duración:** 2 horas (120 minutos)  
**Tecnologías:** GitHub Actions, Python, Newman/Postman CLI, Postman
**Requisitos Previos:**
- Cuenta GitHub con Copilot Chat activo
- VS Code instalado con extensión Copilot Chat
- **UNA** de las siguientes opciones para ejecutar colecciones:
  - **Opción A (Newman):** Node.js y npm instalados + Newman (`npm install -g newman newman-reporter-htmlextra`)
  - **Opción B (Postman CLI):** Instalar con: `powershell.exe -NoProfile -InputFormat None -ExecutionPolicy AllSigned -Command "[System.Net.ServicePointManager]::SecurityProtocol = 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://dl-cli.pstmn.io/install/win64.ps1'))"`
- Postman instalado con colección `mi-banco-apis.json` y environment `testing.json`
- Conocimientos básicos de PowerShell y Python
- Familiaridad con Postman y GitHub
- Acceso a repositorio `mi-banco-qa-repo` en GitHub
- Permisos para crear workflows y secrets en el repositorio


💡 **TIP:** Abre `LIBRERIA_PROMPTS_CICD.md` en paralelo para consultar prompts mientras trabajas.

---

## ⚡ QUICKSTART (Primeros 5 minutos)

### Paso 1: Prepara el entorno

```powershell
# En VS Code
code .

# Abre Copilot Chat
Ctrl + Shift + I

# Autentica tu cuenta GitHub si no lo has hecho
Ctrl + Shift + P → "Copilot: Sign In"
```

### Paso 2: Verifica archivos existentes
- **mi-banco-apis.json** - Colección Postman (ya disponible ✅)
- **testing.json** - Environment Postman (ya disponible ✅)
- **local-environment.json** - Environment para servidor local (ya disponible ✅)
- **📮_GUIA_IMPORTAR_POSTMAN.md** - Guía de importación
- **mock-server/** - Servidor mock de APIs (ya disponible ✅)

### Paso 2.1: Levantar el servidor de APIs Mock 🚀

> ⚠️ **IMPORTANTE:** Antes de ejecutar los tests, debes levantar el servidor mock que simula las APIs de Mi Banco en `http://localhost:3000`

```powershell
# Navegar a la carpeta del servidor mock
cd mock-server

# Instalar dependencias (solo la primera vez)
npm install

# Iniciar el servidor (mantener esta terminal abierta)
npm start
```

**Verificar que el servidor está corriendo:**

```powershell
# En otra terminal, probar el health check
Invoke-RestMethod -Uri "http://localhost:3000/health" -Method GET

# Deberías ver algo como:
# status    : healthy
# timestamp : 2025-12-07T...
# version   : 1.0.0
```

> 💡 **TIP:** Mantén la terminal del servidor abierta durante todo el taller. Si necesitas detenerlo: `Ctrl + C` o `Get-Process -Name "node" | Stop-Process -Force`

**Usuarios de prueba disponibles:**
| Usuario | Contraseña | Rol |
|---------|------------|-----|
| qa_user@mibancoqe.com | QaTest2024! | QA Tester |
| tomsmith | SuperSecretPassword! | Admin |

### Paso 3: Estructura del taller

| Módulo | Tema | Duración |
|--------|------|----------|
| 1 | Fundamentos GitHub Actions | 20 min |
| 2 | Pipeline Básico Newman | 25 min |
| 3 | Smart Test Selection | 25 min |
| 4 | Quality Gates | 20 min |
| 5 | Reportes Ejecutivos | 20 min |
| 6 | Integración Completa | 10 min |

---

## 📚 FLUJO POR MÓDULO

### MÓDULO 1: Fundamentos GitHub Actions (20 minutos)

#### Actividad 1A: Entender GitHub Actions (10 min)

**PASO 1:** Abre Copilot Chat (`Ctrl + Shift + I`)

**PASO 2:** Copia este prompt PACES:

```
PROPÓSITO: Explicar GitHub Actions para automatización QA bancaria
AUDIENCIA: QE con experiencia en Postman/Selenium que no conoce CI/CD
CONTEXTO: Proyecto Mi Banco, necesitamos automatizar ejecución de tests API
EJEMPLOS: Pipeline manual → Pipeline automatizado, Newman local → Newman CI/CD
SCOPE: Conceptos fundamentales, máx 3 párrafos + 1 diagrama ASCII

---

Explica GitHub Actions para un QE que viene del testing manual:

1. ¿Qué es GitHub Actions? (analogía simple)
2. ¿Por qué usarlo para QA bancario?
3. Componentes clave: workflow, job, step, trigger
4. Diagrama ASCII del flujo: PR → Tests → Report → Merge

Mantén lenguaje simple, orientado a QE no-developer.
```

**PASO 3:** Lee la explicación y crea archivo `GitHub_Actions_Fundamentos.md`

**PASO 4:** Documenta los conceptos clave

**VALIDACIÓN:**
- [ ] Archivo creado
- [ ] 4 componentes explicados
- [ ] Diagrama de flujo incluido

**TIEMPO:** 10 minutos

---

#### Actividad 1B: Crear Estructura de Proyecto (10 min)

**PASO 1:** En Copilot Chat, copia este prompt:

```
PROPÓSITO: Crear estructura de directorios para proyecto CI/CD QA
AUDIENCIA: QE configurando repositorio desde cero
CONTEXTO: Windows PowerShell, proyecto Mi Banco QA Automation
EJEMPLOS: mkdir → New-Item, estructura estándar GitHub Actions
SCOPE: Comandos PowerShell ejecutables, crear .github/workflows, scripts, reports

---

Genera comandos PowerShell para crear esta estructura:

mi-banco-qa-repo/
├── .github/workflows/    # Workflows GitHub Actions
├── scripts/              # Scripts Python
├── collections/          # Postman collections
├── environments/         # Postman environments
└── reports/              # Reportes generados

Incluye:
1. Comandos New-Item para cada directorio
2. Verificación con Get-ChildItem
3. Archivo README.md básico en cada carpeta
```

**Referencias:**
- Estructura: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 1: ESTRUCTURA DE PROYECTO"

**PASO 2:** Ejecuta los comandos en terminal

```powershell
# Crear estructura de directorios
New-Item -ItemType Directory -Force -Path ".github/workflows"
New-Item -ItemType Directory -Force -Path "scripts"
New-Item -ItemType Directory -Force -Path "collections"
New-Item -ItemType Directory -Force -Path "environments"
New-Item -ItemType Directory -Force -Path "reports"

# Verificar
Get-ChildItem -Recurse -Directory
```

**PASO 3:** Copia los archivos Postman existentes:

```powershell
# Copiar colección y environment (si existen en el workspace)
Copy-Item "mi-banco-apis.json" -Destination "collections/"
Copy-Item "testing.json" -Destination "environments/"
```

**VALIDACIÓN:**
- [ ] 5 directorios creados
- [ ] Archivos Postman copiados
- [ ] Estructura verificada

**TIEMPO:** 10 minutos

---

### MÓDULO 2: Pipeline Básico Newman (25 minutos)

#### Actividad 2A: Crear Workflow Básico (15 min)

**PASO 1:** En Copilot Chat, copia este prompt PACES:

```
PROPÓSITO: Crear workflow GitHub Actions para ejecutar tests Postman con Newman
AUDIENCIA: QE que configura CI/CD por primera vez
CONTEXTO: Proyecto bancario, colección en collections/mi-banco-apis.json, environment en environments/testing.json
EJEMPLOS: newman run local → newman run en GitHub Actions
SCOPE: Workflow YAML completo, triggers push/PR/schedule, upload de reportes

---

Crea archivo api-tests.yml para GitHub Actions:

REQUISITOS:
1️⃣ Triggers
   - push a main/develop
   - pull_request a main
   - schedule: 6 AM diario

2️⃣ Setup
   - ubuntu-latest
   - Node.js 18
   - Newman + reporter htmlextra

3️⃣ Ejecución
   - newman run con collection y environment
   - Reporters: cli, htmlextra, json
   - Timeout 5000ms por request
   - Delay 100ms entre requests

4️⃣ Artifacts
   - Upload reportes HTML y JSON
   - Retención 30 días
   - Ejecutar aunque fallen tests (if: always())

5️⃣ Comentarios en español explicando cada step

ENTREGA: Archivo YAML completo y funcional
```

**Referencias:**
- Código: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 2: WORKFLOW BÁSICO - api-tests.yml"
- Prompts: `LIBRERIA_PROMPTS_CICD.md` → "1.0 - WORKFLOW BÁSICO NEWMAN"

**PASO 2:** Crea el archivo en `.github/workflows/api-tests.yml`

**PASO 3:** Revisa el YAML generado y ajusta si es necesario

**VALIDACIÓN:**
- [ ] Archivo YAML creado
- [ ] 3 triggers configurados
- [ ] Newman instalado y ejecutado
- [ ] Reportes como artifacts

**TIEMPO:** 15 minutos

---

#### Actividad 2B: Testing Local del Workflow (10 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Validar workflow GitHub Actions localmente antes de push
AUDIENCIA: QE que necesita probar workflow sin hacer commit
CONTEXTO: Windows, archivo api-tests.yml creado, Newman disponible
EJEMPLOS: act tool, yamllint, comandos newman locales
SCOPE: Comandos para validar sintaxis YAML y simular ejecución

---

Genera comandos para validar el workflow localmente:

1. Validar sintaxis YAML (sin errores de indentación)
2. Simular ejecución de Newman como lo haría GitHub
3. Verificar que reportes se generen correctamente

Incluye comandos PowerShell para cada paso.
```

**PASO 2:** Ejecuta tests localmente

> 💡 **OPCIONES DE EJECUCIÓN:** Tienes dos alternativas para ejecutar las colecciones Postman desde línea de comandos. Elige la que prefieras o tengas disponible.

---

##### **OPCIÓN A: Newman (Node.js)** ⭐ Recomendado para CI/CD

```powershell
# Instalar Newman si no está
npm install -g newman newman-reporter-htmlextra

# Ejecutar tests localmente (simula el workflow)
newman run collections/mi-banco-apis.json `
  --environment environments/testing.json `
  --reporters cli,htmlextra,json `
  --reporter-htmlextra-export reports/api-test-report.html `
  --reporter-json-export reports/api-test-results.json `
  --delay-request 100 `
  --timeout-request 5000

# Verificar reportes generados
Get-ChildItem reports/
```

---

##### **OPCIÓN B: Postman CLI** 🆕 Alternativa oficial de Postman

Si no tienes Node.js instalado o prefieres usar la herramienta oficial de Postman:

**Instalación de Postman CLI (una sola vez):**

```powershell
# Instalar Postman CLI para Windows
# Este comando descarga e instala el binario en %USERPROFILE%\AppData\Local\Microsoft\WindowsApps
powershell.exe -NoProfile -InputFormat None -ExecutionPolicy AllSigned -Command "[System.Net.ServicePointManager]::SecurityProtocol = 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://dl-cli.pstmn.io/install/win64.ps1'))"

# Verificar instalación
postman --version
```

**Ejecución con Postman CLI:**

```powershell
# Ejecutar colección con environment local
postman collection run collections/mi-banco-apis.json `
  --environment environments/testing.json

# Con opciones adicionales
postman collection run collections/mi-banco-apis.json `
  --environment environments/testing.json `
  --delay-request 100 `
  --timeout-request 5000

# Verificar reportes (se generan automáticamente)
Get-ChildItem reports/
```

> ⚠️ **NOTA:** Postman CLI requiere autenticación con tu cuenta Postman para algunas funciones avanzadas. Para pipelines CI/CD, Newman sigue siendo la opción más flexible.

---

##### **Comparativa rápida:**

| Característica | Newman | Postman CLI |
|---------------|--------|-------------|
| Requiere Node.js | ✅ Sí | ❌ No |
| Requiere cuenta Postman | ❌ No | ⚠️ Opcional |
| Reportes HTML personalizados | ✅ htmlextra | ⚠️ Limitado |
| Integración GitHub Actions | ✅ Excelente | ✅ Buena |
| Instalación offline | ✅ npm pack | ❌ Requiere internet |

---

**PASO 3:** Abre el reporte HTML:

```powershell
# Abrir reporte en navegador
Start-Process reports/api-test-report.html
```

**VALIDACIÓN:**
- [ ] Newman ejecuta sin errores
- [ ] Reporte HTML generado
- [ ] Reporte JSON generado

**TIEMPO:** 10 minutos

---

### MÓDULO 3: Smart Test Selection (25 minutos)

#### Actividad 3A: Entender Smart Test Selection (10 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Explicar selección inteligente de tests basada en cambios de código
AUDIENCIA: QE que quiere optimizar tiempo de CI/CD
CONTEXTO: Suite de 200+ tests, pipeline tarda 45 minutos, objetivo 15 minutos
EJEMPLOS: Cambio en src/transfers → solo tests de transfers, no toda la suite
SCOPE: Concepto + beneficios + ejemplo práctico con números

---

Explica Smart Test Selection para QE:

1. ¿Qué problema resuelve?
2. ¿Cómo funciona? (diagrama de decisión)
3. Beneficios (tiempo, costo, feedback)
4. Ejemplo numérico:
   - Suite completa: 200 tests, 45 min
   - Con smart selection: X tests, Y min
   - Ahorro: Z%

Incluye tabla comparativa antes/después.
```

**PASO 2:** Crea archivo `Smart_Test_Selection_Concepto.md`

**VALIDACIÓN:**
- [ ] Concepto documentado
- [ ] Diagrama de decisión incluido
- [ ] Ejemplo numérico con ahorro

**TIEMPO:** 10 minutos

---

#### Actividad 3B: Crear Script de Selección (15 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Crear script Python para selección inteligente de tests
AUDIENCIA: QE implementando CI/CD inteligente
CONTEXTO: Proyecto bancario con módulos: transfers, login, security, payments, auth
EJEMPLOS: git diff → archivos cambiados → tests relacionados → newman grep
SCOPE: Script Python completo con mapeo módulo→tests y smoke tests obligatorios

---

Crea script smart-test-selector.py:

REQUISITOS:
1️⃣ Mapeo de módulos
   - src/transfers → tests de transferencias (5 tests)
   - src/login → tests de login (4 tests)
   - src/security → tests de seguridad (4 tests)
   - src/payments → tests de pagos (2 tests)
   - src/auth → tests de auth (2 tests)

2️⃣ Smoke tests (siempre ejecutar)
   - GET_Health_Check
   - POST_Login_ValidCredentials
   - GET_Transfer_Status

3️⃣ Lógica
   - Recibe archivos cambiados como argumento
   - Detecta módulos afectados
   - Agrega tests correspondientes
   - Si no hay cambios específicos → suite completa

4️⃣ Output
   - Reporte en consola
   - Patrón grep para Newman
   - GitHub Actions outputs

5️⃣ Comentarios en español

ENTREGA: Script Python ejecutable
```

**Referencias:**
- Código: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 3: SMART TEST SELECTOR"
- Prompts: `LIBRERIA_PROMPTS_CICD.md` → "2.0 - SMART TEST SELECTION"

**PASO 2:** Crea el archivo en `scripts/smart-test-selector.py`

**PASO 3:** Prueba el script localmente:

```powershell
# Simular cambios en transfers y security
python scripts/smart-test-selector.py "src/transfers/api.py,src/security/ssl.py"

# Simular cambios en login
python scripts/smart-test-selector.py "src/login/auth.py"

# Sin cambios específicos (suite completa)
python scripts/smart-test-selector.py ""
```

**VALIDACIÓN:**
- [ ] Script creado
- [ ] Mapeo de 5 módulos
- [ ] Smoke tests incluidos
- [ ] Output para GitHub Actions

**TIEMPO:** 15 minutos

---

### MÓDULO 4: Quality Gates (20 minutos)

#### Actividad 4A: Entender Quality Gates (5 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Explicar Quality Gates para QA bancario
AUDIENCIA: QE que implementa control de calidad automatizado
CONTEXTO: Banco regulado por SBS, compliance crítico, zero tolerance vulnerabilities
EJEMPLOS: Gate success rate > 95%, zero critical vulns, compliance 100%
SCOPE: 4 gates críticos + criterios + consecuencias de no cumplir

---

Explica Quality Gates para proyecto bancario:

1. ¿Qué son Quality Gates?
2. ¿Por qué son críticos en banca?

Gates requeridos:
- Test Success Rate (> 95%)
- Critical Vulnerabilities (= 0)
- Code Coverage (> 80%)
- Compliance SBS (= 100%)

Para cada gate:
- Criterio de éxito
- ¿Qué pasa si falla?
- ¿Es bloqueante para merge?

Incluye tabla resumen.
```

**PASO 2:** Documenta en `Quality_Gates_Bancarios.md`

**VALIDACIÓN:**
- [ ] 4 gates documentados
- [ ] Criterios claros
- [ ] Consecuencias explicadas

**TIEMPO:** 5 minutos

---

#### Actividad 4B: Crear Evaluador de Gates (15 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Crear script Python para evaluar quality gates
AUDIENCIA: QE automatizando decisiones de merge
CONTEXTO: Proyecto bancario, resultados de tests en JSON, gates críticos definidos
EJEMPLOS: JSON input → evaluación → PASS/FAIL → exit code para CI/CD
SCOPE: Script Python completo con 4 gates, reporte JSON, exit code

---

Crea script evaluate-quality-gates.py:

REQUISITOS:
1️⃣ Input
   - Archivo JSON con resultados de tests (argumento)
   - Estructura: stats.tests.passed/total, coverage, security_scan, compliance

2️⃣ Gates a evaluar
   - test_success_rate: > 95% (CRÍTICO)
   - critical_vulnerabilities: = 0 (CRÍTICO)
   - code_coverage: > 80% (WARNING)
   - compliance_sbs: 100% (CRÍTICO)

3️⃣ Output
   - Reporte en consola con ✅/❌
   - JSON guardado en reports/
   - Recomendación: SEGURO PARA MERGE / BLOQUEAR MERGE

4️⃣ Exit codes
   - 0 = todos gates críticos OK
   - 1 = algún gate crítico FAIL

5️⃣ Comentarios en español

ENTREGA: Script Python ejecutable
```

**Referencias:**
- Código: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 4: QUALITY GATES EVALUATOR"
- Prompts: `LIBRERIA_PROMPTS_CICD.md` → "3.0 - QUALITY GATES"

**PASO 2:** Crea el archivo en `scripts/evaluate-quality-gates.py`

**PASO 3:** Prueba el script con datos mock:

```powershell
# Crear archivo de prueba PASS
$mockPass = @{
    stats = @{
        tests = @{
            passed = 48
            total = 50
        }
    }
    coverage = @{
        percentage = 85
    }
    security_scan = @{
        vulnerabilities = @()
    }
    compliance = @{
        sbs_requirements_met = $true
        aml_validation_complete = $true
        audit_trail_present = $true
    }
}
$mockPass | ConvertTo-Json -Depth 5 | Out-File "reports/test-pass.json"

# Evaluar (debería PASS)
python scripts/evaluate-quality-gates.py reports/test-pass.json
Write-Host "Exit code: $LASTEXITCODE"
```

```powershell
# Crear archivo de prueba FAIL
$mockFail = @{
    stats = @{
        tests = @{
            passed = 40
            total = 50
        }
    }
    coverage = @{
        percentage = 65
    }
    security_scan = @{
        vulnerabilities = @(
            @{severity = "CRITICAL"; title = "SQL Injection"}
        )
    }
    compliance = @{
        sbs_requirements_met = $false
    }
}
$mockFail | ConvertTo-Json -Depth 5 | Out-File "reports/test-fail.json"

# Evaluar (debería FAIL)
python scripts/evaluate-quality-gates.py reports/test-fail.json
Write-Host "Exit code: $LASTEXITCODE"
```

**VALIDACIÓN:**
- [ ] Script creado
- [ ] 4 gates evaluados
- [ ] Exit code correcto (0 vs 1)
- [ ] Reporte JSON generado

**TIEMPO:** 15 minutos

---

### MÓDULO 5: Reportes Ejecutivos (20 minutos)

#### Actividad 5A: Crear Generador de Reportes (15 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Crear script que traduce métricas técnicas a insights de negocio
AUDIENCIA: Stakeholders no-técnicos (Product Owner, Gerencia)
CONTEXTO: Resultados de tests en JSON, necesitan reporte Markdown legible
EJEMPLOS: "48/50 tests passed" → "96% de funcionalidades validadas ✅"
SCOPE: Script Python completo, output Markdown, recomendación de deploy

---

Crea script generate-executive-report.py:

REQUISITOS:
1️⃣ Input
   - Archivo JSON con resultados de tests

2️⃣ Secciones del reporte
   - Resumen Ejecutivo (tabla)
   - Análisis Detallado
   - Áreas Cubiertas (Transfers, Security, Compliance)
   - Recomendación de Negocio
   - Items que requieren atención
   - Próximos pasos

3️⃣ Formato
   - Markdown compatible con GitHub
   - Emojis para status visual (✅❌⚠️)
   - Tablas para métricas
   - Lenguaje de negocio (no técnico)

4️⃣ Lógica de recomendación
   - Success rate >= 95% AND zero critical issues AND compliance OK → DEPLOY OK
   - Cualquier fallo → REVISAR PRIMERO

5️⃣ Output
   - Archivo reports/executive-report.md
   - Timestamp de generación

ENTREGA: Script Python ejecutable
```

**Referencias:**
- Código: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 5: EXECUTIVE REPORT GENERATOR"
- Prompts: `LIBRERIA_PROMPTS_CICD.md` → "4.0 - REPORTES EJECUTIVOS"

**PASO 2:** Crea el archivo en `scripts/generate-executive-report.py`

**PASO 3:** Prueba el script:

```powershell
# Generar reporte con datos mock
python scripts/generate-executive-report.py reports/test-pass.json

# Ver reporte generado
Get-Content reports/executive-report.md

# Abrir en VS Code
code reports/executive-report.md
```

**VALIDACIÓN:**
- [ ] Script creado
- [ ] Reporte Markdown generado
- [ ] Secciones completas
- [ ] Recomendación incluida

**TIEMPO:** 15 minutos

---

#### Actividad 5B: Personalizar Reporte (5 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Agregar sección personalizada al reporte ejecutivo
AUDIENCIA: QE Lead que quiere incluir métricas adicionales
CONTEXTO: Reporte existente, necesito agregar sección de tendencias
EJEMPLOS: Comparación con ejecución anterior, gráfico ASCII de tendencia
SCOPE: Función adicional para agregar al script existente

---

Genera función adicional para el reporte:

def _get_trends_section(self) -> str:
    """
    Genera sección de tendencias comparando con ejecuciones anteriores
    
    Incluir:
    - Comparación success rate vs promedio últimos 5 runs
    - Tendencia (mejorando/estable/empeorando)
    - Gráfico ASCII simple de últimos 5 resultados
    """

Ejemplo output:
### 📈 TENDENCIAS
| Run | Success Rate | Trend |
|-----|-------------|-------|
| #5 (actual) | 96% | ⬆️ |
| #4 | 94% | ⬆️ |
| #3 | 92% | ➡️ |
```

**PASO 2:** Agrega la función al script existente (opcional)

**VALIDACIÓN:**
- [ ] Función creada
- [ ] Integrada al reporte

**TIEMPO:** 5 minutos

---

### MÓDULO 6: Integración Completa (10 minutos)

#### Actividad 6A: Pipeline Completo con 5 Jobs (10 min)

**PASO 1:** En Copilot Chat:

```
PROPÓSITO: Crear workflow GitHub Actions que integre todos los componentes
AUDIENCIA: QE configurando pipeline de producción
CONTEXTO: Smart selector, quality gates, executive report - todos los scripts listos
EJEMPLOS: Job 1 → Job 2 → Job 3 → Job 4 → Job 5 con dependencias
SCOPE: Workflow YAML completo con 5 jobs encadenados

---

Crea archivo smart-qa-pipeline.yml:

REQUISITOS:
1️⃣ Job 1: detect-and-select
   - Checkout con historia completa
   - Detectar archivos cambiados (git diff)
   - Ejecutar smart-test-selector.py
   - Outputs: tests-to-run, test-count

2️⃣ Job 2: run-selected-tests
   - Depende de Job 1
   - Newman con grep pattern de Job 1
   - Generar reportes HTML/JSON
   - Upload artifacts

3️⃣ Job 3: evaluate-gates
   - Depende de Job 2
   - Download artifacts
   - Ejecutar evaluate-quality-gates.py
   - Upload gates report

4️⃣ Job 4: generate-report
   - Depende de Job 2 y Job 3
   - Ejecutar generate-executive-report.py
   - Upload executive report

5️⃣ Job 5: comment-pr
   - Depende de Job 3 y Job 4
   - Solo en pull_request
   - Comentar reporte en PR con gh cli

TRIGGERS: push develop, pull_request main

ENTREGA: Workflow YAML completo
```

**Referencias:**
- Código: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 6: WORKFLOW COMPLETO"
- Prompts: `LIBRERIA_PROMPTS_CICD.md` → "5.0 - PIPELINE COMPLETO"

**PASO 2:** Crea el archivo en `.github/workflows/smart-qa-pipeline.yml`

**PASO 3:** Revisa las dependencias entre jobs

**VALIDACIÓN:**
- [ ] 5 jobs creados
- [ ] Dependencias correctas
- [ ] Outputs pasados entre jobs
- [ ] Comentario en PR configurado

**TIEMPO:** 10 minutos

---

## 🚀 INSTALACIÓN Y PUSH A GITHUB

### Paso 1: Verificar archivos creados

```powershell
# Listar todos los archivos
Get-ChildItem -Recurse -File | Select-Object FullName
```

### Paso 2: Inicializar repositorio Git

```powershell
# Inicializar (si no existe)
git init

# Agregar archivos
git add .github/workflows/ scripts/ collections/ environments/

# Crear commit
git commit -m "Add GitHub Actions CI/CD pipeline for QA automation"
```

### Paso 3: Conectar con GitHub

```powershell
# Agregar remote (reemplaza con tu repo)
git remote add origin https://github.com/tu-usuario/mi-banco-qa.git

# O si ya existe, verificar
git remote -v
```

### Paso 4: Push

```powershell
# Establecer rama principal
git branch -M main

# Push
git push -u origin main
```

### Paso 5: Verificar en GitHub

1. Ir a GitHub.com → Tu repositorio
2. Pestaña "Actions"
3. Verificar que workflows aparezcan
4. Crear PR para activar el pipeline

---

## 📋 CHECKLIST FINAL

### Archivos Creados

- [ ] `.github/workflows/api-tests.yml`
- [ ] `.github/workflows/smart-qa-pipeline.yml`
- [ ] `scripts/smart-test-selector.py`
- [ ] `scripts/evaluate-quality-gates.py`
- [ ] `scripts/generate-executive-report.py`
- [ ] `collections/mi-banco-apis.json`
- [ ] `environments/testing.json`

### Funcionalidades Implementadas

- [ ] Pipeline básico Newman
- [ ] Selección inteligente de tests
- [ ] Evaluación de quality gates
- [ ] Generación de reportes ejecutivos
- [ ] Comentarios automáticos en PR

### Documentación Creada

- [ ] `GitHub_Actions_Fundamentos.md`
- [ ] `Smart_Test_Selection_Concepto.md`
- [ ] `Quality_Gates_Bancarios.md`

---

## 🔗 REFERENCIAS

| Archivo | Descripción | Cuándo usar |
|---------|-------------|-------------|
| `EJEMPLOS_CICD_AUTOMATION.md` | Código listo para copiar | Durante actividades |
| `LIBRERIA_PROMPTS_CICD.md` | Prompts PACES | Para pedir a Copilot |
| `📮_GUIA_IMPORTAR_POSTMAN.md` | Setup Postman | Antes del taller |
| `mi-banco-apis.json` | Colección Postman | Input para Newman |

---

## ⏱️ TIEMPO TOTAL

| Módulo | Duración | Acumulado |
|--------|----------|-----------|
| 1. Fundamentos | 20 min | 20 min |
| 2. Pipeline Básico | 25 min | 45 min |
| 3. Smart Selection | 25 min | 70 min |
| 4. Quality Gates | 20 min | 90 min |
| 5. Reportes | 20 min | 110 min |
| 6. Integración | 10 min | 120 min |

**Total:** 2 horas

---

**GUÍA DE EJECUCIÓN COMPLETA** ✅

Taller CI/CD y Automatización QA  
Mi Banco QE Team | Taller 6
