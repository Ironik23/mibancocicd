# Templates

Esta carpeta contiene templates y plantillas para el proyecto.

## 🎨 Templates Disponibles

### GitHub Templates

Los templates de GitHub están en `.github/`:
- `.github/ISSUE_TEMPLATE/` - Templates para issues
- `.github/PULL_REQUEST_TEMPLATE.md` - Template para PRs
- `.github/workflows/` - Templates de workflows

### Document Templates

Puedes agregar aquí:

#### Security
- `security-incident-report.md` - Template para reportar incidentes
- `vulnerability-disclosure.md` - Template para divulgar vulnerabilidades
- `security-review-checklist.md` - Checklist de revisión de seguridad

#### Code Review
- `code-review-template.md` - Guía para code reviews
- `pr-description-template.md` - Template para descripciones de PR

#### ML/Data Science
- `model-card-template.md` - Documentación de modelos ML
- `dataset-card-template.md` - Documentación de datasets
- `experiment-log-template.md` - Log de experimentos

#### Reports
- `weekly-security-report.md` - Reporte semanal de seguridad
- `sprint-retrospective.md` - Template de retrospectiva
- `technical-design-doc.md` - Documento de diseño técnico

## 📋 Ejemplo: Model Card Template

```markdown
# Model Card: [Nombre del Modelo]

## Model Details
- **Version:** 1.0.0
- **Type:** Classification / Regression
- **Framework:** scikit-learn / TensorFlow
- **Created:** YYYY-MM-DD
- **Owner:** [Equipo/Persona]

## Intended Use
- **Primary Use:** [Descripción]
- **Out-of-Scope:** [Lo que NO debe usarse]

## Training Data
- **Dataset:** [Nombre y versión]
- **Size:** [N registros]
- **Features:** [Lista de features]
- **Target:** [Variable objetivo]

## Performance Metrics
- **Accuracy:** XX.X%
- **Precision:** XX.X%
- **Recall:** XX.X%
- **F1-Score:** XX.X%

## Fairness Metrics
- **Disparate Impact:** X.XX
- **Equal Opportunity Difference:** X.XX
- **Statistical Parity:** X.XX

## Ethical Considerations
- [Consideraciones éticas]
- [Bias detectado y mitigado]
- [Limitaciones conocidas]

## Recommendations
- [Recomendaciones de uso]
- [Frecuencia de re-entrenamiento]
- [Monitoring en producción]
```

## 🔧 Uso

Para usar un template:

1. Copiar el template
2. Renombrar según convención del proyecto
3. Llenar las secciones
4. Guardar en la carpeta apropiada

---

**Nota:** Esta carpeta está preparada para almacenar templates que se creen durante el desarrollo del proyecto.
