# 📚 Librería de Prompts PACES - CI/CD y Automatización QA

**Descripción:** Colección de prompts efectivos para crear pipelines CI/CD de QA  
**Objetivo:** Usar prompts listos para producción en Copilot Chat  
**Tecnologías:** GitHub Actions, Python, Newman, Postman  
**Frameworks soportados:** GitHub Actions, Azure DevOps, Jenkins

---

## 🎯 CÓMO USAR ESTA LIBRERÍA

1. **Busca el prompt** por categoría (Workflow, Script, Reporte)
2. **Copia el prompt completo** (incluye PACES)
3. **Pega en Copilot Chat** (`Ctrl + Shift + I`)
4. **Reemplaza [PLACEHOLDER]** con tu contenido específico
5. **Personaliza** Audiencia y Contexto según tu caso

---

## 📊 TABLA DE CONTENIDOS

| # | Categoría | Prompt | Duración | Nivel |
|---|-----------|--------|----------|-------|
| 1.0 | WORKFLOW | Pipeline Básico Newman | 10 min | Principiante |
| 1.1 | WORKFLOW | Pipeline con Matrix | 15 min | Intermedio |
| 1.2 | WORKFLOW | Pipeline Multi-Environment | 15 min | Avanzado |
| 2.0 | SCRIPT | Smart Test Selection | 15 min | Intermedio |
| 2.1 | SCRIPT | Análisis de Impacto | 10 min | Intermedio |
| 3.0 | SCRIPT | Quality Gates Evaluator | 15 min | Intermedio |
| 3.1 | SCRIPT | Gates Personalizados | 10 min | Avanzado |
| 4.0 | REPORTE | Executive Report | 15 min | Intermedio |
| 4.1 | REPORTE | Technical Report | 10 min | Intermedio |
| 5.0 | INTEGRACIÓN | Pipeline Completo | 20 min | Avanzado |
| 5.1 | INTEGRACIÓN | PR Automation | 10 min | Avanzado |
| 6.0 | EXPLICACIÓN | GitHub Actions Basics | 5 min | Principiante |
| 6.1 | EXPLICACIÓN | CI/CD Best Practices | 5 min | Intermedio |

---

## 🔧 1.0 - WORKFLOW BÁSICO NEWMAN

**Cuando usarlo:** Primer pipeline para ejecutar tests Postman  
**Tiempo:** 10 minutos  
**Output:** Archivo YAML ejecutable

```markdown
PROPÓSITO: Crear workflow GitHub Actions para ejecutar tests Postman con Newman
AUDIENCIA: QE que configura CI/CD por primera vez
CONTEXTO: Proyecto bancario, colección [RUTA_COLLECTION], environment [RUTA_ENV]
EJEMPLOS: newman run local → newman run en GitHub Actions
SCOPE: Workflow YAML completo, triggers push/PR/schedule, upload de reportes

---

Crea archivo api-tests.yml para GitHub Actions:

REQUISITOS:
1️⃣ Triggers
   - push a [BRANCHES]
   - pull_request a main
   - schedule: [HORA] diario

2️⃣ Setup
   - ubuntu-latest
   - Node.js 18
   - Newman + reporter htmlextra

3️⃣ Ejecución
   - newman run con collection y environment
   - Reporters: cli, htmlextra, json
   - Timeout [TIMEOUT]ms por request
   - Delay [DELAY]ms entre requests

4️⃣ Artifacts
   - Upload reportes HTML y JSON
   - Retención [DIAS] días
   - Ejecutar aunque fallen tests (if: always())

5️⃣ Comentarios en español explicando cada step

ENTREGA: Archivo YAML completo y funcional
```

**Variante con notificaciones:**
```markdown
PROPÓSITO: Agregar notificaciones Slack/Teams al workflow
AUDIENCIA: QE que necesita alertas en canal del equipo
CONTEXTO: Workflow Newman existente, Slack webhook configurado
EJEMPLOS: Tests fail → mensaje Slack con resumen
SCOPE: Step adicional para notificaciones, solo si falla

---

Agrega step de notificación al workflow:

REQUISITOS:
- Ejecutar solo si tests fallan
- Mensaje con: tests pasados/fallidos, link a reporte, PR info
- Usar GitHub secret SLACK_WEBHOOK_URL
- Formato Slack Block Kit para mejor visualización

Generar step YAML completo.
```

---

## 🔧 1.1 - WORKFLOW CON MATRIX

**Cuando usarlo:** Ejecutar tests en múltiples ambientes/browsers  
**Tiempo:** 15 minutos  
**Output:** Workflow con estrategia matrix

```markdown
PROPÓSITO: Crear workflow con matrix para ejecutar tests en paralelo
AUDIENCIA: QE que necesita testing multi-ambiente
CONTEXTO: Misma suite de tests, múltiples environments (dev, staging, prod)
EJEMPLOS: 1 workflow → 3 ejecuciones paralelas, reporte consolidado
SCOPE: Matrix de environments + browsers, consolidación de resultados

---

Crea workflow con matrix strategy:

MATRIX:
- environment: [dev, staging, prod]
- Cada uno con su archivo .json de environment

REQUISITOS:
1️⃣ Jobs paralelos por environment
2️⃣ Artifacts separados por ambiente
3️⃣ Job final que consolide resultados
4️⃣ Fallar el workflow si cualquier ambiente falla
5️⃣ Timeout global de [MINUTOS] minutos

ESTRUCTURA:
jobs:
  run-tests:
    strategy:
      matrix:
        environment: [dev, staging, prod]
    ...
  
  consolidate:
    needs: run-tests
    ...

ENTREGA: Workflow YAML completo
```

---

## 🔧 1.2 - WORKFLOW MULTI-ENVIRONMENT

**Cuando usarlo:** Deploy y test progresivo (dev → staging → prod)  
**Tiempo:** 15 minutos  
**Output:** Pipeline con gates entre ambientes

```markdown
PROPÓSITO: Pipeline que promociona código entre ambientes con gates
AUDIENCIA: QE senior configurando pipeline de producción
CONTEXTO: Banco con ambientes dev/staging/prod, requiere aprobaciones
EJEMPLOS: dev tests OK → staging auto, staging OK → prod manual approval
SCOPE: 3 ambientes, gates automáticos y manuales, rollback plan

---

Crea pipeline multi-environment:

AMBIENTES:
1. DEV - Tests automáticos, deploy automático
2. STAGING - Tests automáticos, deploy con gate (success rate > 95%)
3. PROD - Tests smoke, deploy con aprobación manual

REQUISITOS:
1️⃣ Gate dev → staging: 95% success rate
2️⃣ Gate staging → prod: aprobación manual (environment protection)
3️⃣ Tests diferentes por ambiente:
   - DEV: suite completa
   - STAGING: regression + security
   - PROD: smoke tests (críticos)
4️⃣ Rollback automático si prod tests fallan

ENTREGA: Workflow YAML con 3 environments
```

---

## 🐍 2.0 - SMART TEST SELECTION

**Cuando usarlo:** Optimizar tiempo de CI/CD ejecutando solo tests relevantes  
**Tiempo:** 15 minutos  
**Output:** Script Python ejecutable

```markdown
PROPÓSITO: Crear script para selección inteligente de tests basada en cambios
AUDIENCIA: QE implementando CI/CD inteligente
CONTEXTO: Proyecto con módulos [LISTA_MODULOS], suite de [NUMERO] tests
EJEMPLOS: git diff → archivos cambiados → tests relacionados → newman grep
SCOPE: Script Python con mapeo módulo→tests y smoke tests obligatorios

---

Crea script smart-test-selector.py:

REQUISITOS:
1️⃣ Mapeo de módulos
   [Lista tus módulos y tests relacionados]
   - src/transfers → tests de transferencias
   - src/login → tests de login
   - src/security → tests de seguridad
   ...

2️⃣ Smoke tests (siempre ejecutar)
   [Lista tus smoke tests]
   - Health Check
   - Login básico
   ...

3️⃣ Lógica
   - Recibe archivos cambiados como argumento (CSV)
   - Detecta módulos afectados
   - Agrega tests correspondientes
   - Si no hay cambios específicos → suite completa

4️⃣ Output
   - Reporte en consola con estadísticas
   - Patrón grep para Newman (test1|test2|test3)
   - GitHub Actions outputs (::set-output)

5️⃣ Métricas
   - Tests a ejecutar
   - Tiempo estimado
   - Tiempo ahorrado vs suite completa

ENTREGA: Script Python con clase y main()
```

**Variante con análisis de dependencias:**
```markdown
PROPÓSITO: Mejorar smart selection con análisis de dependencias
AUDIENCIA: QE avanzado que necesita análisis más profundo
CONTEXTO: Proyecto con dependencias entre módulos (A depende de B)
EJEMPLOS: Cambio en módulo B → también ejecutar tests de módulo A
SCOPE: Grafo de dependencias + propagación de impacto

---

Extiende smart-test-selector.py:

AGREGAR:
1️⃣ Diccionario de dependencias
   DEPENDENCIES = {
       'src/auth': ['src/login', 'src/transfers'],  # auth afecta a login y transfers
       'src/database': ['*'],  # database afecta a todos
   }

2️⃣ Función analyze_dependencies()
   - Detecta cambios directos
   - Propaga a módulos dependientes
   - Evita duplicados

3️⃣ Reporte con impacto directo vs indirecto

Generar función adicional.
```

---

## 🐍 2.1 - ANÁLISIS DE IMPACTO

**Cuando usarlo:** Entender qué funcionalidades afecta un cambio  
**Tiempo:** 10 minutos  
**Output:** Reporte de impacto

```markdown
PROPÓSITO: Analizar impacto de cambios de código en funcionalidades
AUDIENCIA: QE que necesita comunicar riesgos a stakeholders
CONTEXTO: PR con cambios en [MODULOS], necesito reporte de impacto
EJEMPLOS: Cambio en auth → impacta login, transfers, payments
SCOPE: Análisis de impacto + priorización de tests + riesgos

---

Genera análisis de impacto para estos cambios:

ARCHIVOS CAMBIADOS:
[Lista de archivos]

ANALIZAR:
1️⃣ Funcionalidades afectadas directamente
2️⃣ Funcionalidades afectadas indirectamente
3️⃣ Tests críticos a ejecutar (priorizados)
4️⃣ Riesgos potenciales
5️⃣ Recomendación de testing

FORMATO REPORTE:
| Funcionalidad | Impacto | Tests | Riesgo |
|---------------|---------|-------|--------|

Incluir recomendación de merge (seguro/revisar/bloquear).
```

---

## 🔐 3.0 - QUALITY GATES EVALUATOR

**Cuando usarlo:** Automatizar decisiones de merge basadas en calidad  
**Tiempo:** 15 minutos  
**Output:** Script Python con exit codes

```markdown
PROPÓSITO: Crear evaluador de quality gates para CI/CD bancario
AUDIENCIA: QE automatizando control de calidad
CONTEXTO: Banco regulado, gates críticos: success rate, security, compliance
EJEMPLOS: JSON results → evaluación → PASS/FAIL → exit code
SCOPE: Script Python con 4+ gates, reporte JSON, exit codes

---

Crea script evaluate-quality-gates.py:

GATES REQUERIDOS:
1️⃣ test_success_rate
   - Threshold: [PORCENTAJE]%
   - Crítico: Sí
   - Input: stats.tests.passed/total

2️⃣ critical_vulnerabilities
   - Threshold: 0
   - Crítico: Sí
   - Input: security_scan.vulnerabilities

3️⃣ code_coverage
   - Threshold: [PORCENTAJE]%
   - Crítico: No (warning)
   - Input: coverage.percentage

4️⃣ compliance_sbs
   - Threshold: 100%
   - Crítico: Sí
   - Input: compliance.sbs_requirements_met

REQUISITOS:
1️⃣ Leer JSON de resultados (argumento)
2️⃣ Evaluar cada gate
3️⃣ Mostrar ✅/❌ en consola
4️⃣ Generar JSON con resultados
5️⃣ Exit codes: 0=OK, 1=FAIL

ENTREGA: Script Python ejecutable
```

**Variante con gates custom:**
```markdown
PROPÓSITO: Agregar gates personalizados al evaluador
AUDIENCIA: QE Lead que define estándares del equipo
CONTEXTO: Evaluador existente, necesito agregar gates de [AREA]
EJEMPLOS: Gate de performance (< 2s response time), gate de accessibility
SCOPE: Funciones adicionales para el evaluador

---

Agrega estos gates al evaluador:

GATES ADICIONALES:
1️⃣ performance_response_time
   - Threshold: < [MS] ms promedio
   - Input: timings.avgResponseTime

2️⃣ flaky_tests
   - Threshold: 0 tests flaky detectados
   - Input: flaky.detected_count

3️⃣ [TU_GATE_CUSTOM]
   - Threshold: [VALOR]
   - Input: [PATH_JSON]

Generar funciones _evaluate_*() para cada gate.
```

---

## 🔐 3.1 - GATES PERSONALIZADOS

**Cuando usarlo:** Definir criterios de calidad específicos del proyecto  
**Tiempo:** 10 minutos  
**Output:** Configuración de gates

```markdown
PROPÓSITO: Definir quality gates específicos para proyecto bancario
AUDIENCIA: QE Lead estableciendo estándares de calidad
CONTEXTO: Proyecto [NOMBRE], regulaciones [SBS/GDPR/PCI], riesgos [LISTA]
EJEMPLOS: Gate AML, gate de audit trail, gate de encriptación
SCOPE: 5-10 gates específicos con thresholds y criticidad

---

Define quality gates para este proyecto:

CONTEXTO REGULATORIO:
- Regulaciones: [LISTA]
- Riesgos principales: [LISTA]
- Tolerancia a errores: [BAJA/MEDIA/ALTA]

GENERAR GATES:
Para cada gate incluir:
1. Nombre descriptivo
2. Descripción (qué mide)
3. Threshold exacto
4. ¿Es crítico? (bloquea merge)
5. Input JSON esperado
6. Mensaje si falla

FORMATO:
| Gate | Threshold | Crítico | Input | Mensaje Falla |
|------|-----------|---------|-------|---------------|

Incluir diccionario Python GATES_CONFIG listo para copiar.
```

---

## 📊 4.0 - REPORTES EJECUTIVOS

**Cuando usarlo:** Traducir métricas técnicas para stakeholders  
**Tiempo:** 15 minutos  
**Output:** Script generador de reportes Markdown

```markdown
PROPÓSITO: Crear generador de reportes ejecutivos para stakeholders
AUDIENCIA: Product Owner, Gerencia, Auditoría (no técnicos)
CONTEXTO: Resultados de tests en JSON, necesitan insight de negocio
EJEMPLOS: "48/50 tests" → "96% de funcionalidades validadas ✅"
SCOPE: Script Python, output Markdown, recomendaciones de deploy

---

Crea script generate-executive-report.py:

SECCIONES REQUERIDAS:
1️⃣ Resumen Ejecutivo
   - Tabla con métricas clave
   - Status visual (emojis)
   - Recomendación principal

2️⃣ Análisis Detallado
   - Tests por área funcional
   - Comparación con baseline
   - Tendencias (si disponible)

3️⃣ Áreas Cubiertas
   - [TU_AREA_1]: lista de validaciones
   - [TU_AREA_2]: lista de validaciones
   - Security & Compliance

4️⃣ Recomendación de Negocio
   - ✅ SEGURO PARA DEPLOY
   - ❌ NO SEGURO - REVISAR PRIMERO
   - Justificación en lenguaje simple

5️⃣ Items que Requieren Atención
   - Lista de issues por severidad
   - Siguiente acción recomendada

6️⃣ Próximos Pasos
   - 3 acciones concretas

FORMATO:
- Markdown compatible con GitHub
- Emojis para visualización (✅❌⚠️🟢🟡🔴)
- Tablas para métricas
- NO usar jerga técnica

ENTREGA: Script Python con clase ExecutiveReportGenerator
```

---

## 📊 4.1 - REPORTES TÉCNICOS

**Cuando usarlo:** Reportes detallados para el equipo técnico  
**Tiempo:** 10 minutos  
**Output:** Reporte con detalles de debugging

```markdown
PROPÓSITO: Generar reporte técnico detallado para debugging
AUDIENCIA: QE y Developers que investigan fallos
CONTEXTO: Tests fallidos, necesito información para debug
EJEMPLOS: Stack trace, request/response, timing detallado
SCOPE: Reporte con todos los detalles técnicos

---

Crea función generate_technical_report():

SECCIONES:
1️⃣ Tests Fallidos (detalle)
   - Nombre del test
   - Request enviado (headers, body)
   - Response recibido
   - Assertion fallido
   - Stack trace si disponible

2️⃣ Performance Breakdown
   - Tiempo por request
   - Top 5 más lentos
   - Outliers detectados

3️⃣ Logs Relevantes
   - Últimos 50 logs del test
   - Filtrado por ERROR/WARN

4️⃣ Reproducción
   - Comando curl equivalente
   - Datos de test usados
   - Environment variables

FORMATO: Markdown con bloques de código
```

---

## 🔗 5.0 - PIPELINE COMPLETO

**Cuando usarlo:** Integrar todos los componentes en un pipeline  
**Tiempo:** 20 minutos  
**Output:** Workflow con 5+ jobs encadenados

```markdown
PROPÓSITO: Crear pipeline completo que integre selección, ejecución, gates y reportes
AUDIENCIA: QE configurando pipeline de producción
CONTEXTO: Scripts existentes (selector, gates, reporter), necesito integrarlos
EJEMPLOS: Job 1 → Job 2 → Job 3 con dependencias y artifacts
SCOPE: Workflow YAML con 5 jobs, outputs compartidos, comentario en PR

---

Crea workflow smart-qa-pipeline.yml:

JOBS REQUERIDOS:
1️⃣ detect-and-select
   - Checkout con fetch-depth: 0
   - Detectar archivos cambiados (git diff)
   - Ejecutar smart-test-selector.py
   - Outputs: tests-to-run, test-count

2️⃣ run-selected-tests
   - needs: detect-and-select
   - Newman con grep de Job 1
   - Upload artifacts (reportes)

3️⃣ evaluate-gates
   - needs: run-selected-tests
   - Download artifacts
   - evaluate-quality-gates.py
   - Upload gates report

4️⃣ generate-report
   - needs: [run-selected-tests, evaluate-gates]
   - generate-executive-report.py
   - Upload executive report

5️⃣ comment-pr
   - needs: [evaluate-gates, generate-report]
   - Solo en pull_request
   - gh pr comment con reporte

REQUISITOS:
- Outputs compartidos entre jobs
- Artifacts persistentes
- Manejo de errores (if: always())
- Comentarios en español

ENTREGA: Workflow YAML completo
```

---

## 🔗 5.1 - PR AUTOMATION

**Cuando usarlo:** Automatizar interacciones con Pull Requests  
**Tiempo:** 10 minutos  
**Output:** Steps de automatización PR

```markdown
PROPÓSITO: Automatizar labels, comments y checks en PRs
AUDIENCIA: QE que mejora developer experience
CONTEXTO: Pipeline existente, quiero agregar automación de PR
EJEMPLOS: Auto-label por archivos, comment con resumen, check status
SCOPE: Steps adicionales para workflow existente

---

Agrega automación de PR al workflow:

FUNCIONALIDADES:
1️⃣ Auto-labels basados en archivos
   - Cambios en src/api → label "api"
   - Cambios en tests/ → label "testing"
   - Cambios en docs/ → label "documentation"

2️⃣ Comment automático con:
   - Resumen de tests ejecutados
   - Link a reportes (artifacts)
   - Recomendación (merge/revisar)
   - Estadísticas de quality gates

3️⃣ Check status
   - Pending mientras ejecuta
   - Success/Failure según gates
   - Detalles en check summary

4️⃣ Auto-assign reviewer
   - Basado en CODEOWNERS
   - O según módulo afectado

Generar steps YAML para cada funcionalidad.
```

---

## 💡 6.0 - EXPLICACIÓN GITHUB ACTIONS BASICS

**Cuando usarlo:** Educar al equipo en fundamentos de CI/CD  
**Tiempo:** 5 minutos  
**Output:** Explicación clara y concisa

```markdown
PROPÓSITO: Explicar GitHub Actions para QE que no conoce CI/CD
AUDIENCIA: QE con experiencia en testing manual/Postman
CONTEXTO: Proyecto bancario, primera exposición a CI/CD
EJEMPLOS: Manual → Automático, Newman local → Newman en cloud
SCOPE: Conceptos básicos, sin profundizar en YAML

---

Explica GitHub Actions en términos simples:

ESTRUCTURA:
1️⃣ ¿Qué es? (analogía con testing manual)
2️⃣ ¿Por qué usarlo? (3 beneficios)
3️⃣ Componentes clave:
   - Workflow (el plan de testing)
   - Job (grupo de tareas)
   - Step (una tarea)
   - Trigger (cuándo ejecutar)
4️⃣ Diagrama ASCII del flujo
5️⃣ Ejemplo simple de workflow (comentado)

TONO: Simple, sin jerga, orientado a QE

Incluir tabla comparativa:
| Sin CI/CD | Con CI/CD |
|-----------|-----------|
| Ejecuto Newman manual | Newman se ejecuta solo |
| ...       | ...       |
```

---

## 💡 6.1 - CI/CD BEST PRACTICES

**Cuando usarlo:** Guía de mejores prácticas  
**Tiempo:** 5 minutos  
**Output:** Lista de best practices

```markdown
PROPÓSITO: Documentar mejores prácticas de CI/CD para QA
AUDIENCIA: Equipo QE que implementa pipelines
CONTEXTO: Proyecto bancario, múltiples pipelines, equipo de [N] personas
EJEMPLOS: DRY en workflows, secrets management, caching
SCOPE: Top 10 best practices con ejemplo de cada una

---

Lista mejores prácticas de CI/CD para QA:

CATEGORÍAS:
1️⃣ Performance
   - Caching de dependencias
   - Jobs paralelos
   - Smart test selection

2️⃣ Mantenibilidad
   - Workflows reutilizables
   - Variables y secrets
   - Comentarios claros

3️⃣ Seguridad
   - Never hardcode secrets
   - Least privilege principle
   - Audit de acciones third-party

4️⃣ Observabilidad
   - Logs estructurados
   - Métricas de pipeline
   - Alertas en fallas

5️⃣ Reliability
   - Retry en flaky
   - Timeout apropiados
   - Rollback automático

Para cada práctica:
- ❌ Antipatrón
- ✅ Mejor práctica
- Ejemplo de código

ENTREGA: Documento Markdown con 10+ prácticas
```

---

## 🎯 QUICK TIPS

### Cómo personalizar un prompt

```markdown
Reemplaza estos placeholders:

[RUTA_COLLECTION] → Tu ruta a colección Postman
[RUTA_ENV] → Tu ruta a environment
[BRANCHES] → main, develop, feature/*
[LISTA_MODULOS] → src/transfers, src/login, etc.
[PORCENTAJE] → 95, 80, etc.
```

### Cómo obtener mejores respuestas

1. **Sé específico en CONTEXTO**
   - ❌ "Pipeline para tests"
   - ✅ "Pipeline para 200 tests API en proyecto bancario regulado por SBS"

2. **Proporciona ESTRUCTURA existente**
   - ❌ "Crea un script"
   - ✅ "Crea script que lea JSON con esta estructura: {stats: {tests: {}}}"

3. **Define OUTPUTS claros**
   - ❌ "Genera reporte"
   - ✅ "Genera Markdown con tabla de métricas + recomendación + próximos pasos"

4. **Incluye EJEMPLOS**
   - ❌ Sin ejemplos = output genérico
   - ✅ "Ejemplo: cambio en src/auth → ejecutar tests de login, transfers"

---

## 📊 CHEATSHEET: Cuándo usar qué prompt

| Necesidad | Prompt | Tiempo |
|-----------|--------|--------|
| Primer pipeline | 1.0 Workflow Básico | 10 min |
| Tests en paralelo | 1.1 Matrix | 15 min |
| Optimizar CI/CD | 2.0 Smart Selection | 15 min |
| Control de calidad | 3.0 Quality Gates | 15 min |
| Reportes para jefes | 4.0 Executive Report | 15 min |
| Pipeline completo | 5.0 Integración | 20 min |
| Educar al equipo | 6.0 Explicación | 5 min |

---

## 🔧 TEMPLATES RÁPIDOS

### Template: Workflow Básico

```yaml
name: [NOMBRE]

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: [TU_PASO]
        run: [TU_COMANDO]
```

### Template: Prompt PACES

```markdown
PROPÓSITO: [Qué quieres lograr]
AUDIENCIA: [Para quién es]
CONTEXTO: [Información relevante del proyecto]
EJEMPLOS: [Antes → Después, Malo → Bueno]
SCOPE: [Límites y entregables]

---

[Tu solicitud específica aquí]
```

### Template: Quality Gate

```python
def _evaluate_[NOMBRE](self) -> Dict:
    """Gate: [DESCRIPCIÓN]"""
    
    value = self.results.get('[PATH]', {}).get('[KEY]', 0)
    threshold = self.GATES_CONFIG['[NOMBRE]']['threshold']
    passed = value >= threshold  # o <= según el gate
    
    return {
        'name': '[NOMBRE_VISIBLE]',
        'passed': passed,
        'value': f"{value}",
        'threshold': f"{threshold}",
        'details': f"[DETALLES]",
        'critical': [True/False]
    }
```

---

**LIBRERÍA DE PROMPTS COMPLETA** ✅

CI/CD y Automatización QA  
Mi Banco QE Team | Taller 6
