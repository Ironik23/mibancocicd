# Getting Started - TALLER 7 GHAS

## 🚀 Inicio en 10 minutos

### Paso 1: Configuración Inicial (2 min)

```bash
# Clonar repositorio
git clone https://github.com/tu-org/mi-banco-taller-7-ghas.git
cd mi-banco-taller-7-ghas

# Configurar git (primera vez)
git config user.name "Tu Nombre"
git config user.email "tu.email@mibanco.com"
```

### Paso 2: Instalar Dependencias (3 min)

```bash
# Python 3.8+
pip install -r requirements.txt

# Verificar instalación
python --version
```

### Paso 3: Ejecutar Setup (3 min)

```bash
# Linux/Mac
bash scripts/setup_ghas.sh

# Windows PowerShell
python scripts/setup_ghas.py
```

### Paso 4: Verificar Setup (2 min)

```bash
python scripts/validate_compliance.py
```

---

## 📚 Próximos Pasos

### Opción A: Aprender desde Cero
1. Lee: `docs/GHAS_BASICS.md`
2. Ejecuta: `labs/lab-1-codeql/README.md`
3. Continúa: Labs 2-6 en orden

### Opción B: Aprendizaje Acelerado
1. Lee: `TALLER_7_CHEAT_SHEET.md` (5 min)
2. Copia: Workflows desde `templates/`
3. Personaliza: `config/pci-compliance-policy.yml`

### Opción C: Para Facilitadores
1. Lee: `Taller_7_QE_Guia_Presentador.md`
2. Abre: `Taller_7_QE_Presentacion.md`
3. Ejecuta: Labs en el orden indicado

---

## 🎯 Objetivos por Sesión

| Sesión | Duración | Objetivo | Lab |
|--------|----------|----------|-----|
| 1 | 20 min | Entender CodeQL | Lab 1 |
| 2 | 20 min | Configurar Dependabot | Lab 2 |
| 3 | 15 min | Políticas de rama | Lab 3 |
| 4 | 15 min | Ver el dashboard | Lab 4 |
| 5 | 20 min | Remediar código | Lab 5 |
| 6 | 30 min | Queries personalizadas | Lab 6 |

---

## 🔍 Archivos Clave

```
README.md                          ← Estás aquí
GETTING_STARTED.md                 ← Este archivo
Taller_7_QE_Presentacion.md        ← Presentación completa
Taller_7_QE_Guia_Presentador.md    ← Guía para facilitadores
Taller_7_QE_Codigo_Ejecutable.md   ← Labs y código
TALLER_7_CHEAT_SHEET.md            ← Referencia rápida
docs/CODEQL_GUIDE.md               ← Deep dive CodeQL
docs/DEPENDABOT_GUIDE.md           ← Deep dive Dependabot
00_TALLER_7_RESUMEN_EJECUTIVO.md   ← Resumen ejecutivo
```

---

## ❓ Preguntas Frecuentes

**¿Cuánto tiempo toma?**
- Quick Start: 5-10 minutos
- Labs completos: 2 horas
- Implementación full: 1-2 semanas

**¿Necesito experiencia previa?**
- Básica en Git: SÍ
- Básica en GitHub: SÍ
- Experiencia GHAS: NO (lo aprendes aquí)

**¿Funciona en Windows/Mac/Linux?**
- SÍ, todos funcionan
- Scripts disponibles en bash y PowerShell

**¿Puedo usar esto en producción?**
- SÍ, es production-ready
- PCI DSS compliant
- Incluye validación automática

---

## 🛠️ Solución de Problemas

### Problema: "git not found"
```bash
# Instalar Git
# Windows: https://git-scm.com/download/win
# Mac: brew install git
# Linux: apt-get install git
```

### Problema: "Python version mismatch"
```bash
# Verificar versión
python3 --version

# Debe ser 3.8 o superior
# Si no, instala desde python.org
```

### Problema: "Permission denied"
```bash
# En Mac/Linux, hacer ejecutable
chmod +x scripts/*.sh
chmod +x scripts/*.py
```

### Problema: "Cannot connect to GitHub"
```bash
# Verificar conexión
git config --list | grep github

# Configurar token
gh auth login
```

---

## 📞 Soporte

- 📖 Documentación: `docs/`
- ❓ FAQs: `docs/TROUBLESHOOTING.md`
- 💬 Issues: GitHub Issues
- 🆘 Help: ghas-team@mibanco.com

---

## 🎓 Duración Típica

```
Setup:              5-10 minutos
Lab 1 (CodeQL):     20 minutos
Lab 2 (Dependabot): 20 minutos
Lab 3 (Policies):   15 minutos
Lab 4 (Dashboard):  15 minutos
Lab 5 (Fix):        20 minutos
Lab 6 (Custom):     30 minutos
───────────────────────────────
TOTAL:              ~2 horas
```

---

## ✅ Checklist de Setup

- [ ] Git instalado y configurado
- [ ] Python 3.8+ instalado
- [ ] Repositorio clonado
- [ ] Dependencias instaladas (pip install -r requirements.txt)
- [ ] Setup ejecutado (python scripts/setup_ghas.py)
- [ ] Validación completada (python scripts/validate_compliance.py)
- [ ] Acceso a GitHub: habilitado
- [ ] Listo para Lab 1

---

¡**Ahora sí, comencemos!** 🚀

Ejecuta: `cd labs/lab-1-codeql && cat README.md`
