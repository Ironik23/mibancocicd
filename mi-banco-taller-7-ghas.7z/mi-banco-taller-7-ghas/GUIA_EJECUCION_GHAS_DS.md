# 🔐 Guía de Ejecución Práctica - Taller 7: GitHub Advanced Security para Data Science

**Facilitador:** GitHub Copilot  
**Objetivo:** Implementar seguridad y gobernanza en proyectos de ML/AI usando GHAS  
**Duración:** 2 horas (120 minutos)  
**Tecnologías:** GitHub Advanced Security, CodeQL, Copilot Autofix, Python, Jupyter  

**🔹 IMPORTANTE:** Este taller utiliza **GitHub Advanced Security (GHAS) en la nube**. Todo el análisis se ejecuta automáticamente en GitHub Actions y los resultados se visualizan en el Security tab de GitHub. **No requiere instalación local de CodeQL CLI** (aunque se incluyen secciones opcionales avanzadas para quien desee explorar análisis local).

**Requisitos Previos:**
- ✅ **Cuenta GitHub con GHAS y Copilot habilitados** (OBLIGATORIO)
- ✅ VS Code con extensiones: Copilot Chat, Python, Jupyter
- ✅ Python 3.8+ con entorno virtual
- ✅ Git configurado
- ✅ Conocimientos de Python, pandas, scikit-learn
- ✅ Repositorio `mi-banco-taller-7-ghas` clonado y pusheado a GitHub
- ✅ Familiaridad con notebooks y modelos ML
- ⚠️ CodeQL CLI (OPCIONAL - solo para análisis local avanzado)

💡 **TIP:** Abre `LIBRERIA_PROMPTS_GHAS.md` en paralelo para consultar prompts mientras trabajas.

---

## ⚡ QUICKSTART (Primeros 5 minutos)

### Paso 1: Prepara el entorno

```powershell
# En VS Code
code .

# Abre Copilot Chat
Ctrl + Shift + I

# Crea entorno virtual
python -m venv venv
.\venv\Scripts\Activate.ps1

# Instala dependencias
pip install -r requirements.txt
```

### Paso 2: Verifica archivos existentes
- **src/models/** - Modelos ML con vulnerabilidades ⚠️
- **examples/python/** - Código Python para análisis
- **labs/** - Laboratorios prácticos
- **tests/** - Tests de seguridad para ML

### Paso 3: Estructura del taller

| Módulo | Tema | Duración | Enfoque DS |
|--------|------|----------|------------|
| 1 | Seguridad en ML/AI | 15 min | Riesgos específicos de ML |
| 2 | CodeQL para Python DS | 25 min | Detectar bugs en código ML |
| 3 | Dependency Security | 20 min | Validar librerías ML (numpy, pandas, etc.) |
| 4 | IA Responsable y Gobernanza | 30 min | Bias, fairness, explicabilidad |
| 5 | Secrets en Notebooks | 15 min | API keys, credenciales |
| 6 | Automatización DS Security | 15 min | CI/CD para modelos ML |

---

## 📚 FLUJO POR MÓDULO

### MÓDULO 1: Seguridad en Machine Learning (15 minutos)

#### Actividad 1A: Entender Riesgos de Seguridad en ML (8 min)

**PASO 1:** Abre Copilot Chat (`Ctrl + Shift + I`)

**PASO 2:** Copia este prompt PACES:

```
PROPÓSITO: Explicar riesgos de seguridad específicos de ML/AI
AUDIENCIA: Data Scientist que desarrolla modelos predictivos en banca
CONTEXTO: Proyecto Mi Banco - modelos de scoring crediticio, detección de fraude
EJEMPLOS: Model poisoning, adversarial attacks, data leakage, bias
SCOPE: 5 riesgos principales con ejemplos bancarios

---

Explica los riesgos de seguridad en ML para un Data Scientist bancario:

1. **Model Poisoning**
   - ¿Qué es?
   - Ejemplo: Atacante contamina datos de entrenamiento
   - Impacto en scoring crediticio

2. **Adversarial Attacks**
   - ¿Qué es?
   - Ejemplo: Input diseñado para engañar el modelo
   - Impacto en detección de fraude

3. **Data Leakage**
   - ¿Qué es?
   - Ejemplo: Features que no estarán disponibles en producción
   - Impacto en predicciones

4. **Model Inversion**
   - ¿Qué es?
   - Ejemplo: Inferir datos de entrenamiento desde el modelo
   - Impacto en privacidad de clientes

5. **Bias y Fairness**
   - ¿Qué es?
   - Ejemplo: Modelo discrimina por género/edad
   - Impacto regulatorio y reputacional

Para cada uno incluye:
- Definición simple
- Cómo se manifiesta en banking
- Cómo detectarlo
- Cómo prevenirlo

Usa lenguaje DS, no de seguridad tradicional.
```

**PASO 3:** Documenta los riesgos en `docs/ml-security-risks.md`

**PASO 4:** Pregunta a Copilot sobre responsabilidades:

```
PROPÓSITO: Definir responsabilidades de DS en seguridad de modelos
AUDIENCIA: Data Scientist ampliando scope a seguridad
CONTEXTO: Equipo bancario con regulación SBS y compliance estricto
EJEMPLOS: Validar accuracy → Validar accuracy + fairness + explicabilidad
SCOPE: 6 responsabilidades concretas con métricas

---

Lista las 6 responsabilidades de seguridad de un Data Scientist:

Para cada una:
- Descripción técnica
- Ejemplo en modelo de credit scoring
- Métrica para medir cumplimiento
- Herramienta GHAS/GitHub que ayuda
- Consecuencia si se ignora

Incluye aspectos de:
- Seguridad técnica (code vulnerabilities)
- Seguridad de datos (PII, GDPR)
- IA Responsable (bias, fairness, explicabilidad)
- Gobernanza (versioning, auditoría)

Formato tabla Markdown con columnas.
```

**VALIDACIÓN:**
- [ ] 5 riesgos de ML documentados
- [ ] 6 responsabilidades definidas
- [ ] Ejemplos bancarios claros

**TIEMPO:** 8 minutos

---

#### Actividad 1B: Auditar Notebook Vulnerable (7 min)

**PASO 1:** Abre `examples/python/vulnerable_ml_notebook.ipynb`

**PASO 2:** En Copilot Chat, audita el notebook:

```
PROPÓSITO: Identificar problemas de seguridad en notebook ML
AUDIENCIA: Data Scientist aprendiendo security best practices
CONTEXTO: Notebook de credit scoring con múltiples vulnerabilidades
EJEMPLOS: API keys hardcoded, data leakage, PII exposure, no reproducibilidad
SCOPE: Lista completa de issues con severidad y remediación

---

Analiza el notebook vulnerable_ml_notebook.ipynb:

Busca y documenta:
1. **Secrets expuestos**
   - API keys, passwords, tokens hardcoded
   - Dónde están (celda #)
   - Impacto: acceso no autorizado

2. **PII sin protección**
   - Datos personales en logs/prints
   - Visualizaciones que exponen identidad
   - Impacto: violación GDPR/SBS

3. **Data Leakage**
   - Features usando información del futuro
   - Target leakage en features
   - Impacto: modelo no funciona en producción

4. **Falta de reproducibilidad**
   - Sin random seeds
   - Sin versionado de datos
   - Impacto: resultados no reproducibles

5. **Dependencias inseguras**
   - Librerías sin versión fija
   - Imports innecesarios
   - Impacto: supply chain attacks

6. **Code injection risks**
   - eval() / exec()
   - SQL queries sin parametrizar
   - Impacto: ejecución de código malicioso

Para cada issue:
- Severidad: CRÍTICA/ALTA/MEDIA/BAJA
- Línea/celda donde ocurre
- Explicación técnica
- Cómo corregirlo
- Código corregido

Formato Markdown con bloques de código.
```

**PASO 3:** Compara con versión segura (si existe) o genera correcciones

**VALIDACIÓN:**
- [ ] Mínimo 6 tipos de vulnerabilidades identificados
- [ ] Código corregido para cada una
- [ ] Impacto de negocio entendido

**TIEMPO:** 7 minutos

---

### MÓDULO 2: CodeQL para Data Science (25 minutos)

> **📌 NOTA:** Este módulo usa **CodeQL en GitHub Actions** (en la nube). Los análisis se ejecutan automáticamente en cada push/PR y los resultados aparecen en `GitHub → Security → Code scanning alerts`. No necesitas instalar nada localmente.

#### Actividad 2A: Configurar CodeQL para Python DS (10 min)

**PASO 1:** En Copilot Chat, solicita configuración específica para DS:

```
PROPÓSITO: Configurar CodeQL con queries específicas para Data Science
AUDIENCIA: Data Scientist configurando análisis de seguridad
CONTEXTO: Proyecto Python con notebooks, pandas, scikit-learn, tensorflow
EJEMPLOS: Detectar eval(), pickle inseguro, SQL injection en queries pandas
SCOPE: Workflow YAML + custom queries para ML

---

Crea workflow CodeQL optimizado para Data Science:

REQUISITOS:
1️⃣ Triggers
   - push a main/develop
   - pull_request a main
   - schedule: análisis nocturno 3 AM

2️⃣ Lenguaje
   - Python con foco en librerías DS

3️⃣ Queries específicas DS:
   - Insecure deserialization (pickle.load sin validar)
   - Use of eval/exec en notebooks
   - SQL injection en pandas.read_sql
   - Hardcoded secrets en notebooks
   - Unvalidated user input en modelos
   - Missing random seeds (reproducibilidad)

4️⃣ Exclusiones
   - Notebooks checkpoint (.ipynb_checkpoints)
   - Data folders (data/, datasets/)
   - Model artifacts (*.pkl, *.h5)

5️⃣ Configuración
   - Upload resultados a GitHub Security
   - Generar SARIF para integración
   - Notificar en Slack si hay CRITICAL

ENTREGA: .github/workflows/codeql-ds-analysis.yml
```

**Referencias:**
- Lab: `labs/lab-1-codeql/README.md`
- Custom queries: `.codeql/custom-queries/` (ya disponibles en el repo)

**PASO 2:** Crea el archivo workflow en `.github/workflows/codeql-ds-analysis.yml`

**PASO 3:** 🔷 **[OPCIONAL - AVANZADO]** Crea queries custom adicionales de CodeQL para ML:

> ⚠️ **NOTA:** El repositorio ya incluye 6 queries personalizadas en `.codeql/custom-queries/`. Esta sección es opcional para usuarios avanzados que quieran crear queries adicionales. **Puedes omitir este paso** y usar las queries existentes.

```
PROPÓSITO: Crear query CodeQL custom para detectar pickle inseguro
AUDIENCIA: Data Scientist avanzado que quiere custom rules
CONTEXTO: Pickle es común en ML pero inseguro si no se valida
EJEMPLOS: pickle.load(open('model.pkl')) sin verificar origen
SCOPE: Query .ql funcional

---

Crea query CodeQL que detecte uso inseguro de pickle:

Detectar:
- pickle.load() sin verificación de origen
- pickle.loads() con datos de usuario
- joblib.load() sin validación

No alertar si:
- Archivo viene de path interno fijo
- Hay validación previa con hash/signature

Query en formato .ql con:
- Metadata (name, description, severity)
- Import de librerías Python
- Lógica de detección
- Explicación de la vulnerabilidad

ENTREGA: queries/insecure-pickle.ql
```

**PASO 4:** Commit y push para activar CodeQL en GitHub

```powershell
git add .github/workflows/codeql-ds-analysis.yml
git commit -m "feat: Agregar CodeQL para Data Science"
git push origin main
```

**PASO 5:** Verifica ejecución en GitHub:

1. Ve a tu repositorio en GitHub.com
2. Click en tab **"Actions"**
3. Verifica que el workflow "CodeQL DS Analysis" se está ejecutando
4. Espera 3-5 minutos a que termine
5. Ve a tab **"Security" → "Code scanning"**
6. Deberías ver alertas detectadas en el código vulnerable

**VALIDACIÓN:**
- [ ] Workflow creado y ejecutado **en GitHub Actions**
- [ ] Queries custom incluidas en el análisis (ver `.codeql/custom-queries/`)
- [ ] Alertas visibles en **GitHub Security tab**
- [ ] Puedes ver detalles de cada alerta (ubicación, severidad, recomendación)

**TIEMPO:** 10 minutos

---

#### Actividad 2B: Analizar y Remediar Alertas DS (15 min)

> **📌 WORKFLOW:** Las alertas se analizan directamente en **GitHub.com**, no en VS Code. Copilot Autofix está integrado en la interfaz web de GitHub.

**PASO 1:** Navega a **GitHub.com → Tu Repositorio → Security → Code scanning alerts**

**PASO 2:** Selecciona una alerta (ej: "Insecure deserialization in pickle.load")

**PASO 3:** En la página de la alerta, verás:
- 📍 Ubicación exacta del código vulnerable
- 📊 Severidad (Critical/High/Medium/Low)
- 📝 Explicación del problema
- 💡 **Botón "Generate fix with Copilot"** ← Click aquí

**PASO 4:** Copilot Autofix generará una remediación automática. Revísala y aplícala.

**PASO 5 (Alternativo):** Si prefieres trabajar en VS Code, usa Copilot Chat con este prompt:

```
PROPÓSITO: Remediar alertas de CodeQL con Copilot Autofix
AUDIENCIA: Data Scientist corrigiendo vulnerabilidades
CONTEXTO: Alerta de pickle inseguro en modelo ML
EJEMPLOS: pickle.load → validación + pickle.load
SCOPE: Corrección + test de validación

---

Para esta alerta de CodeQL:

[PEGA ALERTA AQUÍ - ejemplo: "Insecure deserialization in pickle.load"]

1. Explica el riesgo en términos de ML
   - ¿Qué puede hacer un atacante?
   - ¿Cómo impacta el modelo en producción?

2. Genera código corregido que:
   - Valide integridad del archivo (hash SHA-256)
   - Use allowlist de clases permitidas
   - Log intentos de carga sospechosos
   - Maneje errores apropiadamente

3. Crea test unitario que valide:
   - Pickle legítimo se carga OK
   - Pickle manipulado falla validación
   - Error logging funciona

4. Documenta en docstring:
   - Por qué es necesaria la validación
   - Cómo usar la función segura

ENTREGA: Código corregido + test + docs
```

**PASO 6:** Commit y push la corrección:

```powershell
git add <archivo-corregido>
git commit -m "fix: Remediar pickle inseguro con validación de hash"
git push origin main
```

**PASO 7:** Verifica en GitHub que la alerta se marcó como "Fixed" después del análisis.

**PASO 8:** Para alertas comunes en DS, documenta patrones de remediación:

```markdown
# Patrones de Remediación DS

## 1. Insecure Pickle
**Problema:** pickle.load sin validación
**Solución:**
```python
import pickle
import hashlib

def load_model_secure(filepath, expected_hash):
    """Carga modelo validando integridad"""
    # Calcular hash del archivo
    with open(filepath, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    
    if file_hash != expected_hash:
        raise ValueError("Model file integrity check failed")
    
    # Cargar solo si hash coincide
    with open(filepath, 'rb') as f:
        model = pickle.load(f)
    
    return model
```
**Test:** Ver tests/test_secure_pickle.py

## 2. SQL Injection en pandas
**Problema:** pandas.read_sql con f-strings
**Solución:**
```python
# ❌ Vulnerable
query = f"SELECT * FROM transactions WHERE user_id = {user_id}"
df = pd.read_sql(query, conn)

# ✅ Seguro
query = "SELECT * FROM transactions WHERE user_id = ?"
df = pd.read_sql(query, conn, params=(user_id,))
```

## 3. Eval/Exec en notebooks
**Problema:** eval(user_input) para features dinámicas
**Solución:**
```python
# ❌ Vulnerable
feature = eval(feature_expression)

# ✅ Seguro - usar ast.literal_eval o allowlist
import ast
allowed_functions = {'sum', 'mean', 'max', 'min'}

def safe_eval(expression):
    tree = ast.parse(expression, mode='eval')
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if node.func.id not in allowed_functions:
                raise ValueError(f"Function {node.func.id} not allowed")
    return ast.literal_eval(expression)
```
```

**VALIDACIÓN:**
- [ ] Todas las alertas analizadas
- [ ] Correcciones aplicadas
- [ ] Tests creados
- [ ] Patrones documentados

**TIEMPO:** 15 minutos

---

### MÓDULO 3: Dependency Security para DS (20 minutos)

#### Actividad 3A: Configurar Dependabot para librerías ML (10 min)

> **📌 NOTA:** Dependabot se configura con un archivo YAML y se ejecuta automáticamente en GitHub. Los PRs de actualización aparecen en tu repositorio.

**PASO 1:** En Copilot Chat, genera configuración de Dependabot:

```
PROPÓSITO: Configurar Dependabot para dependencias de Data Science
AUDIENCIA: Data Scientist gestionando librerías ML
CONTEXTO: requirements.txt con numpy, pandas, scikit-learn, tensorflow, etc.
EJEMPLOS: Vulnerabilidad en numpy → Dependabot crea PR → Review & merge
SCOPE: dependabot.yml optimizado para DS

---

Crea configuración Dependabot para proyecto DS:

REQUISITOS:
1️⃣ Ecosistema: pip (Python)
2️⃣ Archivos a monitorear:
   - requirements.txt (producción)
   - requirements-dev.txt (desarrollo)
   - notebooks/requirements-notebooks.txt (notebooks)
3️⃣ Schedule: 
   - weekly para requirements.txt
   - monthly para dev/notebooks
4️⃣ Grupos de dependencias:
   - ml-core: numpy, pandas, scikit-learn
   - deep-learning: tensorflow, pytorch, keras
   - visualization: matplotlib, seaborn, plotly
5️⃣ Auto-merge para:
   - Patch updates de librerías estables
   - Security updates siempre
6️⃣ Reviewers: @mi-banco-ds-team
7️⃣ Labels: dependencies, data-science, security

ENTREGA: .github/dependabot.yml
```

**PASO 2:** Crea el archivo `.github/dependabot.yml` con la configuración generada

**PASO 3:** Commit y push:

```powershell
git add .github/dependabot.yml
git commit -m "feat: Configurar Dependabot para librerías ML"
git push origin main
```

**PASO 4:** Habilita Dependabot alerts en GitHub:

1. Ve a **GitHub.com → Tu Repo → Settings**
2. Click en **"Code security and analysis"**
3. Habilita:
   - ✅ Dependency graph
   - ✅ Dependabot alerts
   - ✅ Dependabot security updates

**PASO 5:** Dentro de 1-2 minutos, verás PRs automáticos de Dependabot si hay vulnerabilidades.

**PASO 6 (Opcional):** Configura políticas de auto-merge para security patches:

```yaml
# .github/workflows/dependabot-auto-merge.yml
name: Dependabot Auto-Merge
on: pull_request

jobs:
  auto-merge:
    runs-on: ubuntu-latest
    if: github.actor == 'dependabot[bot]'
    steps:
      - name: Check if security update
        id: check
        run: |
          if [[ "${{ github.event.pull_request.title }}" == *"security"* ]]; then
            echo "is_security=true" >> $GITHUB_OUTPUT
          fi
      
      - name: Auto-merge security updates
        if: steps.check.outputs.is_security == 'true'
        run: gh pr merge --auto --squash "$PR_URL"
        env:
          PR_URL: ${{github.event.pull_request.html_url}}
          GITHUB_TOKEN: ${{secrets.GITHUB_TOKEN}}
```

**VALIDACIÓN:**
- [ ] Dependabot configurado en `.github/dependabot.yml`
- [ ] Dependabot alerts habilitado en **GitHub Settings**
- [ ] Grupos de dependencias definidos
- [ ] Ves PRs automáticos de Dependabot en **GitHub Pull Requests**
- [ ] Auto-merge para security activo (opcional)

**TIEMPO:** 10 minutos

---

#### Actividad 3B: Validar Compatibilidad de Dependencias (10 min)

**PASO 1:** Crea script de validación de compatibilidad:

```
PROPÓSITO: Validar que updates de dependencias no rompan modelos
AUDIENCIA: Data Scientist evitando breaking changes
CONTEXTO: Update de sklearn puede cambiar resultados de modelo
EJEMPLOS: sklearn 1.0 → 1.3 cambia default de n_estimators
SCOPE: Script que valida reproducibilidad post-update

---

Crea scripts/validate-ml-dependencies.py:

VALIDACIONES:
1️⃣ Version compatibility
   - Verificar compatibilidad entre librerías
   - numpy <-> pandas <-> scikit-learn
   - tensorflow <-> keras versiones

2️⃣ Model reproducibility
   - Cargar modelo pre-existente
   - Re-entrenar con mismas semillas
   - Comparar predicciones (tolerancia < 0.001)
   - Alertar si hay diferencias

3️⃣ Performance benchmarks
   - Tiempo de entrenamiento no aumenta >10%
   - Tiempo de inferencia no aumenta >5%
   - Memoria no aumenta >15%

4️⃣ API compatibility
   - Verificar que funciones usadas siguen existiendo
   - Deprecation warnings → FAIL

REQUISITOS:
- Leer requirements.txt antes y después
- Ejecutar suite de tests ML
- Comparar métricas: accuracy, precision, recall
- Exit code: 0=OK, 1=Breaking change detected
- Reporte JSON con detalles

ENTREGA: Script Python ejecutable
```

**PASO 2:** Integra en workflow de Dependabot:

```yaml
# Agregar a PR checks
- name: Validate ML Dependencies
  run: |
    python scripts/validate-ml-dependencies.py \
      --old requirements.txt.old \
      --new requirements.txt \
      --model examples/python/credit_model.pkl \
      --test-data examples/python/test_data.csv
```

**PASO 3:** Prueba con un cambio de versión:

```powershell
# Simular update de sklearn
pip install scikit-learn==1.3.0
python scripts/validate-ml-dependencies.py
```

**VALIDACIÓN:**
- [ ] Script funcional
- [ ] Detecta breaking changes
- [ ] Integrado en CI/CD

**TIEMPO:** 10 minutos

---

### MÓDULO 4: IA Responsable y Gobernanza (30 minutos)

#### Actividad 4A: Detectar y Medir Bias (15 min)

**PASO 1:** En Copilot Chat, genera código para análisis de fairness:

```
PROPÓSITO: Detectar bias en modelo de credit scoring
AUDIENCIA: Data Scientist validando fairness
CONTEXTO: Modelo predictivo bancario, regulación SBS anti-discriminación
EJEMPLOS: Modelo rechaza más mujeres que hombres con mismo perfil
SCOPE: Script Python que mide disparate impact

---

Crea scripts/detect-model-bias.py:

MÉTRICAS A CALCULAR:
1️⃣ Disparate Impact
   - Por género (M/F)
   - Por edad (<30, 30-50, >50)
   - Por zona geográfica
   - Threshold: ratio debe estar entre 0.8-1.25

2️⃣ Equal Opportunity
   - TPR debe ser similar entre grupos
   - Threshold: diferencia < 10%

3️⃣ Equalized Odds
   - TPR y FPR similares entre grupos
   - Threshold: diferencia < 5%

4️⃣ Statistical Parity
   - Tasa de aprobación similar
   - Threshold: diferencia < 10%

REQUISITOS:
- Leer modelo y datos de test
- Calcular métricas por grupo protegido
- Visualizar con gráficos (matplotlib)
- Generar reporte HTML
- Exit code: 0=Fair, 1=Bias detected
- Incluir recomendaciones de mitigación

ENTREGA: Script con clase BiasDetector
```

**PASO 2:** Ejecuta análisis en modelo existente:

```powershell
python scripts/detect-model-bias.py `
  --model examples/python/credit_model.pkl `
  --data examples/python/test_data.csv `
  --protected-attributes gender,age,region `
  --output reports/fairness-report.html
```

**PASO 3:** Si hay bias, genera código de mitigación:

```
PROPÓSITO: Mitigar bias detectado en modelo
AUDIENCIA: Data Scientist corrigiendo fairness issues
CONTEXTO: Disparate impact de 0.65 en género (threshold 0.8)
EJEMPLOS: Reweighting, resampling, threshold optimization
SCOPE: Código ejecutable que reduce bias

---

Genera código de mitigación para bias detectado:

TÉCNICAS:
1. Reweighting
   - Ajustar pesos de muestras
   - Balancear representación

2. Threshold Optimization
   - Diferentes thresholds por grupo
   - Mantener accuracy global

3. Adversarial Debiasing
   - Entrenar con adversary que detecta grupo
   - Penalizar predicciones que revelan grupo

Incluir:
- Código completo en Python
- Métricas antes y después
- Trade-off accuracy vs fairness
- Validación que bias se redujo

FORMATO: Notebook ejecutable con explicaciones
```

**VALIDACIÓN:**
- [ ] Script de detección funcional
- [ ] Métricas de fairness calculadas
- [ ] Bias detectado (si aplica)
- [ ] Estrategia de mitigación definida

**TIEMPO:** 15 minutos

---

#### Actividad 4B: Explicabilidad y Trazabilidad (15 min)

**PASO 1:** Implementa explicabilidad con SHAP:

```
PROPÓSITO: Agregar explicabilidad a modelo de credit scoring
AUDIENCIA: Data Scientist cumpliendo con right-to-explanation
CONTEXTO: SBS requiere explicar decisiones de crédito a clientes
EJEMPLOS: "Crédito rechazado porque: ingresos bajos (30%), historial (40%)"
SCOPE: Integración de SHAP values en pipeline

---

Crea scripts/explain-model.py usando SHAP:

REQUISITOS:
1️⃣ Calcular SHAP values para cada predicción
2️⃣ Generar explicaciones en lenguaje natural:
   - Top 3 features que contribuyeron
   - Dirección del impacto (positivo/negativo)
   - Magnitud del impacto (%)
3️⃣ Visualizaciones:
   - SHAP summary plot (global)
   - SHAP waterfall plot (individual)
   - Feature importance
4️⃣ Exportar explicaciones:
   - JSON para API
   - HTML para auditoría
   - PDF para cliente
5️⃣ Validar explicaciones:
   - Sumar a prediction
   - Consistencia entre explicaciones

ENTREGA: Script + ejemplos de uso
```

**PASO 2:** Implementa model lineage y versioning:

```
PROPÓSITO: Trazabilidad completa de modelos ML
AUDIENCIA: Data Scientist implementando MLOps governance
CONTEXTO: Auditoría requiere saber qué modelo generó qué predicción
EJEMPLOS: Tracking de datos, código, hiperparámetros, métricas
SCOPE: Sistema de versionado de modelos

---

Diseña sistema de model governance:

METADATA A TRACKEAR:
1. Identificación
   - Model ID único
   - Version semántica (1.2.3)
   - Timestamp de entrenamiento
   - Owner (Data Scientist)

2. Datos de entrenamiento
   - Dataset ID y versión
   - Hash SHA-256 de datos
   - Fecha de extracción
   - Queries SQL usados

3. Código y configuración
   - Git commit hash
   - Hyperparameters
   - Features usados
   - Transformaciones aplicadas

4. Métricas de performance
   - Accuracy, Precision, Recall
   - Fairness metrics
   - Performance benchmarks

5. Aprobaciones y compliance
   - Reviewer aprobador
   - Fecha de aprobación
   - Tests de seguridad pasados
   - Compliance checks (SBS, GDPR)

IMPLEMENTACIÓN:
- Usar MLflow o similar
- Integrar con GitHub releases
- Almacenar en model registry
- API para query de metadata

ENTREGA: Diagrama de arquitectura + código inicial
```

**PASO 3:** Integra explicabilidad en API de predicción:

```python
# Agregar endpoint /explain
@app.route('/predict-explain', methods=['POST'])
def predict_with_explanation():
    data = request.json
    
    # Predecir
    prediction = model.predict(data)
    
    # Explicar
    explanation = explainer.explain_instance(
        data, 
        model.predict_proba,
        num_features=5
    )
    
    return {
        'prediction': prediction,
        'explanation': {
            'top_features': explanation.top_features,
            'shap_values': explanation.shap_values,
            'natural_language': explanation.to_text()
        },
        'metadata': {
            'model_version': MODEL_VERSION,
            'model_id': MODEL_ID,
            'timestamp': datetime.now()
        }
    }
```

**VALIDACIÓN:**
- [ ] SHAP integrado
- [ ] Explicaciones generadas
- [ ] Model lineage implementado
- [ ] Metadata trackeado

**TIEMPO:** 15 minutos

---

### MÓDULO 5: Secrets en Notebooks (15 minutos)

#### Actividad 5A: Detectar y Remediar Secrets (15 min)

> **📌 NOTA:** Secret Scanning se ejecuta automáticamente en GitHub después de habilitarlo. Las alertas aparecen en el Security tab.

**PASO 1:** Habilita Secret Scanning en GitHub:

1. Ve a **GitHub.com → Tu Repo → Settings**
2. Click en **"Code security and analysis"**
3. Habilita:
   - ✅ **Secret scanning** → Click "Enable"
   - ✅ **Push protection** → Click "Enable" (previene push de secrets)

**PASO 2:** GitHub escaneará automáticamente tu repositorio. Si hay secrets, verás alertas en:
   - **Security → Secret scanning alerts**

**PASO 3:** En Copilot Chat, genera script para limpiar notebooks (prevención local):

```
PROPÓSITO: Detectar y remover secrets de notebooks antes de commit
AUDIENCIA: Data Scientist evitando exponer credenciales
CONTEXTO: Notebooks con API keys, passwords, tokens hardcoded
EJEMPLOS: AWS_SECRET_KEY = "abc123" → AWS_SECRET_KEY = os.getenv("AWS_SECRET_KEY")
SCOPE: Pre-commit hook que escanea notebooks

---

Crea scripts/clean-notebook-secrets.py:

SECRETOS A DETECTAR:
1. API Keys (regex patterns)
   - AWS: AKIA[0-9A-Z]{16}
   - OpenAI: sk-[a-zA-Z0-9]{48}
   - Stripe: sk_live_[a-zA-Z0-9]{24}

2. Passwords/Tokens
   - password = "..."
   - token = "..."
   - api_key = "..."

3. Connection strings
   - Database URLs con credenciales
   - S3 URLs con access keys

4. PII
   - Emails
   - Phone numbers
   - Account numbers

ACCIONES:
- Escanear todas las celdas del notebook
- Detectar patrones sospechosos
- Reemplazar con referencias a env vars
- Generar .env.example con placeholders
- Actualizar .gitignore para excluir .env

REQUISITOS:
- Compatible con pre-commit hooks
- Exit code 1 si encuentra secrets
- Sugerir correcciones
- Log findings para auditoría

ENTREGA: Script + pre-commit config
```

**PASO 4:** Configura pre-commit hook (prevención local):

```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: clean-notebook-secrets
        name: Clean Secrets from Notebooks
        entry: python scripts/clean-notebook-secrets.py
        language: system
        files: '\.ipynb$'
        pass_filenames: true
```

```powershell
# Instalar pre-commit
pip install pre-commit
pre-commit install

# Test
pre-commit run --all-files
```

**PASO 5:** Migra secrets existentes a variables de entorno:

```python
# ❌ Antes (vulnerable)
API_KEY = "sk-abc123xyz789"
db_conn = "postgresql://user:pass@host/db"

# ✅ Después (seguro)
import os
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("OPENAI_API_KEY")
db_conn = os.getenv("DATABASE_URL")

# Validar que existen
if not API_KEY:
    raise ValueError("OPENAI_API_KEY not set in environment")
```

**PASO 6:** Crea `.env.example`:

```bash
# .env.example
OPENAI_API_KEY=your_openai_key_here
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
DATABASE_URL=postgresql://user:password@localhost:5432/dbname
S3_BUCKET_NAME=my-data-bucket
```

**VALIDACIÓN:**
- [ ] Secret scanning activo **en GitHub Settings**
- [ ] Push protection habilitado (previene commits con secrets)
- [ ] Alertas visibles en **GitHub Security → Secret scanning**
- [ ] Pre-commit hook funcional (prevención local)
- [ ] Secrets migrados a env vars
- [ ] .env.example creado
- [ ] .env en .gitignore

**TIEMPO:** 15 minutos

---

### MÓDULO 6: Automatización DS Security (15 minutos)

#### Actividad 6A: Pipeline de Seguridad para ML (15 min)

**PASO 1:** Crea workflow completo de seguridad DS:

```
PROPÓSITO: Pipeline CI/CD con validaciones de seguridad para ML
AUDIENCIA: Data Scientist integrando security en MLOps
CONTEXTO: Proyecto ML que necesita gates de seguridad antes de deploy
EJEMPLOS: Commit → Tests → Security checks → Model validation → Deploy
SCOPE: Workflow YAML completo con 6 stages

---

Crea .github/workflows/ml-security-pipeline.yml:

STAGES:
1️⃣ Code Quality & Security
   - CodeQL analysis
   - Linting (flake8, black)
   - Type checking (mypy)
   - Security scan (bandit)

2️⃣ Dependency Security
   - Dependabot alerts check
   - License compliance
   - Known vulnerabilities (safety)

3️⃣ Secrets Detection
   - Secret scanning
   - Notebook cleaning
   - Environment validation

4️⃣ Model Validation
   - Reproducibility check
   - Fairness metrics (bias detection)
   - Performance benchmarks
   - Explainability tests

5️⃣ Data Security
   - PII detection en datasets
   - Data encryption verification
   - Access control validation

6️⃣ Compliance Gates
   - SBS compliance checks
   - GDPR compliance (right to explanation)
   - Model documentation completeness
   - Approval workflow

REQUISITOS:
- Parallel execution donde posible
- Fail fast en CRITICAL issues
- Detailed reports como artifacts
- Slack notification en failures
- Auto-comment en PR con summary

ENTREGA: Workflow YAML funcional
```

**PASO 2:** Crea dashboard de métricas de seguridad:

```
PROPÓSITO: Dashboard de métricas de seguridad ML
AUDIENCIA: DS Lead, Security Officer
CONTEXTO: Necesito visibilidad de postura de seguridad de modelos
EJEMPLOS: Gráfico de vulnerabilidades over time, fairness scores
SCOPE: Script que genera HTML dashboard

---

Crea scripts/generate-security-dashboard.py:

MÉTRICAS:
1. Code Security
   - CodeQL alerts trend
   - Dependency vulnerabilities
   - Secrets exposed (histórico)

2. Model Security
   - Fairness scores por modelo
   - Explicabilidad coverage
   - Model versioning compliance

3. Data Security
   - PII exposure incidents
   - Encryption coverage
   - Access violations

4. Compliance
   - % modelos con docs completa
   - % modelos auditados
   - Time to remediation

VISUALIZACIONES:
- Line charts (trends)
- Bar charts (comparison)
- Heat maps (risk matrix)
- Tables (detailed breakdown)

FORMATO: HTML interactivo con Plotly/Chart.js
```

**PASO 3:** Integra todo en un PR template con checklist:

```markdown
# Pull Request - ML Model Update

## Descripción
<!-- Descripción del cambio -->

## Checklist de Seguridad
### Code Security
- [ ] CodeQL analysis passed (0 CRITICAL)
- [ ] No secrets en código/notebooks
- [ ] Dependencies sin vulnerabilidades CRITICAL/HIGH

### Model Security  
- [ ] Fairness metrics calculadas (disparate impact > 0.8)
- [ ] Model explicabilidad implementada
- [ ] Reproducibilidad validada (diff < 0.001)

### Data Security
- [ ] PII protegido/anonimizado
- [ ] Datos encriptados en reposo
- [ ] Access controls verificados

### Governance
- [ ] Model metadata completo
- [ ] Documentación actualizada
- [ ] Reviewer aprobó cambios
- [ ] Tests de seguridad pasados

### Compliance
- [ ] Cumple SBS requirements
- [ ] GDPR right-to-explanation OK
- [ ] Audit trail registrado

## Métricas del Modelo
| Métrica | Valor | Threshold | Status |
|---------|-------|-----------|--------|
| Accuracy | X.XX | >0.85 | ✅/❌ |
| Precision | X.XX | >0.80 | ✅/❌ |
| Recall | X.XX | >0.75 | ✅/❌ |
| Fairness (DI) | X.XX | 0.8-1.25 | ✅/❌ |

## Security Scan Results
<!-- Auto-generado por workflow -->
```

**VALIDACIÓN:**
- [ ] Pipeline completo funcional
- [ ] Dashboard generado
- [ ] PR template con checklist

**TIEMPO:** 15 minutos

---

## 🎯 ENTREGABLES FINALES

Al finalizar el taller, deberías tener:

### Workflows ✅
- [ ] `.github/workflows/codeql-ds-analysis.yml` - CodeQL para DS
- [ ] `.github/workflows/ml-security-pipeline.yml` - Pipeline completo
- [ ] `.github/workflows/dependabot-auto-merge.yml` - Auto-merge security

### Scripts 🐍
- [ ] `scripts/detect-model-bias.py` - Detección de bias
- [ ] `scripts/explain-model.py` - Explicabilidad SHAP
- [ ] `scripts/validate-ml-dependencies.py` - Validador de deps
- [ ] `scripts/clean-notebook-secrets.py` - Limpieza de secrets
- [ ] `scripts/generate-security-dashboard.py` - Dashboard

### Configuración ⚙️
- [ ] `.github/dependabot.yml` - Dependabot para ML libs
- [ ] `.pre-commit-config.yaml` - Pre-commit hooks
- [ ] `.env.example` - Template de variables

### Documentación 📄
- [ ] `docs/ml-security-risks.md` - Riesgos de ML
- [ ] `docs/bias-mitigation-guide.md` - Guía de fairness
- [ ] `reports/security-dashboard.html` - Dashboard interactivo

### Model Governance 🏛️
- [ ] Model registry con metadata completo
- [ ] Lineage tracking implementado
- [ ] Aprobación workflow activo

---

## 📊 CHECKLIST DE CALIDAD

### Seguridad de Código
- [ ] CodeQL analiza notebooks y scripts
- [ ] No hay secrets hardcoded
- [ ] Dependencies sin vulnerabilidades críticas
- [ ] Pre-commit hooks activos

### Seguridad de Modelos
- [ ] Fairness metrics calculadas
- [ ] Bias dentro de thresholds aceptables
- [ ] Explicabilidad implementada
- [ ] Reproducibilidad validada

### Seguridad de Datos
- [ ] PII protegido
- [ ] Datos encriptados
- [ ] Access controls en place
- [ ] Audit logging activo

### Gobernanza
- [ ] Model versioning implementado
- [ ] Metadata completo para cada modelo
- [ ] Lineage tracking funcional
- [ ] Aprobaciones documentadas

---

## 💡 TIPS PARA DATA SCIENTISTS

### Best Practices ML Security

1. **Treat models como código**
   - Version control todo (código + modelos)
   - Code review para notebooks
   - CI/CD con tests

2. **Reproducibilidad es seguridad**
   - Fijar random seeds
   - Versionar datos
   - Documentar environment

3. **Explica tus modelos**
   - SHAP para feature importance
   - Lime para explicaciones locales
   - Documentación en lenguaje natural

4. **Mide fairness constantemente**
   - No solo al inicio
   - Monitor en producción
   - Re-evaluar con nuevos datos

5. **Protege datos sensibles**
   - Anonymization
   - Differential privacy
   - Federated learning si es posible

### Vulnerabilidades Comunes en DS

| Vulnerabilidad | Riesgo | Mitigación |
|----------------|--------|------------|
| Pickle inseguro | Code execution | Validar hash, usar joblib con compresión |
| Data poisoning | Modelo manipulado | Validar datos, detectar outliers |
| Model stealing | IP theft | Rate limiting, API authentication |
| Inference attacks | Privacy breach | Differential privacy, model aggregation |
| Adversarial examples | Predicciones erróneas | Adversarial training, input validation |

---

## 🔗 RECURSOS ADICIONALES

### Papers y Referencias
- [Fairness in ML](https://fairmlbook.org/)
- [Interpretable ML Book](https://christophm.github.io/interpretable-ml-book/)
- [Microsoft Responsible AI](https://www.microsoft.com/en-us/ai/responsible-ai)
- [Google's PAIR](https://pair.withgoogle.com/)

### Herramientas
- [SHAP](https://github.com/slundberg/shap) - Explicabilidad
- [Fairlearn](https://fairlearn.org/) - Fairness metrics
- [MLflow](https://mlflow.org/) - ML lifecycle
- [WhyLogs](https://github.com/whylabs/whylogs) - Data/model monitoring

### Datasets para Práctica
- [UCI Adult Dataset](https://archive.ics.uci.edu/ml/datasets/adult) - Fairness
- [COMPAS](https://github.com/propublica/compas-analysis) - Bias en justicia
- [Adversarial examples](https://github.com/tensorflow/cleverhans)

---

## ❓ PREGUNTAS FRECUENTES

**P: ¿Debo sacrificar accuracy por fairness?**  
R: No siempre. Muchas veces hay técnicas que mejoran ambas. Si hay trade-off, es una decisión de negocio con stakeholders.

**P: ¿Cómo explico SHAP a un cliente?**  
R: "Esta decisión se basó principalmente en: tu historial de pagos (40%), ingresos (30%), y antigüedad laboral (20%)."

**P: ¿Qué tan seguido debo re-evaluar fairness?**  
R: En producción, continuamente. Como mínimo mensual, o cuando cambies el modelo.

**P: ¿Pickle es inseguro siempre?**  
R: No, pero requiere validación del origen. Joblib con compresión es más seguro.

**P: ¿Cómo reporto un modelo con bias?**  
R: Documenta métricas, impacto, y propone mitigación. Escala a DS Lead y Legal si es alto impacto.

---

## 🎓 PRÓXIMOS PASOS

Después del taller:

1. **Implementa en tu proyecto**
   - Aplica CodeQL a tus notebooks
   - Mide fairness en tus modelos
   - Implementa explicabilidad

2. **Profundiza conocimiento**
   - Curso de Fairness in ML
   - Certificación en Responsible AI
   - Papers recientes de ML Security

3. **Evangeliza en el equipo**
   - Presenta best practices
   - Crea guidelines internas
   - Mentoreo a juniors

4. **Contribuye a la comunidad**
   - Escribe sobre learnings
   - Comparte código en GitHub
   - Presenta en meetups

---

**¡Felicidades! Has completado el Taller 7: GitHub Advanced Security para Data Science** 🎉

**Mi Banco DS Team | Taller 7 - GHAS**
