# Tools Directory

Esta carpeta contiene herramientas de línea de comandos para el proyecto.

## 🛠️ Herramientas Disponibles

### CodeQL CLI

**Estado:** ⚠️ **NO NECESARIO** - Se puede eliminar esta carpeta

**Razón:** CodeQL CLI está integrado directamente en GitHub Actions y no necesita instalación local para el taller.

**Instalación Global (si se necesita localmente):**

```bash
# Windows (Chocolatey)
choco install codeql

# macOS (Homebrew)
brew install codeql

# Linux (manual)
wget https://github.com/github/codeql-action/releases/latest/download/codeql-bundle-linux64.tar.gz
tar -xvzf codeql-bundle-linux64.tar.gz
export PATH="$PATH:/path/to/codeql"
```

**Uso en GitHub Actions:**

```yaml
- name: Initialize CodeQL
  uses: github/codeql-action/init@v2
  with:
    languages: python, javascript
```

### GitHub CLI (gh)

**Estado:** ⚠️ **NO NECESARIO** - Se puede eliminar esta carpeta

**Razón:** GitHub CLI se instala globalmente, no en el proyecto.

**Instalación Global:**

```bash
# Windows (WinGet)
winget install --id GitHub.cli

# Windows (Chocolatey)
choco install gh

# macOS (Homebrew)
brew install gh

# Linux (apt)
sudo apt install gh
```

**Autenticación:**

```bash
gh auth login
```

**Comandos útiles para el taller:**

```bash
# Ver CodeQL alerts
gh api /repos/OWNER/REPO/code-scanning/alerts

# Ver Dependabot alerts
gh api /repos/OWNER/REPO/dependabot/alerts

# Crear PR
gh pr create --title "Fix: SQL injection" --body "Remediación de vulnerabilidad"

# Ver estado de Actions
gh run list
gh run view <run-id>
```

## 🗂️ Estructura Actual

```
tools/
├── codeql-cli/        # ❌ ELIMINAR - No necesario
├── github-cli/        # ❌ ELIMINAR - No necesario
└── README.md          # Este archivo
```

## ✅ Recomendación

**Eliminar carpetas vacías:**

```bash
# PowerShell
Remove-Item -Recurse tools/codeql-cli
Remove-Item -Recurse tools/github-cli
```

**O mantener solo README:**

```
tools/
└── README.md          # Documentación de herramientas externas
```

## 📚 Herramientas del Taller (ya instaladas)

### Python Tools (requirements.txt)

```bash
pip install -r requirements.txt
```

Incluye:
- `pytest` - Testing
- `bandit` - Security linter
- `safety` - Dependency vulnerability scanner
- `pylint` - Code quality

### GitHub Advanced Security (GHAS)

**Incluido en GitHub:**
- CodeQL Analysis
- Secret Scanning
- Dependabot
- Security Advisories
- Copilot Autofix

**Acceso:** https://github.com/OWNER/REPO/security

### VS Code Extensions (recomendadas)

```json
{
  "recommendations": [
    "GitHub.vscode-github-actions",
    "GitHub.copilot",
    "GitHub.copilot-chat",
    "ms-python.python",
    "ms-python.vscode-pylance",
    "ms-azuretools.vscode-docker"
  ]
}
```

## 🔧 Setup del Entorno (sin esta carpeta)

### 1. Instalar Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configurar GitHub CLI (global)

```bash
winget install --id GitHub.cli
gh auth login
```

### 3. Habilitar GHAS en el Repositorio

```bash
# Requiere permisos de admin
gh api -X PATCH /repos/OWNER/REPO -f security_and_analysis.advanced_security.status=enabled
gh api -X PATCH /repos/OWNER/REPO -f security_and_analysis.secret_scanning.status=enabled
```

### 4. Ejecutar CodeQL Localmente (opcional)

```bash
# Instalar CodeQL CLI globalmente
choco install codeql

# Crear database
codeql database create mydb --language=python

# Ejecutar queries
codeql database analyze mydb --format=sarif-latest --output=results.sarif
```

## 📖 Documentación Oficial

- **CodeQL:** https://codeql.github.com/docs/
- **GitHub CLI:** https://cli.github.com/manual/
- **GHAS:** https://docs.github.com/en/code-security
- **Dependabot:** https://docs.github.com/en/code-security/dependabot

---

**Conclusión:** Las carpetas `codeql-cli/` y `github-cli/` pueden eliminarse ya que estas herramientas se instalan globalmente, no a nivel de proyecto. El taller usa principalmente GHAS integrado en GitHub Actions.
