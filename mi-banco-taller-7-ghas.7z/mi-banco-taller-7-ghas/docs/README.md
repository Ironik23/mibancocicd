# Documentation

Esta carpeta contiene documentación adicional del proyecto.

## 📚 Documentos Disponibles

La documentación principal del taller está en la raíz del proyecto:

- `README.md` - Introducción y guía rápida
- `GETTING_STARTED.md` - Guía de inicio
- `GUIA_EJECUCION_GHAS_DS.md` - Taller completo para Data Science
- `GUIA_EJECUCION_GHAS_QE.md` - Taller completo para QE
- `LIBRERIA_PROMPTS_GHAS.md` - Biblioteca de prompts
- `EJEMPLOS_GHAS_CODIGO.md` - Ejemplos de código
- `Seguridad_Avanzada_GHAS.md` - Presentación de GHAS

## 📝 Documentos Adicionales

Puedes agregar aquí durante el taller:

### Arquitectura
- `architecture.md` - Diagrama y descripción de arquitectura
- `data-flow.md` - Flujo de datos en el sistema
- `security-design.md` - Diseño de seguridad

### Procedimientos
- `deployment.md` - Guía de deployment
- `incident-response.md` - Plan de respuesta a incidentes
- `runbook.md` - Procedimientos operacionales

### Reportes
- `security-audit-YYYY-MM.md` - Auditorías de seguridad
- `vulnerability-assessment.md` - Evaluación de vulnerabilidades
- `compliance-checklist.md` - Checklist de compliance (SBS, GDPR)

## 🔗 Referencias Externas

- [GitHub Advanced Security Docs](https://docs.github.com/en/code-security)
- [OWASP Top 10](https://owasp.org/Top10/)
- [CWE Database](https://cwe.mitre.org/)
- [Python Security Best Practices](https://python.readthedocs.io/en/latest/library/security_warnings.html)

---

**Nota:** Esta carpeta está preparada para documentación adicional que se genere durante el desarrollo del proyecto.
