# Seguridad Avanzada con GitHub Advanced Security

## Taller Seguridad del Código con GitHub

### Presentador

**Alejandro Robles**\
Consultor GitHub

------------------------------------------------------------------------

# Normas del Taller

Pautas esenciales para un aprendizaje efectivo y colaborativo

### Puntualidad

El taller dará inicio a la hora programada. Asegúrate de estar listo.

### Micrófono silenciado

Mantén tu micrófono en silencio durante la sesión para evitar
interrupciones.

### Atención activa

Dedica tu concentración plena al contenido y evita distracciones
externas.

### Participación activa

Tus preguntas son bienvenidas. Usa la función *"levantar mano"* para
intervenir.

### Evaluación

Completa la encuesta al finalizar el taller.

### Respeto mutuo

Todas las opiniones y niveles de conocimiento son válidos y merecen
respeto.

------------------------------------------------------------------------

# Agenda

Estructura del curso

-   Objetivo\
-   Introducción a GHAS\
-   Code Scanning y CodeQL\
-   Dependency Review y Dependabot\
-   Configuración de Políticas y Cumplimiento\
-   Security Overview y Campaigns\
-   Gobernanza y IA Responsable\
-   Labs Prácticos

------------------------------------------------------------------------

# Objetivo

-   Entender los componentes de GitHub Advanced Security\
-   Implementar escaneo de código con CodeQL\
-   Gestionar vulnerabilidades en dependencias\
-   Aplicar políticas de seguridad y cumplimiento\
-   Integrar IA responsable en procesos de calidad\
-   Configurar automatización de remediación

------------------------------------------------------------------------

# ¿Qué es GitHub Advanced Security?

> "GitHub Advanced Security (GHAS) es una suite integral de herramientas
> que permite a los equipos de desarrollo detectar y remediar
> vulnerabilidades en tiempo real."

### Componentes clave

-   **Code scanning:** análisis semántico con CodeQL\
-   **Copilot Autofix:** correcciones generadas por IA directamente en
    el flujo del desarrollador\
-   **Security Campaigns:** remediación a escala\
-   **Detección avanzada de dependencias**\
-   **Security Overview:** visibilidad empresarial de seguridad

------------------------------------------------------------------------

# Principio: "Found Means Fixed"

-   **Detección temprana → Menores costos de remediación**\
-   **Menos vulnerabilidades en producción → Menor riesgo**\
-   **Mejora de experiencia para desarrolladores → Mayor adopción**

> Todo lo que se detecta debe corregirse inmediatamente.

------------------------------------------------------------------------

# Code Scanning

## Detecte vulnerabilidades con precisión

-   Análisis semántico (CodeQL) trata el código como datos.\
-   Cientos de reglas nativas creadas por GitHub.\
-   Reducción significativa de falsos positivos.\
-   Detecta vulnerabilidades que otras herramientas omiten.\
-   Posibilidad de crear consultas personalizadas.

### Cómo funciona

1.  El desarrollador hace *push*\
2.  GitHub Actions ejecuta CodeQL\
3.  Análisis semántico\
4.  Generación de alertas\
5.  Notificación en Pull Request\
6.  Copilot Autofix sugiere correcciones

------------------------------------------------------------------------

# Tipos de vulnerabilidades comunes (2024)

-   Inyecciones\
-   Control de acceso roto\
-   Diseño inseguro\
-   Errores criptográficos\
-   Fallas de autenticación\
-   Configuraciones incorrectas\
-   Fallas de integridad\
-   Falta de registro/monitoreo\
-   SSRF\
-   Componentes vulnerables

------------------------------------------------------------------------

# Copilot Autofix

Correcciones generadas por IA directamente en el PR

**45%** de sugerencias aceptadas\
**60%** reducción del MTTR

### Ejemplo

``` python
# SQL Injection encontrado en PR
query = f"SELECT * FROM users WHERE email = '{email}'"

# Copilot Autofix sugiere:
query = "SELECT * FROM users WHERE email = %s"
cursor.execute(query, (email,))
```

------------------------------------------------------------------------

# Efectividad de Autofix

-   Hasta **60%** reducción en PR\
-   Hasta **80%** en XSS\
-   Hasta **90%** en SQL Injection

------------------------------------------------------------------------

# Gobernanza y IA Responsable

## Transparencia

-   Explicación de la vulnerabilidad\
-   Contexto del código\
-   Nivel de confianza\
-   Alternativas

## Trazabilidad

-   Quién aceptó el cambio\
-   Cuándo\
-   En qué PR\
-   Auditorías en GitHub Audit

## Responsabilidad

El desarrollador es dueño del cambio.

## Sesgo y Equidad

-   No asumir roles\
-   Accesibilidad universal\
-   Sugerencias justas

------------------------------------------------------------------------

# Framework de Gobernanza GHAS

### DEFINIR

-   Políticas de seguridad\
-   Estándares de codificación\
-   Cumplimiento\
-   Métricas

### IMPLEMENTAR

-   Code scanning en todos los repos\
-   Dependency Review obligatorio\
-   Ramas protegidas\
-   Automatización CI/CD

### MONITOREAR

-   Security Overview\
-   Alertas en tiempo real\
-   Métricas de remediación

### MEJORAR

-   Auditorías\
-   Training\
-   Ajuste de políticas\
-   Campañas de remediación

------------------------------------------------------------------------

# Security Campaigns

## "Quema la deuda de seguridad"

-   Iniciativas coordinadas para resolver alertas similares\
-   Basadas en tipos específicos de vulnerabilidad\
-   Plazos definidos\
-   Métricas de progreso

**55%** de alertas corregidas en campaña vs **10%** independientemente\
**2x** más participación de desarrolladores

### Ejemplo: Campaña SQL Injection

-   Período: 2 semanas\
-   Repos: 8\
-   Alertas: 42\
-   67% resueltas\
-   Equipos: Backend Java, API Python, Scripts

------------------------------------------------------------------------

# Dependencias

## Dependency Review & Dependabot

-   Evitar dependencias vulnerables antes del merge\
-   Reglas automáticas de clasificación\
-   Puntuación EPSS\
-   Correcciones automatizadas con Dependabot

------------------------------------------------------------------------

# Security Overview

Centro de comando para Code Security

-   Vista unificada de repositorios, alertas y riesgos\
-   Filtros por tipo, gravedad, lenguaje\
-   Seguimiento del progreso y adopción

------------------------------------------------------------------------

# Promesa de Code Security

Seguridad y calidad por defecto

-   Reducción de falsos positivos\
-   Gestión integral de riesgos de cadena de suministro\
-   Seguridad integrada al flujo de trabajo\
-   Remediación en minutos

------------------------------------------------------------------------

# Labs Prácticos (Hands-On)

### Lab 1: Configurar Code Scanning

-   Habilitar CodeQL\
-   Detectar vulnerabilidades

### Lab 2: Gestionar alertas de dependencias

-   Configurar Dependabot\
-   Resolver vulnerabilidades

### Lab 3: Crear Security Campaign

------------------------------------------------------------------------

# Recursos Útiles

-   GitHub Copilot\
-   GitHub Advanced Security Docs\
-   CodeQL Documentation\
-   OWASP Top 10 2024\
-   PCI DSS Guide\
-   https://silver-lamp-e2j3v5z.pages.github.io/docs/tutorial-extras/Inicio

------------------------------------------------------------------------

# Gracias
