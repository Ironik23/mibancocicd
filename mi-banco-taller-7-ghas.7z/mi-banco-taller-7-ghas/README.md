# 🔐 TALLER 7: GitHub Advanced Security (GHAS)

**Duración:** 2 horas | **Nivel:** Intermedio-Avanzado | **Público:** QE (Quality Engineering) y DS (Data Science)

---

## 📌 Descripción

Taller práctico sobre **GitHub Advanced Security (GHAS)** diseñado específicamente para equipos de **Quality Engineering** y **Data Science** en el sector bancario. Aprende a implementar seguridad en aplicaciones y modelos ML usando CodeQL, Dependabot, y herramientas de gobernanza de IA.

### 🎯 Objetivos

#### Para QE (Quality Engineering):
- ✅ Implementar CodeQL para detectar vulnerabilidades en APIs
- ✅ Crear security tests automatizados (OWASP Top 10)
- ✅ Configurar quality gates de seguridad en CI/CD
- ✅ Validar dependencias y gestionar vulnerabilidades
- ✅ Generar reportes de seguridad ejecutivos

#### Para DS (Data Science):
- ✅ Detectar vulnerabilidades en código Python/ML
- ✅ Medir y mitigar bias en modelos predictivos
- ✅ Implementar explicabilidad (SHAP) para compliance
- ✅ Proteger secrets en notebooks Jupyter
- ✅ Crear pipelines ML seguros con MLSecOps

---

## 🚀 Quick Start (5 minutos)

### Para Quality Engineers (QE)

```powershell
# 1. Clonar repositorio
git clone https://github.com/mi-banco/mi-banco-taller-7-ghas.git
cd mi-banco-taller-7-ghas

# 2. Leer guía específica QE
code GUIA_EJECUCION_GHAS_QE.md

# 3. Setup inicial
New-Item -ItemType Directory -Force -Path ".github/workflows", "scripts", "collections", "reports"

# 4. Primer lab - CodeQL
cd labs/lab-1-codeql
code README.md
```

### Para Data Scientists (DS)

```powershell
# 1. Clonar repositorio
git clone https://github.com/mi-banco/mi-banco-taller-7-ghas.git
cd mi-banco-taller-7-ghas

# 2. Leer guía específica DS
code GUIA_EJECUCION_GHAS_DS.md

# 3. Setup entorno Python
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt

# 4. Primer lab - ML Security
jupyter notebook examples/python/vulnerable_ml_notebook.ipynb
```

---

## 📚 Guías de Ejecución

### 🔹 GUIA_EJECUCION_GHAS_QE.md (Para Quality Engineers)

**Contenido:**
- **Módulo 1:** Fundamentos GHAS para QE (15 min)
  - Entender GHAS desde perspectiva de testing
  - Explorar código vulnerable
- **Módulo 2:** Code Scanning con CodeQL (25 min)
  - Configurar CodeQL para Python/JavaScript
  - Analizar y documentar alertas
  - Crear test cases de validación
- **Módulo 3:** Dependency Review (20 min)
  - Configurar Dependabot
  - Crear quality gates de dependencias
- **Módulo 4:** Security Quality Gates (25 min)
  - Definir gates de seguridad bancaria
  - Implementar evaluador automático
- **Módulo 5:** Security Testing Automation (25 min)
  - Tests de seguridad con Postman
  - Automatizar en CI/CD
- **Módulo 6:** Reportes de Seguridad (10 min)
  - Generar reportes ejecutivos

**Entregables:**
- Workflows: `codeql-analysis.yml`, `security-tests.yml`
- Scripts: `validate-dependencies.py`, `evaluate-security-gates.py`
- Tests: `security-tests.postman.json`
- Documentación: Análisis de alertas, reportes ejecutivos

---

### 🔹 GUIA_EJECUCION_GHAS_DS.md (Para Data Scientists)

**Contenido:**
- **Módulo 1:** Seguridad en ML/AI (15 min)
  - Riesgos específicos de ML (model poisoning, adversarial attacks)
  - Auditar notebooks vulnerables
- **Módulo 2:** CodeQL para Data Science (25 min)
  - Configurar CodeQL con queries ML
  - Detectar pickle inseguro, eval(), SQL injection
- **Módulo 3:** Dependency Security para DS (20 min)
  - Dependabot para librerías ML (numpy, pandas, sklearn)
  - Validar compatibilidad post-update
- **Módulo 4:** IA Responsable y Gobernanza (30 min)
  - Detectar y medir bias (disparate impact, equal opportunity)
  - Implementar explicabilidad con SHAP
  - Model lineage y trazabilidad
- **Módulo 5:** Secrets en Notebooks (15 min)
  - Detectar API keys, passwords hardcoded
  - Pre-commit hooks para limpieza automática
- **Módulo 6:** Automatización DS Security (15 min)
  - Pipeline ML con security gates
  - Dashboard de métricas de seguridad

**Entregables:**
- Workflows: `codeql-ds-analysis.yml`, `ml-security-pipeline.yml`
- Scripts: `detect-model-bias.py`, `explain-model.py`, `clean-notebook-secrets.py`
- Configuración: `.pre-commit-config.yaml`, model registry
- Reportes: Fairness analysis, security dashboard

---

## 📖 Recursos de Aprendizaje

### 🔹 LIBRERIA_PROMPTS_GHAS.md

**Descripción:** Colección de 30+ prompts PACES listos para usar con GitHub Copilot

**Categorías:**
- **Para QE:** CodeQL setup, análisis de alertas, dependency gates, security testing, reportes
- **Para DS:** CodeQL ML, detección de bias, explicabilidad, limpieza de secrets, ML pipelines
- **Compartidos:** Secret scanning, compliance checker

**Uso:**
1. Abre el archivo y busca el prompt relevante
2. Copia el prompt completo (incluye estructura PACES)
3. Pega en Copilot Chat (`Ctrl + Shift + I`)
4. Personaliza placeholders con tu contexto
5. Obtén código ejecutable

**Ejemplo de Prompt:**
```markdown
PROPÓSITO: Configurar CodeQL para detectar vulnerabilidades en APIs bancarias
AUDIENCIA: QE que configura seguridad en CI/CD por primera vez
CONTEXTO: Proyecto Python, APIs REST, necesito detectar SQL injection, XSS
EJEMPLOS: Push código → CodeQL analiza → Alertas en PR → Bloquea merge
SCOPE: Workflow YAML completo con security-extended queries
```

---

### 🔹 EJEMPLOS_GHAS_CODIGO.md

**Descripción:** Código ejecutable listo para copiar/pegar

**Contenido:**
1. **Workflows GitHub Actions:**
   - `codeql-analysis.yml` (QE)
   - `codeql-ds-analysis.yml` (DS)
   - `ml-security-pipeline.yml` (DS)

2. **Scripts Python:**
   - `validate-dependencies.py` - Quality gate de dependencias (QE)
   - `detect-model-bias.py` - Análisis de fairness (DS)
   - `evaluate-security-gates.py` - Evaluador de gates (QE)
   - `clean-notebook-secrets.py` - Limpieza de secrets (DS)
   - `check-compliance.py` - Validador de compliance (Ambos)

3. **Configuraciones:**
   - `dependabot.yml` - Monitoreo de dependencias
   - `codeql-config.yml` - Configuración CodeQL
   - `.pre-commit-config.yaml` - Hooks de pre-commit

4. **Colecciones de Tests:**
   - `security-tests.postman.json` - Tests OWASP Top 10 (QE)

**Uso:**
- Copia el código directamente
- Personaliza variables y paths
- Ejecuta localmente o en CI/CD

---

## 📚 Contenido Adicional

---

## 📁 Estructura del Repositorio

```
mi-banco-taller-7-ghas/
├── GUIA_EJECUCION_GHAS_QE.md         ← Guía completa para QE (2h)
├── GUIA_EJECUCION_GHAS_DS.md         ← Guía completa para DS (2h)
├── LIBRERIA_PROMPTS_GHAS.md          ← 30+ prompts PACES
├── EJEMPLOS_GHAS_CODIGO.md           ← Código ejecutable
├── Seguridad_Avanzada_GHAS.md        ← Presentación del taller
├── .github/
│   ├── workflows/                    ← GitHub Actions workflows
│   └── dependabot.yml                ← Configuración Dependabot
├── labs/                             ← 6 Laboratorios prácticos
│   ├── lab-1-codeql/
│   ├── lab-2-dependabot/
│   ├── lab-3-policies/
│   ├── lab-4-overview/
│   ├── lab-5-remediation/
│   └── lab-6-queries/
├── src/                              ← Código de ejemplo
│   ├── vulnerable/                   ← Apps con vulnerabilidades
│   ├── secure/                       ← Apps corregidas
│   └── models/                       ← Modelos ML
├── scripts/                          ← Scripts de automatización
│   ├── validate-dependencies.py
│   ├── detect-model-bias.py
│   ├── clean-notebook-secrets.py
│   └── check-compliance.py
├── tests/                            ← Tests de seguridad
├── collections/                      ← Postman collections
├── config/                           ← Configuraciones
├── reports/                          ← Reportes generados
└── docs/                             ← Documentación adicional
```

---

## 🎓 Rutas de Aprendizaje

### 🟢 Para Quality Engineers (QE)

**Ruta Completa (2 horas):**
1. **Inicio (10 min):** Leer `GUIA_EJECUCION_GHAS_QE.md` - Módulo 1
2. **CodeQL (25 min):** Configurar y analizar con `LIBRERIA_PROMPTS_GHAS.md` - Prompt 1.0
3. **Dependencies (20 min):** Setup Dependabot - Módulo 3
4. **Gates (25 min):** Implementar security gates - Módulo 4
5. **Testing (25 min):** Security tests automatizados - Módulo 5
6. **Reportes (10 min):** Generar reportes ejecutivos - Módulo 6
7. **Práctica:** Completar `labs/lab-1-codeql` y `labs/lab-5-remediation`

**Recursos:**
- 📘 Guía: `GUIA_EJECUCION_GHAS_QE.md`
- 💬 Prompts: Sección QE en `LIBRERIA_PROMPTS_GHAS.md`
- 💻 Código: Ejemplos 1-4 y 6 en `EJEMPLOS_GHAS_CODIGO.md`

---

### 🔵 Para Data Scientists (DS)

**Ruta Completa (2 horas):**
1. **Inicio (15 min):** Leer `GUIA_EJECUCION_GHAS_DS.md` - Módulo 1
2. **CodeQL ML (25 min):** CodeQL para Python/ML - Módulo 2
3. **Dependencies ML (20 min):** Validar librerías ML - Módulo 3
4. **Fairness (30 min):** Detectar y mitigar bias - Módulo 4
5. **Secrets (15 min):** Limpiar notebooks - Módulo 5
6. **ML Pipeline (15 min):** Pipeline security completo - Módulo 6
7. **Práctica:** Auditar `src/vulnerable/vulnerable_ml_notebook.ipynb`

**Recursos:**
- 📘 Guía: `GUIA_EJECUCION_GHAS_DS.md`
- 💬 Prompts: Sección DS en `LIBRERIA_PROMPTS_GHAS.md`
- 💻 Código: Ejemplos 2, 5, 7, 8 en `EJEMPLOS_GHAS_CODIGO.md`

---

### 🟣 Ruta Rápida (30 minutos)

**Para ambos equipos:**
1. Lee el **Quick Start** de tu guía (QE o DS)
2. Ejecuta el **Lab 1: CodeQL** (`labs/lab-1-codeql/README.md`)
3. Usa un prompt de `LIBRERIA_PROMPTS_GHAS.md` con Copilot
4. Copia código de `EJEMPLOS_GHAS_CODIGO.md` y ejecútalo

---

## 🛠️ Tecnologías Utilizadas

### Para QE
- **GitHub Advanced Security:** CodeQL, Dependabot, Secret Scanning
- **Testing:** Postman/Newman, pytest
- **CI/CD:** GitHub Actions
- **Lenguajes:** Python, JavaScript
- **APIs:** REST, GitHub API

### Para DS
- **GitHub Advanced Security:** CodeQL, Dependabot
- **ML Libraries:** numpy, pandas, scikit-learn, tensorflow
- **Fairness:** fairlearn, aif360
- **Explicabilidad:** SHAP, LIME
- **Notebooks:** Jupyter
- **MLOps:** MLflow, DVC

---

## 📋 Requisitos Previos

### Para ambos equipos
- ✅ Cuenta GitHub con GHAS habilitado
- ✅ VS Code con extensión Copilot Chat
- ✅ Git configurado
- ✅ Python 3.8+ instalado

### Adicionales para QE
- ✅ Node.js y npm (para Newman)
- ✅ Postman instalado
- ✅ Conocimientos de APIs REST

### Adicionales para DS
- ✅ Jupyter Notebook
- ✅ Entorno virtual Python
- ✅ Familiaridad con pandas, sklearn

---

## 🎯 Objetivos de Aprendizaje por Rol

### Quality Engineer (QE)

Al finalizar el taller podrás:
- ✅ Configurar CodeQL para detectar OWASP Top 10
- ✅ Crear 15+ security tests automatizados
- ✅ Implementar quality gates que bloquean PRs inseguros
- ✅ Validar dependencias y manejar vulnerabilidades
- ✅ Generar reportes de seguridad para stakeholders
- ✅ Integrar seguridad en pipelines CI/CD

### Data Scientist (DS)

Al finalizar el taller podrás:
- ✅ Detectar vulnerabilidades específicas de ML (pickle, eval)
- ✅ Medir fairness con 5+ métricas (disparate impact, equal opportunity)
- ✅ Implementar explicabilidad con SHAP
- ✅ Proteger secrets en notebooks con pre-commit hooks
- ✅ Crear pipelines ML con security gates
- ✅ Documentar model lineage para auditoría

---

## 📞 Soporte y Recursos

### Durante el Taller
- 💬 **Copilot Chat:** `Ctrl + Shift + I` para ayuda instantánea
- 📚 **Librería de Prompts:** `LIBRERIA_PROMPTS_GHAS.md`
- 💻 **Código de Referencia:** `EJEMPLOS_GHAS_CODIGO.md`

### Después del Taller
- 🔗 [GitHub Advanced Security Docs](https://docs.github.com/en/code-security)
- 🔗 [CodeQL Documentation](https://codeql.github.com/docs/)
- 🔗 [OWASP Top 10 2024](https://owasp.org/www-project-top-ten/)
- 🔗 [Fairness in ML](https://fairmlbook.org/)

### Comunidad
- 💼 **Equipo QE:** Slack #qa-security
- 🤖 **Equipo DS:** Slack #ds-mlops-security
- 🏦 **Mi Banco:** Portal interno de seguridad

---

## 🎉 Siguiente Pasos

### Para Quality Engineers
1. ✅ Implementa CodeQL en tu proyecto
2. ✅ Crea tu primera colección de security tests
3. ✅ Configura Dependabot en todos tus repos
4. ✅ Comparte findings con el equipo

### Para Data Scientists
1. ✅ Audita tus notebooks con `clean-notebook-secrets.py`
2. ✅ Mide fairness en tu modelo actual
3. ✅ Implementa SHAP en tu API de predicciones
4. ✅ Documenta model lineage para compliance

---

## 📜 Licencia

Este proyecto es material educativo de **Mi Banco** para uso interno.

---

## 👥 Autores

- **Alejandro Robles** - Consultor GitHub - Facilitador
- **Equipo QE Mi Banco** - Contribuidores
- **Equipo DS Mi Banco** - Contribuidores

---

## 🏆 Reconocimientos

Gracias a todos los que hicieron posible este taller:
- Equipo de Seguridad Mi Banco
- GitHub Advanced Security Team
- Comunidad de QE y DS

---

**¿Listo para comenzar?**

👉 **QE:** Abre `GUIA_EJECUCION_GHAS_QE.md`  
👉 **DS:** Abre `GUIA_EJECUCION_GHAS_DS.md`

**¡Vamos a hacer código seguro! 🔐**
2. docs/GHAS_BASICS.md
3. labs/lab-1-codeql/README.md
4. labs/lab-2-dependabot/README.md

### Para Desarrolladores
1. docs/CODEQL_GUIDE.md
2. .github/workflows/ (ver configuración)
3. src/vulnerable/ (analizar código)
4. labs según necesidad

### Para Facilitadores
1. Taller_7_QE_Guia_Presentador.md
2. Taller_7_QE_Presentacion.md
3. labs/*/solution.md (soluciones)
4. scripts/generate_report.py (reportes)

### Para Ejecutivos/Líderes
1. 00_TALLER_7_RESUMEN_EJECUTIVO.md
2. docs/COMPLIANCE.md
3. ROI: 588% en 3 años

---

## 🔧 Configuración Inicial

### Requisitos
- GitHub Enterprise o GitHub.com con GHAS habilitado
- Git instalado
- Python 3.8+
- Permiso de admin en repositorio

### Pasos Setup

```bash
# 1. Configurar Git
git config --global user.name "Tu Nombre"
git config --global user.email "tu.email@mibanco.com"

# 2. Instalar dependencias Python
pip install -r requirements.txt

# 3. Ejecutar setup
python scripts/setup_ghas.sh

# 4. Verificar configuración
python scripts/validate_compliance.py
```

---

## 📊 6 Laboratorios Prácticos

| Lab | Tema | Duración | Dificultad |
|-----|------|----------|-----------|
| 1 | CodeQL: Análisis de código | 20 min | ⭐⭐ |
| 2 | Dependabot: Vulnerabilidades | 20 min | ⭐⭐ |
| 3 | Branch Protection Policies | 15 min | ⭐ |
| 4 | Security Overview Dashboard | 15 min | ⭐ |
| 5 | Remediación de código | 20 min | ⭐⭐⭐ |
| 6 | Custom CodeQL Queries | 30 min | ⭐⭐⭐ |

**Total: 120 minutos (2 horas)**

---

## 💡 Características Clave

✨ **Análisis Semántico**: CodeQL entiende el código, no solo busca patrones
🔄 **Automatización**: Dependabot y GitHub Actions trabajan juntos
🛡️ **Gobernanza**: Políticas de rama, CODEOWNERS, PCI DSS compliance
📊 **Visibilidad**: Security Overview Dashboard en tiempo real
🤖 **IA Responsable**: Autofix con Copilot y validación humana
📋 **Trazabilidad**: Auditoría completa de todos los cambios

---

## 📖 Documentación Completa

- **GETTING_STARTED.md**: Primeros pasos
- **docs/SETUP.md**: Configuración detallada
- **docs/CODEQL_GUIDE.md**: Guía de CodeQL
- **docs/DEPENDABOT_GUIDE.md**: Guía de Dependabot
- **docs/COMPLIANCE.md**: PCI DSS mapping
- **docs/TROUBLESHOOTING.md**: Solución de problemas

---

## 🔄 GitHub Workflows Incluidos

- ✅ **codeql-analysis.yml**: Análisis automático en cada push
- ✅ **dependabot-pr.yml**: PRs automáticas de Dependabot
- ✅ **security-checks.yml**: Validación de políticas

---

## 🛠️ Scripts de Automatización

```python
analyze_security.py         # Analizar seguridad del repo
setup_ghas.sh              # Setup GHAS completo
validate_compliance.py     # Validar cumplimiento PCI DSS
migrate_repos.py           # Migrar a GHAS
generate_report.py         # Generar reportes
```

---

## 🤝 Contribuir

Ver **CONTRIBUTING.md** para directrices de contribución.

---

## 📄 Licencia

MIT License - Ver **LICENSE.md**

---

## 📞 Soporte

- 📧 Email: ghas-team@mibanco.com
- 💬 Slack: #ghas-support
- 📱 Wiki: https://wiki.mibanco.com/ghas

---

## 📊 Métricas de Impacto

| Métrica | Impacto | Timeframe |
|---------|---------|-----------|
| Vulnerabilidades detectadas | -73% | 6 meses |
| Tiempo de remediación | -45% | 3 meses |
| Breaches prevenidos | +5 | 1 año |
| ROI | 588% | 3 años |
| Cost savings | $850K | 3 años |

---

## 🎉 ¡Éxito en el Taller!

**Última actualización:** 31 de octubre de 2025  
**Versión:** 1.0  
**Estado:** ✅ Listo para producción

