# 📖 Ejemplos de Código - CI/CD y Automatización QA

**Descripción:** Código listo para copiar/pegar en el taller  
**Tecnologías:** GitHub Actions, Python, Newman, Postman  
**Repositorio:** Mi Banco QA Automation  
**Duración:** 2 horas

---

## 📑 TABLA DE CONTENIDOS

| # | Tipo | Descripción | Complejidad | Líneas |
|---|------|-------------|-------------|--------|
| 1 | Workflow | api-tests.yml - Pipeline básico Newman | Principiante | 50 |
| 2 | Script | smart-test-selector.py - Selección inteligente | Intermedio | 120 |
| 3 | Script | evaluate-quality-gates.py - Quality gates | Intermedio | 150 |
| 4 | Script | generate-executive-report.py - Reportes | Intermedio | 180 |
| 5 | Workflow | smart-qa-pipeline.yml - Pipeline completo | Avanzado | 130 |
| 6 | Config | Estructura de directorios | Principiante | 15 |
| 7 | Config | Mock test results JSON | Principiante | 25 |

---

## 📦 EJEMPLO 1: ESTRUCTURA DE PROYECTO

**Uso:** Para Actividad 1 - Setup inicial  
**Descripción:** Estructura de carpetas para CI/CD QA  
**Duración práctica:** 5 min

```
mi-banco-qa-repo/
├── .github/
│   └── workflows/
│       ├── api-tests.yml                    # ARCHIVO 1
│       ├── smart-qa-pipeline.yml           # ARCHIVO 2
│       └── complete-pipeline.yml           # ARCHIVO 3
├── scripts/
│   ├── smart-test-selector.py              # SCRIPT 1
│   ├── evaluate-quality-gates.py           # SCRIPT 2
│   └── generate-executive-report.py        # SCRIPT 3
├── collections/
│   └── mi-banco-apis.json                  # Postman collection
├── environments/
│   └── testing.json                        # Postman environment
└── reports/                                # (creado automáticamente)
```

**Comandos para crear estructura:**

```powershell
# PowerShell - Crear directorios
New-Item -ItemType Directory -Force -Path ".github/workflows"
New-Item -ItemType Directory -Force -Path "scripts"
New-Item -ItemType Directory -Force -Path "collections"
New-Item -ItemType Directory -Force -Path "environments"
New-Item -ItemType Directory -Force -Path "reports"

# Verificar
Get-ChildItem -Recurse -Directory
```

```bash
# Bash/Linux - Crear directorios
mkdir -p .github/workflows
mkdir -p scripts
mkdir -p collections
mkdir -p environments
mkdir -p reports

# Verificar
ls -la .github/workflows/
ls -la scripts/
```

---

## 📄 EJEMPLO 2: WORKFLOW BÁSICO - api-tests.yml

**Uso:** Para Actividad 2 - Pipeline básico  
**Ruta:** `.github/workflows/api-tests.yml`  
**Descripción:** Workflow que ejecuta tests Postman con Newman  
**Duración práctica:** 10 min

```yaml
name: Mi Banco API Testing Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]
  schedule:
    - cron: '0 6 * * *'

env:
  POSTMAN_COLLECTION: collections/mi-banco-apis.json
  POSTMAN_ENVIRONMENT: environments/testing.json

jobs:
  api-tests:
    name: Ejecutar Tests API Postman
    runs-on: ubuntu-latest
    
    steps:
      - name: Checkout código
        uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Instalar Newman
        run: npm install -g newman newman-reporter-htmlextra
      
      - name: Ejecutar Tests API
        run: |
          newman run ${{ env.POSTMAN_COLLECTION }} \
            --environment ${{ env.POSTMAN_ENVIRONMENT }} \
            --reporters cli,htmlextra,json \
            --reporter-htmlextra-export reports/api-test-report.html \
            --reporter-json-export reports/api-test-results.json \
            --delay-request 100 \
            --timeout-request 5000
      
      - name: Upload Test Reports
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: api-test-reports-${{ github.run_number }}
          path: reports/
          retention-days: 30
      
      - name: Notificar en Slack (si está configurado)
        if: always()
        run: |
          echo "✅ Tests completados"
```

**Conceptos clave:**
- `on:` → Triggers del workflow (push, PR, schedule)
- `env:` → Variables reutilizables
- `if: always()` → Ejecutar aunque fallen tests anteriores
- `${{ github.run_number }}` → Número único de ejecución

---

## 🐍 EJEMPLO 3: SMART TEST SELECTOR

**Uso:** Para Actividad 3 - Selección inteligente de tests  
**Ruta:** `scripts/smart-test-selector.py`  
**Descripción:** Analiza cambios de código y selecciona tests críticos  
**Duración práctica:** 15 min

```python
#!/usr/bin/env python3
"""
Smart Test Selection - Copilot Assisted
Analiza cambios y selecciona tests críticos a ejecutar
"""

import json
import sys
from typing import List, Dict, Set

class IntelligentTestSelector:
    """Selecciona tests inteligentemente basado en cambios"""
    
    # MAPEO: Carpeta/módulo → Tests críticos a ejecutar
    CRITICAL_TESTS = {
        'src/transfers': {
            'tests': [
                'POST_Transfer_Valid_DailyLimit',
                'POST_Transfer_InvalidCCI_Format',
                'POST_Transfer_AML_LargeAmount',
                'POST_Transfer_ExceedsLimit',
                'GET_TransferStatus_Tracking',
            ],
            'priority': 'CRITICAL'
        },
        'src/login': {
            'tests': [
                'POST_Login_ValidCredentials',
                'POST_Login_InvalidPassword',
                'POST_Login_MultiFactor_OTP',
                'GET_Login_SessionToken',
            ],
            'priority': 'CRITICAL'
        },
        'src/security': {
            'tests': [
                'SecurityHeaders_Validation',
                'SSL_TLS_Validation',
                'CSRF_TokenValidation',
                'XSS_Prevention_Check',
            ],
            'priority': 'CRITICAL'
        },
        'src/payments': {
            'tests': [
                'POST_Payment_ValidAmount',
                'POST_Payment_InvalidCard',
            ],
            'priority': 'HIGH'
        },
        'src/auth': {
            'tests': [
                'Suite_Auth_Complete',
                'Suite_Auth_EdgeCases',
            ],
            'priority': 'MEDIUM'
        }
    }
    
    # Tests que SIEMPRE correr (smoke tests)
    SMOKE_TESTS = [
        'GET_Health_Check',
        'POST_Login_ValidCredentials',
        'GET_Transfer_Status',
    ]
    
    def __init__(self, changed_files: List[str]):
        """
        Inicializa selector con archivos cambiados
        
        Args:
            changed_files: Lista de archivos modificados
        """
        self.changed_files = changed_files
        self.affected_modules: Set[str] = set()
        self.tests_to_run: Set[str] = set()
    
    def analyze_changes(self) -> Dict:
        """
        Analiza cambios y determina tests a ejecutar
        
        Returns:
            Dict con análisis resultados
        """
        print("🔍 Analizando cambios de código...")
        
        # Agregar smoke tests siempre
        self.tests_to_run.update(self.SMOKE_TESTS)
        print("  ✓ Agregados smoke tests (always run)")
        
        # Analizar cada archivo cambiado
        for file in self.changed_files:
            if not file.strip():
                continue
            
            # Buscar qué módulos fueron afectados
            for module, config in self.CRITICAL_TESTS.items():
                if module in file:
                    self.affected_modules.add(module)
                    self.tests_to_run.update(config['tests'])
                    print(f"  ✓ {module} DETECTADO - agregando tests ({config['priority']})")
        
        # Si no hubo cambios detectados, correr todos
        if not self.affected_modules:
            print("  ⚠️  No se detectaron cambios específicos - corriendo suite completa")
            for config in self.CRITICAL_TESTS.values():
                self.tests_to_run.update(config['tests'])
        
        return {
            'affected_modules': sorted(list(self.affected_modules)),
            'tests_to_run': sorted(list(self.tests_to_run)),
            'test_count': len(self.tests_to_run),
            'estimated_duration_minutes': len(self.tests_to_run) * 2,
            'time_saved_estimated': max(0, (100 - len(self.tests_to_run)) * 2)
        }
    
    def generate_grep_pattern(self) -> str:
        """Genera patrón grep para Newman"""
        if not self.tests_to_run:
            return ""
        
        # Newman grep: "test1|test2|test3"
        pattern = "|".join(sorted(self.tests_to_run))
        return pattern
    
    def generate_report(self) -> str:
        """Genera reporte de análisis"""
        result = self.analyze_changes()
        
        report = f"""
📊 SMART TEST SELECTION REPORT
═══════════════════════════════

Módulos detectados: {', '.join(result['affected_modules']) or 'Ninguno específico'}

Tests a ejecutar: {result['test_count']}
Tiempo estimado: {result['estimated_duration_minutes']} minutos
Tiempo ahorrado: ~{result['time_saved_estimated']} minutos

Tests:
"""
        for test in sorted(result['tests_to_run']):
            report += f"  ✓ {test}\n"
        
        return report

def main():
    """Función principal"""
    
    # Obtener archivos cambiados del argumento
    changed_files_str = sys.argv[1] if len(sys.argv) > 1 else ""
    changed_files = [f.strip() for f in changed_files_str.split(',') if f.strip()]
    
    print("=" * 60)
    print("SMART TEST SELECTOR - GitHub Actions Workflow")
    print("=" * 60)
    
    # Analizar
    selector = IntelligentTestSelector(changed_files)
    result = selector.analyze_changes()
    
    # Mostrar reporte
    print(selector.generate_report())
    
    # JSON output para GitHub
    print("\n📋 JSON Output:")
    print(json.dumps(result, indent=2))
    
    # GitHub Actions outputs
    tests_pattern = selector.generate_grep_pattern()
    print(f"\n🔄 GitHub Actions Outputs:")
    print(f"::set-output name=tests-to-run::{tests_pattern}")
    print(f"::set-output name=test-count::{result['test_count']}")
    print(f"::set-output name=affected-modules::{','.join(result['affected_modules'])}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
```

**Cómo usarlo:**

```bash
# Localmente (para testing)
python scripts/smart-test-selector.py "src/transfers/transfer.py,src/security/ssl.py"

# En workflow (automático)
python scripts/smart-test-selector.py "${{ github.event.pull_request.changed_files }}"
```

---

## 🐍 EJEMPLO 4: QUALITY GATES EVALUATOR

**Uso:** Para Actividad 4 - Quality gates  
**Ruta:** `scripts/evaluate-quality-gates.py`  
**Descripción:** Evalúa si los resultados cumplen criterios de calidad  
**Duración práctica:** 15 min

```python
#!/usr/bin/env python3
"""
Quality Gates Evaluator
Valida que cambios cumplan criterios de calidad
"""

import json
import sys
from typing import Dict, List
from pathlib import Path

class QualityGatesEvaluator:
    """Evalúa quality gates para decisión de merge"""
    
    # Definición de gates
    GATES_CONFIG = {
        'test_success_rate': {
            'threshold': 95,
            'unit': '%',
            'critical': True,
            'description': 'Success rate de tests'
        },
        'critical_vulnerabilities': {
            'threshold': 0,
            'unit': 'count',
            'critical': True,
            'description': 'Vulnerabilidades críticas encontradas'
        },
        'code_coverage': {
            'threshold': 80,
            'unit': '%',
            'critical': False,
            'description': 'Cobertura de código'
        },
        'compliance_sbs': {
            'threshold': 100,
            'unit': '%',
            'critical': True,
            'description': 'Cumplimiento normativo SBS'
        }
    }
    
    def __init__(self, test_results_file: str):
        """Inicializa evaluador con resultados de tests"""
        try:
            with open(test_results_file, 'r') as f:
                self.results = json.load(f)
        except FileNotFoundError:
            print(f"❌ Error: No se encontró {test_results_file}")
            sys.exit(1)
        except json.JSONDecodeError:
            print(f"❌ Error: {test_results_file} no es JSON válido")
            sys.exit(1)
    
    def evaluate_all(self) -> Dict:
        """Evalúa todos los gates"""
        
        print("\n🔐 EVALUANDO QUALITY GATES")
        print("=" * 60)
        
        gates_results = {}
        all_critical_passed = True
        
        # Evaluar cada gate
        gates_results['success_rate'] = self._evaluate_success_rate()
        gates_results['security'] = self._evaluate_security()
        gates_results['coverage'] = self._evaluate_coverage()
        gates_results['compliance'] = self._evaluate_compliance()
        
        # Determinar si puede mergear
        for gate_result in gates_results.values():
            if gate_result.get('critical', False) and not gate_result.get('passed', False):
                all_critical_passed = False
                print(f"  ❌ {gate_result['name']}: FAIL (crítico)")
            elif gate_result.get('passed', False):
                print(f"  ✅ {gate_result['name']}: PASS")
            else:
                print(f"  ⚠️  {gate_result['name']}: WARNING")
        
        # Resultado final
        final_result = {
            'can_merge': all_critical_passed,
            'gates': gates_results,
            'recommendation': '✅ SEGURO PARA MERGE' if all_critical_passed else '❌ BLOQUEAR MERGE',
            'timestamp': self.results.get('timestamp', 'N/A')
        }
        
        print("\n" + "=" * 60)
        print(final_result['recommendation'])
        
        return final_result
    
    def _evaluate_success_rate(self) -> Dict:
        """Gate: Success rate > 95%"""
        
        stats = self.results.get('stats', {}).get('tests', {})
        passed = stats.get('passed', 0)
        total = stats.get('total', 1)
        
        rate = (passed / total * 100) if total > 0 else 0
        threshold = self.GATES_CONFIG['test_success_rate']['threshold']
        passed_gate = rate >= threshold
        
        return {
            'name': 'Test Success Rate',
            'passed': passed_gate,
            'value': f"{rate:.1f}%",
            'threshold': f"{threshold}%",
            'details': f"{passed}/{total} tests pasados",
            'critical': True
        }
    
    def _evaluate_security(self) -> Dict:
        """Gate: Zero critical vulnerabilities"""
        
        vulnerabilities = self.results.get('security_scan', {}).get('vulnerabilities', [])
        critical = [v for v in vulnerabilities if v.get('severity') == 'CRITICAL']
        
        passed_gate = len(critical) == 0
        
        return {
            'name': 'Security Vulnerabilities',
            'passed': passed_gate,
            'value': f"{len(critical)} críticos",
            'threshold': '0',
            'details': f"{len(vulnerabilities)} total vulnerabilidades",
            'critical': True
        }
    
    def _evaluate_coverage(self) -> Dict:
        """Gate: Code coverage > 80%"""
        
        coverage = self.results.get('coverage', {}).get('percentage', 0)
        threshold = self.GATES_CONFIG['code_coverage']['threshold']
        passed_gate = coverage >= threshold
        
        return {
            'name': 'Code Coverage',
            'passed': passed_gate,
            'value': f"{coverage}%",
            'threshold': f"{threshold}%",
            'details': f"Cobertura actual: {coverage}%",
            'critical': False
        }
    
    def _evaluate_compliance(self) -> Dict:
        """Gate: SBS Compliance 100%"""
        
        compliance = self.results.get('compliance', {})
        sbs_ok = compliance.get('sbs_requirements_met', False)
        aml_ok = compliance.get('aml_validation_complete', False)
        audit_ok = compliance.get('audit_trail_present', False)
        
        passed_gate = sbs_ok and aml_ok and audit_ok
        
        return {
            'name': 'Compliance SBS',
            'passed': passed_gate,
            'value': 'OK' if passed_gate else 'FAIL',
            'threshold': 'ALL REQUIRED',
            'details': f"SBS:{sbs_ok} AML:{aml_ok} AUDIT:{audit_ok}",
            'critical': True
        }
    
    def save_report(self, filename: str = 'reports/quality-gates-report.json'):
        """Guarda reporte en archivo"""
        
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        
        report = self.evaluate_all()
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n📄 Reporte guardado: {filename}")
        
        return report

def main():
    """Función principal"""
    
    if len(sys.argv) < 2:
        print("Uso: python evaluate-quality-gates.py <test-results.json>")
        sys.exit(1)
    
    results_file = sys.argv[1]
    
    # Evaluar gates
    evaluator = QualityGatesEvaluator(results_file)
    report = evaluator.evaluate_all()
    
    # Guardar
    evaluator.save_report()
    
    # Exit code para GitHub Actions
    exit_code = 0 if report['can_merge'] else 1
    sys.exit(exit_code)

if __name__ == "__main__":
    main()
```

**Cómo usarlo:**

```bash
# Evaluar tests
python scripts/evaluate-quality-gates.py reports/api-test-results.json
echo $?  # 0 = gates OK, 1 = gates FAIL
```

---

## 🐍 EJEMPLO 5: EXECUTIVE REPORT GENERATOR

**Uso:** Para Actividad 5 - Reportes ejecutivos  
**Ruta:** `scripts/generate-executive-report.py`  
**Descripción:** Traduce métricas técnicas a insights para stakeholders  
**Duración práctica:** 15 min

```python
#!/usr/bin/env python3
"""
Executive Report Generator
Traduce métricas técnicas → insights para stakeholders
"""

import json
import sys
from datetime import datetime
from pathlib import Path

class ExecutiveReportGenerator:
    """Genera reportes para diferentes audiencias"""
    
    def __init__(self, test_results_file: str):
        """Inicializa con resultados de tests"""
        try:
            with open(test_results_file) as f:
                self.results = json.load(f)
        except FileNotFoundError:
            print(f"❌ Error: {test_results_file} no encontrado")
            sys.exit(1)
        
        self.timestamp = datetime.now()
    
    def generate_markdown_report(self) -> str:
        """Genera reporte en Markdown para GitHub/Email"""
        
        timestamp_str = self.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        
        report = f"""# 📊 MI BANCO QA TESTING REPORT

**Generado:** {timestamp_str}  
**Tipo:** Automated Testing Results

---

## 🎯 RESUMEN EJECUTIVO

| Métrica | Valor | Status |
|---------|-------|--------|
| **Tests Exitosos** | {self._get_passed_tests()}/{self._get_total_tests()} | {"✅" if self._get_success_rate() >= 95 else "⚠️"} |
| **Success Rate** | {self._get_success_rate():.1f}% | {"🟢 Good" if self._get_success_rate() >= 95 else "🟡 Warning"} |
| **Tiempo Ejecución** | {self._get_execution_time_minutes()}m | ⏱️ |
| **Cobertura** | {self._get_coverage()}% | {"🟢" if self._get_coverage() >= 80 else "🟡"} |
| **Issues Críticos** | {self._get_critical_issues()} | {"✅ None" if self._get_critical_issues() == 0 else "❌"} |
| **Compliance SBS** | {"✅ OK" if self._check_compliance() else "❌ FAIL"} | {"🟢" if self._check_compliance() else "🔴"} |

---

## 📈 ANÁLISIS DETALLADO

### Ejecución de Tests
- **Total tests**: {self._get_total_tests()}
- **Pasados**: {self._get_passed_tests()} ✅
- **Fallidos**: {self._get_failed_tests()} ❌
- **Saltados**: {self._get_skipped_tests()} ⊘

### Áreas Cubiertas

#### Transfers
- ✅ Validación de límites diarios
- ✅ Validación formato CCI
- {"✅ AML para montos grandes" if self._check_transfer_aml() else "⚠️ AML edge cases pendientes"}

#### Security & Compliance
- ✅ Headers HTTPS
- ✅ Protección CSRF
- ✅ Auditoría de operaciones
- ✅ Encriptación de datos

#### Performance
- ✅ Tests dentro de baseline
- ✅ No hay timeouts
- ✅ Respuestas en tiempo esperado

---

## 🎁 RECOMENDACIÓN DE NEGOCIO

{self._get_business_recommendation()}

---

## ⚠️ ITEMS QUE REQUIEREN ATENCIÓN

{self._get_issues_section()}

---

## 📋 PRÓXIMOS PASOS

1. {"✅ Proceder a deploy a staging" if self._can_deploy() else "❌ Resolver issues críticos antes de deploy"}
2. {"✅ Solicitar aprobación para producción" if self._can_deploy() else "❌ Realizar testing adicional"}
3. {"✅ Programar release" if self._can_deploy() else "❌ Comunicar delays a stakeholders"}

---

**Generado por:** GitHub Actions + Copilot IA  
**Pipeline:** Mi Banco QA Automation  
**Status:** {"✅ Ready" if self._can_deploy() else "⏳ In Progress"}
"""
        
        return report
    
    def _get_passed_tests(self) -> int:
        return self.results.get('stats', {}).get('tests', {}).get('passed', 0)
    
    def _get_failed_tests(self) -> int:
        return self.results.get('stats', {}).get('tests', {}).get('failed', 0)
    
    def _get_skipped_tests(self) -> int:
        return self.results.get('stats', {}).get('tests', {}).get('skipped', 0)
    
    def _get_total_tests(self) -> int:
        return self.results.get('stats', {}).get('tests', {}).get('total', 0)
    
    def _get_success_rate(self) -> float:
        total = self._get_total_tests()
        passed = self._get_passed_tests()
        return (passed / total * 100) if total > 0 else 0
    
    def _get_coverage(self) -> int:
        return self.results.get('coverage', {}).get('percentage', 0)
    
    def _get_execution_time_minutes(self) -> int:
        ms = self.results.get('timings', {}).get('totalTime', 0)
        return round(ms / 60000) if ms > 0 else 0
    
    def _get_critical_issues(self) -> int:
        issues = self.results.get('issues', [])
        return len([i for i in issues if i.get('severity') == 'CRITICAL'])
    
    def _check_compliance(self) -> bool:
        return self.results.get('compliance', {}).get('sbs_requirements_met', True)
    
    def _check_transfer_aml(self) -> bool:
        return self.results.get('tests', {}).get('transfer_aml_ok', True)
    
    def _can_deploy(self) -> bool:
        """Determina si es seguro deployar"""
        return (self._get_success_rate() >= 95 and 
                self._get_critical_issues() == 0 and 
                self._check_compliance())
    
    def _get_business_recommendation(self) -> str:
        """Genera recomendación en lenguaje de negocio"""
        
        if self._can_deploy():
            return f"""
✅ **SEGURO PARA DEPLOY A STAGING**

Análisis:
- Todos los tests completaron exitosamente
- No hay issues de seguridad críticos
- Cumplimiento SBS verificado
- Performance dentro de baseline

Acción recomendada: Proceder con deploy
"""
        else:
            issues = []
            if self._get_success_rate() < 95:
                issues.append(f"- Success rate {self._get_success_rate():.1f}% < 95% requerido")
            if self._get_critical_issues() > 0:
                issues.append(f"- {self._get_critical_issues()} issues críticos encontrados")
            if not self._check_compliance():
                issues.append("- Compliance SBS no cumple")
            
            return f"""
❌ **NO SEGURO PARA DEPLOY - REVISAR PRIMERO**

Issues encontrados:
{chr(10).join(issues)}

Acción recomendada: Resolver items críticos antes de deploy
"""
    
    def _get_issues_section(self) -> str:
        """Genera sección de issues"""
        
        issues = self.results.get('issues', [])
        
        if not issues:
            return "✅ No hay issues reportados"
        
        critical = [i for i in issues if i.get('severity') == 'CRITICAL']
        warnings = [i for i in issues if i.get('severity') == 'WARNING']
        
        section = ""
        
        if critical:
            section += "\n### 🔴 CRÍTICOS\n"
            for issue in critical:
                section += f"- **{issue.get('title')}**: {issue.get('description')}\n"
        
        if warnings:
            section += "\n### 🟡 WARNINGS\n"
            for issue in warnings:
                section += f"- {issue.get('title')}\n"
        
        return section if section else "✅ Sin issues"
    
    def save_markdown(self, filename: str = 'reports/executive-report.md'):
        """Guarda reporte Markdown"""
        
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        
        report = self.generate_markdown_report()
        
        with open(filename, 'w') as f:
            f.write(report)
        
        print(f"✅ Reporte Markdown guardado: {filename}")
        
        return report

def main():
    """Función principal"""
    
    if len(sys.argv) < 2:
        print("Uso: python generate-executive-report.py <test-results.json>")
        sys.exit(1)
    
    results_file = sys.argv[1]
    
    # Generar
    generator = ExecutiveReportGenerator(results_file)
    generator.save_markdown()
    
    print("✅ Reporte ejecutivo generado exitosamente")

if __name__ == "__main__":
    main()
```

---

## 📄 EJEMPLO 6: WORKFLOW COMPLETO - smart-qa-pipeline.yml

**Uso:** Para Actividad 6 - Pipeline completo  
**Ruta:** `.github/workflows/smart-qa-pipeline.yml`  
**Descripción:** Pipeline con selección inteligente y quality gates  
**Duración práctica:** 20 min

```yaml
name: Smart QA Pipeline - Test Selection + Gates

on:
  pull_request:
    branches: [main, develop]
  push:
    branches: [develop]

jobs:
  # Job 1: Detectar cambios y seleccionar tests
  detect-and-select:
    name: Detectar cambios y seleccionar tests
    runs-on: ubuntu-latest
    outputs:
      tests-to-run: ${{ steps.selector.outputs.tests-to-run }}
      test-count: ${{ steps.selector.outputs.test-count }}
    
    steps:
      - name: Checkout con historia completa
        uses: actions/checkout@v3
        with:
          fetch-depth: 0
      
      - name: Detectar archivos cambiados
        id: files
        run: |
          if [ "${{ github.event_name }}" = "pull_request" ]; then
            CHANGED=$(git diff --name-only origin/main...HEAD | tr '\n' ',' | sed 's/,$//')
          else
            CHANGED=$(git diff --name-only HEAD~1 HEAD | tr '\n' ',' | sed 's/,$//')
          fi
          echo "changed-files=$CHANGED" >> $GITHUB_OUTPUT
          echo "📝 Archivos cambiados: $CHANGED"
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      
      - name: Smart Test Selection
        id: selector
        run: |
          python scripts/smart-test-selector.py "${{ steps.files.outputs.changed-files }}"

  # Job 2: Ejecutar tests seleccionados
  run-selected-tests:
    name: Ejecutar Tests Seleccionados
    runs-on: ubuntu-latest
    needs: detect-and-select
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Instalar Newman
        run: npm install -g newman newman-reporter-htmlextra
      
      - name: Ejecutar Tests Seleccionados
        run: |
          echo "📊 Ejecutando ${{ needs.detect-and-select.outputs.test-count }} tests"
          newman run collections/mi-banco-apis.json \
            --grep "${{ needs.detect-and-select.outputs.tests-to-run }}" \
            --reporters cli,htmlextra,json \
            --reporter-htmlextra-export reports/test-report.html \
            --reporter-json-export reports/test-results.json \
            --delay-request 100 \
            --timeout-request 5000 || true
      
      - name: Upload Reports
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: test-reports
          path: reports/
          retention-days: 30

  # Job 3: Evaluar quality gates
  evaluate-gates:
    name: Evaluar Quality Gates
    runs-on: ubuntu-latest
    needs: run-selected-tests
    if: always()
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/download-artifact@v3
        with:
          name: test-reports
          path: reports/
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      
      - name: Evaluar Gates
        id: gates
        run: |
          python scripts/evaluate-quality-gates.py reports/test-results.json || true
      
      - name: Upload Gates Report
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: quality-gates-report
          path: reports/quality-gates-report.json

  # Job 4: Generar reporte ejecutivo
  generate-report:
    name: Generar Reporte Ejecutivo
    runs-on: ubuntu-latest
    needs: [run-selected-tests, evaluate-gates]
    if: always()
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/download-artifact@v3
        with:
          name: test-reports
          path: reports/
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      
      - name: Generar Reporte
        run: |
          python scripts/generate-executive-report.py reports/test-results.json
      
      - name: Upload Final Report
        uses: actions/upload-artifact@v3
        with:
          name: executive-report
          path: reports/executive-report.md

  # Job 5: Comentar en PR
  comment-pr:
    name: Comentar resultado en PR
    runs-on: ubuntu-latest
    needs: [evaluate-gates, generate-report]
    if: github.event_name == 'pull_request' && always()
    
    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/download-artifact@v3
        with:
          name: executive-report
          path: reports/
      
      - name: Comentar en PR
        run: |
          REPORT=$(cat reports/executive-report.md)
          gh pr comment ${{ github.event.pull_request.number }} --body "$REPORT"
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

---

## 📋 EJEMPLO 7: MOCK TEST RESULTS JSON

**Uso:** Para testing local de scripts  
**Ruta:** `reports/mock-test-results.json`  
**Descripción:** Datos de prueba para evaluar quality gates  

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "stats": {
    "tests": {
      "total": 50,
      "passed": 48,
      "failed": 2,
      "skipped": 0
    }
  },
  "timings": {
    "totalTime": 180000
  },
  "coverage": {
    "percentage": 85
  },
  "security_scan": {
    "vulnerabilities": []
  },
  "compliance": {
    "sbs_requirements_met": true,
    "aml_validation_complete": true,
    "audit_trail_present": true
  },
  "tests": {
    "transfer_aml_ok": true
  },
  "issues": []
}
```

**Versión con errores (para probar gates FAIL):**

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "stats": {
    "tests": {
      "total": 50,
      "passed": 40,
      "failed": 10,
      "skipped": 0
    }
  },
  "timings": {
    "totalTime": 300000
  },
  "coverage": {
    "percentage": 65
  },
  "security_scan": {
    "vulnerabilities": [
      {"severity": "CRITICAL", "title": "SQL Injection en login"},
      {"severity": "HIGH", "title": "XSS en formulario"}
    ]
  },
  "compliance": {
    "sbs_requirements_met": false,
    "aml_validation_complete": true,
    "audit_trail_present": false
  },
  "tests": {
    "transfer_aml_ok": false
  },
  "issues": [
    {"severity": "CRITICAL", "title": "SQL Injection", "description": "Campo login vulnerable"},
    {"severity": "WARNING", "title": "Timeout alto", "description": "API transfers > 5s"}
  ]
}
```

---

## 🚀 COMANDOS DE TESTING LOCAL

### Test Smart Selector

```bash
# Simular cambios en transfers
python scripts/smart-test-selector.py "src/transfers/api.py,src/security/ssl.py"

# Simular cambios en login
python scripts/smart-test-selector.py "src/login/auth.py"

# Sin cambios específicos (corre todo)
python scripts/smart-test-selector.py ""
```

### Test Quality Gates

```bash
# Con mock exitoso
echo '{"stats": {"tests": {"passed": 48, "total": 50}}, "compliance": {"sbs_requirements_met": true, "aml_validation_complete": true, "audit_trail_present": true}}' > reports/test.json
python scripts/evaluate-quality-gates.py reports/test.json
echo "Exit code: $?"  # Debería ser 0

# Con mock fallido
echo '{"stats": {"tests": {"passed": 40, "total": 50}}, "compliance": {"sbs_requirements_met": false}}' > reports/test-fail.json
python scripts/evaluate-quality-gates.py reports/test-fail.json
echo "Exit code: $?"  # Debería ser 1
```

### Test Executive Report

```bash
python scripts/generate-executive-report.py reports/mock-test-results.json
cat reports/executive-report.md
```

---

## 📚 REFERENCIAS RÁPIDAS

| Script | Input | Output | Exit Code |
|--------|-------|--------|-----------|
| smart-test-selector.py | archivos cambiados (CSV) | tests a ejecutar | 0 siempre |
| evaluate-quality-gates.py | test-results.json | quality-gates-report.json | 0=OK, 1=FAIL |
| generate-executive-report.py | test-results.json | executive-report.md | 0 siempre |

---

**CÓDIGO EJECUTABLE COMPLETO** ✅

Todos los archivos listos para copiar y pegar  
Mi Banco QE Team | Taller 6
