# Lab 4: Security Overview & Metrics Dashboard

**Duración:** 10 minutos | **Nivel:** ⭐ | **Objetivo:** Entender y usar el dashboard de seguridad de GitHub

---

## 🎯 Objetivo del Lab

En este lab aprenderás a:
- ✅ Navegar el Security Overview
- ✅ Interpretar métricas de seguridad
- ✅ Crear reportes ejecutivos
- ✅ Identificar tendencias y patrones
- ✅ Priorizar trabajo de remediación

---

## 📋 Requisitos Previos

- GHAS habilitado
- CodeQL ejecutado al menos una vez
- Dependabot activo
- Permisos de lectura en Security tab

---

## 🚀 Paso 1: Security Overview (3 min)

### Acceder al Dashboard

1. Ve a **Security** → **Overview**
2. Selecciona tiempo: `Last 30 days`

### Paneles Principales

```
┌─────────────────────────────────────────────┐
│  📊 SECURITY OVERVIEW                       │
├─────────────────────────────────────────────┤
│  Code Scanning Alerts                       │
│  🔴 Critical: 2  🟠 High: 5  🟡 Medium: 12  │
├─────────────────────────────────────────────┤
│  Dependency Alerts                          │
│  🔴 Critical: 1  🟠 High: 3  🟡 Medium: 8   │
├─────────────────────────────────────────────┤
│  Secret Scanning                            │
│  🔴 Active: 1  🟢 Resolved: 4               │
├─────────────────────────────────────────────┤
│  Trend (Last 30 days)                       │
│  📈 New alerts: 12                          │
│  📉 Resolved: 18                            │
│  ✅ Net improvement: -6                     │
└─────────────────────────────────────────────┘
```

---

## 🔍 Paso 2: Code Scanning Alerts (2 min)

### Filtrar por Severidad

Clic en **Code scanning** → Filtros:

```yaml
Filters disponibles:
- Severity: Critical, High, Medium, Low
- State: Open, Closed, Fixed, Dismissed
- Tool: CodeQL, Semgrep, etc.
- Branch: main, develop, feature/*
- Language: Python, JavaScript, etc.
```

### Ejemplo de Vista

```
┌────────────────────────────────────────────────────┐
│ SQL Injection                            🔴 CRITICAL│
│ src/vulnerable/app.py:45                           │
│ Opened 3 days ago                                  │
│ Rule: py/sql-injection                             │
│ CWE-89                                             │
│                                                    │
│ [View Details] [Dismiss] [Create Issue]           │
└────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────┐
│ Hardcoded Credentials                    🟠 HIGH   │
│ config/settings.py:12                              │
│ Opened 1 week ago                                  │
│ Rule: py/hardcoded-credentials                     │
│                                                    │
│ [View Details] [Dismiss] [Create Issue]           │
└────────────────────────────────────────────────────┘
```

### Acciones Disponibles

| Acción | Cuándo usar |
|--------|-------------|
| **Fix** | La vulnerabilidad es real |
| **Dismiss** | False positive o no aplicable |
| **Create Issue** | Trackear en backlog |
| **Suppress** | Temporal, con justificación |

---

## 📊 Paso 3: Métricas y KPIs (3 min)

### KPIs de Seguridad

```python
# Calcular Security Posture Score
def calculate_security_score():
    """
    Score = 100 - (penalties)
    
    Penalties:
    - CRITICAL alert open: -10 points each
    - HIGH alert open: -5 points each
    - MEDIUM alert open: -2 points each
    - Secret exposed: -15 points
    - No branch protection: -20 points
    """
    
    score = 100
    score -= critical_alerts * 10
    score -= high_alerts * 5
    score -= medium_alerts * 2
    score -= exposed_secrets * 15
    
    if not branch_protected:
        score -= 20
    
    return max(0, score)

# Ejemplo
alerts = {
    'critical': 2,  # -20
    'high': 5,      # -25
    'medium': 12,   # -24
    'secrets': 1    # -15
}

score = 100 - 20 - 25 - 24 - 15 = 16
# 🔴 Poor security posture!
```

### Mean Time to Remediation (MTTR)

```
Alert created: 2024-12-01 10:00
Alert fixed: 2024-12-03 14:00

MTTR = 2 days, 4 hours

Benchmarks:
🟢 Excellent: < 24 hours
🟡 Good: 1-3 days
🟠 Fair: 3-7 days
🔴 Poor: > 7 days
```

### Vulnerability Density

```
Total vulnerabilities: 24
Lines of code: 15,000

Density = 24 / 15,000 * 1000 = 1.6 per 1K LOC

Benchmarks:
🟢 Excellent: < 0.5
🟡 Good: 0.5 - 1.0
🟠 Fair: 1.0 - 2.0
🔴 Poor: > 2.0
```

---

## 📈 Paso 4: Trends & Patterns (2 min)

### Gráfico de Tendencias

```
Alerts over time (Last 90 days)

30 │                           ╭─╮
   │                      ╭────╯ ╰─╮
25 │                 ╭────╯         ╰─╮
   │            ╭────╯                 ╰─╮
20 │       ╭────╯                         ╰─╮
   │  ╭────╯                                 ╰─
15 │──╯
   └────────────────────────────────────────────
   Sep          Oct          Nov          Dec

📊 Analysis:
- Peak in October (major release)
- Decreasing trend (good!)
- Current: 15 open alerts
```

### Patrón de Inyección

```
Vulnerability Type Breakdown:

SQL Injection      █████████ 35%
XSS               ██████ 25%
Hardcoded Secrets ████ 15%
Command Injection ███ 12%
Path Traversal    ██ 8%
Other            █ 5%

🎯 Focus: SQL Injection (35% of issues)
Action: Security training on prepared statements
```

---

## 🎓 Ejercicio Práctico

### Crear Reporte Ejecutivo

Imagina que eres Tech Lead. Genera reporte para el CTO:

**Template:**

```markdown
# Security Report - December 2024

## Executive Summary
- Security Score: 72/100 (🟡 Good)
- Trend: ↗️ Improving (+8 from last month)
- Critical Issues: 2 (down from 5)

## Highlights
✅ Fixed 18 vulnerabilities this month
✅ MTTR improved from 5 days to 2 days
✅ Zero secrets exposed

⚠️ 2 CRITICAL alerts still open:
   1. SQL Injection in payment module (7 days old)
   2. Authentication bypass in API (3 days old)

## Action Items
1. [HIGH] Fix CRITICAL alerts by EOW
2. [MED] Security training on SQL injection
3. [LOW] Update dependency scanning rules

## Metrics
| Metric | Current | Last Month | Target |
|--------|---------|------------|--------|
| Security Score | 72 | 64 | 80+ |
| MTTR | 2 days | 5 days | < 1 day |
| Open CRITICAL | 2 | 5 | 0 |
| Vuln Density | 1.2/KLOC | 1.8/KLOC | < 1.0 |

## Next Steps
- Sprint focus: Remediate all CRITICAL alerts
- Schedule: Security workshop for team
- Investment: CodeQL custom queries for ML security
```

---

## 🛠️ Paso 5: Automatizar Reportes

### GitHub API para Métricas

```python
#!/usr/bin/env python3
"""
Generate security metrics report from GitHub API
"""

import requests
from datetime import datetime

def get_security_metrics(repo: str, token: str):
    """Fetch security metrics from GitHub API"""
    
    headers = {
        'Authorization': f'token {token}',
        'Accept': 'application/vnd.github+json'
    }
    
    # Code scanning alerts
    url = f'https://api.github.com/repos/{repo}/code-scanning/alerts'
    response = requests.get(url, headers=headers)
    alerts = response.json()
    
    # Count by severity
    metrics = {
        'critical': 0,
        'high': 0,
        'medium': 0,
        'low': 0
    }
    
    for alert in alerts:
        if alert['state'] == 'open':
            severity = alert['rule']['security_severity_level']
            metrics[severity] = metrics.get(severity, 0) + 1
    
    # Calculate score
    score = 100
    score -= metrics.get('critical', 0) * 10
    score -= metrics.get('high', 0) * 5
    score -= metrics.get('medium', 0) * 2
    
    return {
        'score': max(0, score),
        'alerts': metrics,
        'timestamp': datetime.now().isoformat()
    }

# Usage
metrics = get_security_metrics('mi-banco/repo', 'ghp_token')
print(f"Security Score: {metrics['score']}/100")
```

### Integrar con Slack

```yaml
# .github/workflows/security-report.yml
name: Weekly Security Report

on:
  schedule:
    - cron: '0 9 * * MON'  # Every Monday 9 AM

jobs:
  report:
    runs-on: ubuntu-latest
    steps:
      - name: Generate Report
        run: |
          python scripts/generate-security-report.py \
            --repo ${{ github.repository }} \
            --output report.json
      
      - name: Send to Slack
        uses: slackapi/slack-github-action@v1
        with:
          channel-id: 'security-alerts'
          slack-message: |
            📊 Weekly Security Report
            
            Security Score: ${{ steps.report.outputs.score }}/100
            Critical: ${{ steps.report.outputs.critical }}
            High: ${{ steps.report.outputs.high }}
            
            Full report: ${{ github.server_url }}/${{ github.repository }}/security
        env:
          SLACK_BOT_TOKEN: ${{ secrets.SLACK_BOT_TOKEN }}
```

---

## ✅ Checklist de Validación

- [ ] Accedí al Security Overview
- [ ] Navegué Code Scanning alerts
- [ ] Entiendo cómo filtrar por severity
- [ ] Calculé Security Score de mi proyecto
- [ ] Identifiqué el tipo de vulnerabilidad más común
- [ ] Creé un reporte ejecutivo de ejemplo

---

## ❓ Preguntas Frecuentes

**P1: ¿Qué es un buen Security Score?**
R: 
- 90-100: Excelente
- 80-89: Bueno
- 70-79: Aceptable
- < 70: Requiere atención

**P2: ¿Cómo priorizar remediación?**
R: Orden de prioridad:
1. CRITICAL + Explotable + Producción
2. CRITICAL + Explotable + Dev
3. HIGH + Explotable
4. CRITICAL + No explotable
5. HIGH + No explotable
6. MEDIUM/LOW

**P3: ¿Con qué frecuencia revisar el dashboard?**
R:
- Tech Lead: Diario
- Dev Team: Al menos 2x/semana
- Management: Semanal
- Executive: Mensual

**P4: ¿Cómo medir mejora?**
R: Track:
- Security Score (↑ es mejor)
- MTTR (↓ es mejor)
- Open CRITICAL alerts (↓ es mejor)
- Vulnerability density (↓ es mejor)

---

## 💡 Best Practices

### 1. Dashboard Review Ritual

```
Monday Morning (15 min):
1. Check Security Overview
2. Review new alerts from weekend
3. Prioritize critical items
4. Assign to team members
5. Set sprint goals
```

### 2. Tracking Trends

```python
# Log metrics weekly
weekly_metrics = {
    'week': '2024-W50',
    'score': 72,
    'critical': 2,
    'high': 5,
    'mttr_hours': 48
}

# Compare with historical data
if score > last_week_score:
    print("✅ Improving!")
else:
    print("⚠️ Deteriorating - action needed")
```

### 3. Communication

```
🎯 For Developers:
   - Focus on: Technical details, code fixes
   - Frequency: Daily/Weekly
   - Format: Slack, GitHub comments

📊 For Management:
   - Focus on: Metrics, trends, risks
   - Frequency: Weekly/Monthly
   - Format: Dashboard, reports

💼 For Executives:
   - Focus on: Business impact, compliance
   - Frequency: Monthly/Quarterly
   - Format: Executive summary, slides
```

---

## 📚 Recursos Adicionales

- [Security Overview Docs](https://docs.github.com/en/code-security/security-overview)
- [GitHub API - Code Scanning](https://docs.github.com/en/rest/code-scanning)
- [OWASP Metrics](https://owasp.org/www-project-security-qualitative-metrics/)

---

**¡Felicidades! Completaste Lab 4** 🎉

¿Listo para Lab 5? → `cd ../lab-5-remediation && cat README.md`
