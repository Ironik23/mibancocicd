# Lab 3: Security Policies & Branch Protection

**Duración:** 15 minutos | **Nivel:** ⭐⭐ | **Objetivo:** Implementar políticas de seguridad y protección de ramas

---

## 🎯 Objetivo del Lab

En este lab aprenderás a:
- ✅ Configurar branch protection rules
- ✅ Crear security policy (SECURITY.md)
- ✅ Implementar gates de seguridad en CI/CD
- ✅ Bloquear merges con vulnerabilidades críticas
- ✅ Configurar required checks

---

## 📋 Requisitos Previos

- Repositorio con GHAS habilitado
- Permisos de admin en el repositorio
- GitHub Actions configurado
- CodeQL y Dependabot activos

---

## 🚀 Paso 1: Branch Protection Rules (5 min)

### Configurar Protección de main

1. Ve a **Settings** → **Branches** → **Add rule**
2. Branch name pattern: `main`
3. Configura las siguientes reglas:

```yaml
Protection rules:
✅ Require pull request before merging
   ✅ Require approvals: 1
   ✅ Dismiss stale reviews
   ✅ Require review from Code Owners

✅ Require status checks to pass
   ✅ CodeQL Analysis
   ✅ Dependency Review
   ✅ Unit Tests
   ✅ Security Scan
   
✅ Require conversation resolution before merging

✅ Require signed commits (opcional)

✅ Require linear history

✅ Do not allow bypassing (ni para admins)
```

### Ejemplo Visual

```
Developer → Create PR → ❌ Can't merge until:
                         ✅ 1 approval
                         ✅ CodeQL passed
                         ✅ No CRITICAL vulnerabilities
                         ✅ Tests passed
                         ✅ All conversations resolved
                      → ✅ Merge allowed
```

---

## 📝 Paso 2: Security Policy (4 min)

### Crear SECURITY.md

Crea el archivo en la raíz del proyecto:

```markdown
# Security Policy

## 🔒 Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.x     | ✅ Full support    |
| 1.9.x   | ⚠️ Security fixes only |
| < 1.9   | ❌ Not supported   |

## 🚨 Reporting a Vulnerability

**DO NOT** create a public GitHub issue for security vulnerabilities.

Instead, please report via:

### Option 1: GitHub Security Advisories (Preferred)
1. Go to **Security** → **Advisories**
2. Click **New draft security advisory**
3. Fill in details
4. Submit

### Option 2: Email
Send to: security@mibanco.com
- Subject: `[SECURITY] Brief description`
- Include: Steps to reproduce, impact, affected versions

### What to expect
- **Response time:** 48 hours
- **Fix timeline:** 
  - CRITICAL: 24-48 hours
  - HIGH: 1 week
  - MEDIUM: 2 weeks
  - LOW: Next release

## 🛡️ Security Best Practices

### For Contributors
- ✅ Never commit secrets (API keys, passwords)
- ✅ Use environment variables for credentials
- ✅ Run security scans locally before PR
- ✅ Keep dependencies updated
- ✅ Follow secure coding guidelines

### For Users
- ✅ Always use latest version
- ✅ Enable 2FA on GitHub
- ✅ Use secrets manager for credentials
- ✅ Review dependency alerts regularly

## 🔍 Security Scanning

This project uses:
- **CodeQL** - Static analysis for vulnerabilities
- **Dependabot** - Dependency vulnerability scanning
- **Secret Scanning** - Detect exposed credentials
- **Container Scanning** - Docker image vulnerabilities

## 📚 Security Resources

- [OWASP Top 10](https://owasp.org/Top10/)
- [CWE Database](https://cwe.mitre.org/)
- [GitHub Security Best Practices](https://docs.github.com/en/code-security)

## 🏆 Hall of Fame

Thanks to security researchers who responsibly disclosed vulnerabilities:
- (List will be updated with permission)

---

Last updated: 2024-12-10
```

### Por qué es Importante

```
✅ Con SECURITY.md:
   - Investigadores saben cómo reportar
   - Proceso claro y profesional
   - Respuesta coordinada

❌ Sin SECURITY.md:
   - Reportes en issues públicos
   - Vulnerabilidad expuesta prematuramente
   - Caos en la respuesta
```

---

## 🛡️ Paso 3: Security Gates en CI/CD (4 min)

### Crear Workflow de Security Gate

`.github/workflows/security-gate.yml`:

```yaml
name: Security Gate

on:
  pull_request:
    branches: [main, develop]

jobs:
  security-check:
    runs-on: ubuntu-latest
    name: Security Checks
    
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      
      - name: Check for CRITICAL vulnerabilities
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: 'fs'
          scan-ref: '.'
          format: 'json'
          output: 'trivy-results.json'
          exit-code: '1'  # Fail on CRITICAL
          severity: 'CRITICAL,HIGH'
      
      - name: Dependency Review
        uses: actions/dependency-review-action@v3
        with:
          fail-on-severity: high
          deny-licenses: GPL-3.0, AGPL-3.0
      
      - name: Secret Scan
        uses: trufflesecurity/trufflehog@main
        with:
          path: ./
          base: ${{ github.event.pull_request.base.sha }}
          head: ${{ github.event.pull_request.head.sha }}
      
      - name: CodeQL Results Check
        run: |
          # Verificar que no hay alertas CRITICAL sin resolver
          CRITICAL_COUNT=$(gh api \
            repos/${{ github.repository }}/code-scanning/alerts \
            --jq '[.[] | select(.state=="open" and .rule.security_severity_level=="critical")] | length')
          
          if [ "$CRITICAL_COUNT" -gt 0 ]; then
            echo "❌ Found $CRITICAL_COUNT CRITICAL alerts"
            exit 1
          fi
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Block on failed checks
        if: failure()
        run: |
          echo "🚫 Security gate FAILED"
          echo "Cannot merge until security issues are resolved"
          exit 1
```

### Qué hace este workflow

```
Pull Request creado
   ↓
1. Trivy escanea vulnerabilidades → ❌ Falla si hay CRITICAL
   ↓
2. Dependency Review → ❌ Falla si hay HIGH+ o licencias prohibidas
   ↓
3. Secret scan → ❌ Falla si hay secrets
   ↓
4. CodeQL check → ❌ Falla si hay alertas CRITICAL abiertas
   ↓
✅ Todos pasan → Allow merge
```

---

## 🔐 Paso 4: CODEOWNERS (2 min)

### Crear .github/CODEOWNERS

```bash
# Security-sensitive files require security team review
/src/secure/*                    @mi-banco/security-team
/.github/workflows/*             @mi-banco/devops-team
/scripts/security/*              @mi-banco/security-team

# ML models require DS lead review
/models/*                        @mi-banco/ds-leads
/src/models/*                    @mi-banco/ds-leads
/notebooks/*                     @mi-banco/ds-team

# Infrastructure as Code
*.tf                             @mi-banco/devops-team
*.yml                            @mi-banco/devops-team
*.yaml                           @mi-banco/devops-team

# Documentation
*.md                             @mi-banco/tech-writers

# Default owners
*                                @mi-banco/core-team
```

### Cómo funciona

```
Developer crea PR modificando: src/secure/auth.py
   ↓
GitHub automáticamente:
   ✅ Asigna @mi-banco/security-team como reviewer
   ✅ Requiere aprobación de security team
   ✅ No permite merge sin aprobación
```

---

## ⚡ Ejercicio Práctico

### Escenario: PR con Vulnerabilidad

1. **Developer crea PR:**
   ```python
   # Nuevo código
   def process_payment(card_number):
       print(f"Processing: {card_number}")  # ❌ Log PII
   ```

2. **Security Gates ejecutan:**
   ```
   ✅ CodeQL: PASS
   ❌ Secret Scan: PASS
   ❌ Custom Rule: FAIL - PII in logs detected
   ```

3. **PR bloqueado:**
   ```
   🚫 Cannot merge
   Reason: PII logging detected in src/payment.py:45
   Action required: Remove PII from logs
   ```

4. **Developer corrige:**
   ```python
   def process_payment(card_number):
       masked = "*" * 12 + card_number[-4:]
       print(f"Processing: {masked}")  # ✅ Masked PII
   ```

5. **Re-run checks:**
   ```
   ✅ All checks passed
   ✅ Ready to merge
   ```

---

## 📊 Paso 5: Monitoring Compliance

### Dashboard de Compliance

Ve a: **Security** → **Overview**

```
Branch Protection Status:
✅ main: Protected
   - Requires 1 approval
   - Requires status checks
   - No force push
   
⚠️ develop: Partially protected
   - Requires status checks
   - ❌ No approval required
   
❌ feature/*: Not protected
```

### Audit Log

Ve a: **Settings** → **Audit log**

Rastrea:
- Cambios en branch protection
- Bypass attempts
- Security policy changes
- Code owner changes

---

## ✅ Checklist de Validación

- [ ] Branch protection configurado en main
- [ ] SECURITY.md creado y completo
- [ ] Security gate workflow implementado
- [ ] CODEOWNERS configurado
- [ ] Probé crear PR y revisar gates
- [ ] Verifico que no puedo hacer merge sin aprobación

---

## ❓ Preguntas Frecuentes

**P1: ¿Puedo bypass las protecciones en emergencia?**
R: Sí, admins pueden bypass, pero queda registrado en audit log. Úsalo solo en emergencias reales.

**P2: ¿Cuántos approvals son suficientes?**
R: Depende del proyecto:
- Crítico (banking): 2+ approvals
- Producción: 1 approval
- Dev/staging: Opcional

**P3: ¿Qué pasa si CodeQL falla en PR?**
R: El PR queda bloqueado. Opciones:
1. Corregir la vulnerabilidad (recomendado)
2. Suprimir false positive con comentario
3. Bypass (solo emergencias)

**P4: ¿CODEOWNERS es obligatorio?**
R: No, pero altamente recomendado para:
- Archivos sensibles de seguridad
- Infraestructura como código
- Modelos ML en producción

---

## 💡 Best Practices

### 1. Principio de Defensa en Profundidad
```
Layer 1: Pre-commit hooks (local)
Layer 2: CodeQL en PR (GitHub)
Layer 3: Security gate (CI/CD)
Layer 4: Branch protection (GitHub)
Layer 5: Code review (humano)
```

### 2. Evolución de Políticas
```
Inicio: Protección básica
   ↓
Semana 2: Agregar CodeQL
   ↓
Mes 1: Agregar security gates
   ↓
Mes 2: CODEOWNERS completo
   ↓
Mes 3: Advanced policies
```

### 3. Balance Seguridad vs Velocidad
```
❌ Muy estricto:
   - 5 approvals required
   - 20 checks obligatorios
   - Nadie puede hacer merge
   → Equipo frustrado

✅ Balanceado:
   - 1-2 approvals
   - 5-7 checks críticos
   - Clear escalation path
   → Equipo productivo y seguro
```

---

## 📚 Recursos Adicionales

- [Branch Protection Rules](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/defining-the-mergeability-of-pull-requests/about-protected-branches)
- [CODEOWNERS](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners)
- [Security Policy Guide](https://docs.github.com/en/code-security/getting-started/adding-a-security-policy-to-your-repository)

---

**¡Felicidades! Completaste Lab 3** 🎉

¿Listo para Lab 4? → `cd ../lab-4-overview && cat README.md`
