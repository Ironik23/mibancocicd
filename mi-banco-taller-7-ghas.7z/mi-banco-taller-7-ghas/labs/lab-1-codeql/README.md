# Lab 1: CodeQL - Análisis Semántico de Código

**Duración:** 20 minutos | **Nivel:** ⭐⭐ | **Objetivo:** Entender y ejecutar análisis con CodeQL

---

## 🎯 Objetivo del Lab

En este lab aprenderás a:
- ✅ Entender cómo funciona CodeQL
- ✅ Analizar código vulnerable con CodeQL
- ✅ Identificar vulnerabilidades comunes
- ✅ Ver resultados en el dashboard de GitHub

---

## 📋 Requisitos Previos

- Git configurado
- Acceso a GitHub con GHAS habilitado
- Python 3.8+
- Conocimiento básico de vulnerabilidades (SQL injection, XSS, etc.)

---

## 🚀 Paso 1: Entender CodeQL (5 min)

### ¿Qué es CodeQL?

CodeQL es un motor de análisis semántico que entiende el código:

```
❌ TRADICIONAL (Búsqueda de patrones)
   Busca: "subprocess.run"
   Problema: Muchos falsos positivos

✅ CodeQL (Análisis semántico)
   Entiende: ¿Se pasa shell=True?
   Ventaja: Menos falsos positivos
```

### Las 3 Preguntas que CodeQL Responde

1. **¿Cuál es el flujo de datos?**
   - De dónde viene la entrada
   - A dónde va

2. **¿Cuál es el contexto?**
   - ¿Se sanitiza?
   - ¿Se valida?

3. **¿Hay vulnerabilidad?**
   - Entrada no sanitizada → Uso peligroso

---

## 🔍 Paso 2: Analizar el Código Vulnerable (5 min)

### Versión Vulnerable

Abre: `src/vulnerable/vulnerable_app.py`

```python
def get_user_by_email(email):
    """❌ VULNERABLE: SQL Injection"""
    query = f"SELECT * FROM users WHERE email = '{email}'"
    cursor.execute(query)  # ← PELIGRO: entrada sin sanitizar
```

**¿Qué ve CodeQL?**
1. `email` viene del parámetro de entrada (no confiable)
2. Se usa en una query SQL
3. No hay sanitización
4. ❌ **VULNERABILIDAD: SQL Injection**

### Otro Ejemplo

```python
def run_command(cmd):
    """❌ VULNERABLE: Command Injection"""
    subprocess.run(cmd, shell=True)  # ← PELIGRO
```

**¿Qué ve CodeQL?**
1. `cmd` es entrada
2. Se pasa a subprocess con `shell=True`
3. ❌ **VULNERABILIDAD: Command Injection**

---

## ✅ Paso 3: Ver la Versión Segura (3 min)

Abre: `src/secure/secure_app.py`

```python
def get_user_by_email(email: str) -> list:
    """✅ SEGURO: Prepared Statements"""
    query = "SELECT * FROM users WHERE ?"
    cursor.execute(query, (email,))  # ← SEGURO: parametrizado
```

**¿Qué ve CodeQL?**
1. Query usa placeholders (?)
2. Datos pasan como parámetros separados
3. ✅ **NO vulnerabilidad: SQL Injection**

---

## 🖥️ Paso 4: Ejecutar CodeQL (4 min)

### En GitHub Actions

Si habilitaste GHAS en tu repositorio:

```bash
git push origin main
```

Luego:
1. Ve a: **Settings** → **Code security & analysis**
2. Verifica que **CodeQL** está habilitado
3. Ve a: **Security** → **Code scanning alerts**
4. Deberías ver las vulnerabilidades encontradas

### Localmente (Opcional)

```bash
# Instalar CodeQL CLI
gh extension install github/gh-codeql

# Ejecutar análisis
gh codeql database create mi-banco-db
gh codeql database analyze mi-banco-db --format=csv --output=results.csv
```

---

## 📊 Paso 5: Interpretar Resultados (3 min)

### Ejemplo de Salida

```
Vulnerability: SQL Injection
File: src/vulnerable/vulnerable_app.py
Line: 45
Severity: HIGH
Message: This query is built from user input
Rule: py/sql-injection
```

### Significados de Severidad

| Severity | Significado | Acción |
|----------|------------|--------|
| CRITICAL | Riesgo inmediato | Corregir hoy |
| HIGH | Grave | Corregir esta semana |
| MEDIUM | Moderado | Corregir este mes |
| LOW | Bajo | Revisar |

---

## 🎓 Comparación: Antes vs Después

### Antes (Vulnerable)
```python
# ❌ 8 vulnerabilidades detectadas
- SQL Injection (1)
- Command Injection (1)
- Weak Cryptography (2)
- Hardcoded Secrets (1)
- Dangerous Imports (1)
- Unsafe Logging (1)
- Path Traversal (1)
```

### Después (Seguro)
```python
# ✅ Todas corregidas
- Prepared statements
- No shell=True
- PBKDF2 hashing
- Variables de entorno
- Subprocess seguro
- Logs filtrados
- Path validation
```

---

## ✅ Checklist de Validación

- [ ] Leí las 8 vulnerabilidades en `vulnerable_app.py`
- [ ] Entiendo cada vulnerabilidad
- [ ] Ví las correcciones en `secure_app.py`
- [ ] Entiendo el concepto de "prepared statements"
- [ ] Sé por qué `shell=True` es peligroso
- [ ] Puedo explicar "SQL Injection" en 30 segundos

---

## ❓ Preguntas Clave

**P1: ¿Por qué CodeQL es mejor que búsqueda de patrones?**
R: Entiende la semántica del código, no solo regexes. Menos falsos positivos.

**P2: ¿Qué es SQL Injection?**
R: Atacante inyecta SQL en entrada del usuario que modifica la query.

**P3: ¿Qué es Prepared Statement?**
R: Separar estructura SQL de los datos. El database sabe qué es qué.

**P4: ¿Por qué evitar `shell=True`?**
R: Si entrada tiene `;` o `|`, puede ejecutar comandos extra.

---

## 📚 Próximos Pasos

1. **Ahora:** Completaste Lab 1 ✅
2. **Siguiente:** Lab 2 (Dependabot)
3. **Después:** Lab 3 (Branch Protection)

---

## 💡 Tips Importantes

1. **CodeQL es preventivo**
   - Se ejecuta en cada PR
   - Previene que entre código vulnerable

2. **No todas las vulnerabilidades son reales**
   - CodeQL puede reportar falsos positivos
   - Revisa manualmente cada una

3. **La mejor defensa es el código seguro**
   - Todos deben conocer estas vulnerabilidades
   - Aplícalas en tus proyectos

---

**¡Felicidades! Completaste Lab 1** 🎉

¿Listo para Lab 2? → `cd ../lab-2-dependabot && cat README.md`
