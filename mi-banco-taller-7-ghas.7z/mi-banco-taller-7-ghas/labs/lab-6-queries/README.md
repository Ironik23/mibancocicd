# Lab 6: Custom CodeQL Queries

**Duración:** 25 minutos | **Nivel:** ⭐⭐⭐⭐ | **Objetivo:** Crear queries CodeQL personalizadas para tu dominio

---

## 🎯 Objetivo del Lab

En este lab aprenderás a:
- ✅ Entender la estructura de queries CodeQL
- ✅ Crear queries custom para tu dominio (ML, banking)
- ✅ Detectar patrones específicos de tu aplicación
- ✅ Integrar queries custom en el workflow
- ✅ Compartir queries con el equipo

---

## 📋 Requisitos Previos

- Conocimiento básico de CodeQL
- Lab 1 completado
- Python/JavaScript conocimiento intermedio
- Editor con syntax highlighting para QL

---

## 🚀 Paso 1: Anatomía de una Query (5 min)

### Estructura Básica

```ql
/**
 * @name Vulnerable pattern name
 * @description Detailed description of what this detects
 * @kind problem
 * @problem.severity warning
 * @precision high
 * @id my-org/my-custom-query
 * @tags security
 *       external/cwe/cwe-89
 */

import python

// Define el patrón a buscar
from ... 
where ...
select ...
```

### Componentes

```ql
// 1. METADATA (comentario inicial)
/**
 * @name - Nombre corto para UI
 * @kind - Tipo: problem, path-problem, alert
 * @precision - Qué tan preciso: high, medium, low
 * @problem.severity - error, warning, recommendation
 */

// 2. IMPORTS
import python
import semmle.python.security.dataflow.SqlInjection

// 3. LÓGICA
from FunctionCall call, Expr arg
where 
  call.getFunction().getName() = "execute" and
  arg = call.getArg(0) and
  not arg.isConstant()
select call, "Potential SQL injection"
```

---

## 🔍 Paso 2: Query Simple - Detectar eval() (5 min)

### Problema

`eval()` es peligroso en Python. Queremos detectar todos los usos.

### Query Custom

Crea: `.github/codeql/queries/python/dangerous-eval.ql`

```ql
/**
 * @name Use of dangerous eval() function
 * @description Using eval() can lead to arbitrary code execution
 * @kind problem
 * @problem.severity error
 * @precision high
 * @id banking/dangerous-eval
 * @tags security
 *       external/cwe/cwe-95
 */

import python

from Call call
where 
  // Buscar llamadas a eval()
  call.getFunc().(Name).getId() = "eval"
select call, "Dangerous use of eval() function. Consider using ast.literal_eval() or safer alternatives."
```

### Explicación

```ql
from Call call          // Para cada llamada a función
where                   // Donde
  call.getFunc()        //   la función llamada
    .(Name)             //   es un nombre (no método)
    .getId() = "eval"   //   y ese nombre es "eval"
select call, "mensaje"  // Reportar con mensaje
```

### Probar localmente

```bash
# Instalar CodeQL CLI
npm install -g @github/codeql

# Crear database
codeql database create python-db --language=python

# Ejecutar query
codeql query run .github/codeql/queries/python/dangerous-eval.ql \
  --database=python-db \
  --output=results.sarif
```

---

## 🛡️ Paso 3: Query Avanzada - Pickle Inseguro (7 min)

### Problema Específico de ML

En ML es común usar `pickle.load()`, pero sin validar el origen es peligroso.

### Query Custom

`.github/codeql/queries/python/insecure-pickle-load.ql`

```ql
/**
 * @name Insecure pickle deserialization
 * @description Loading pickle files without validation can lead to arbitrary code execution
 * @kind path-problem
 * @problem.severity error
 * @precision high
 * @id banking-ml/insecure-pickle
 * @tags security
 *       external/cwe/cwe-502
 *       ml-security
 */

import python
import semmle.python.dataflow.new.DataFlow
import semmle.python.dataflow.new.TaintTracking
import semmle.python.ApiGraphs

/**
 * Taint tracking configuration para pickle.load
 */
class PickleLoadConfig extends TaintTracking::Configuration {
  PickleLoadConfig() { this = "PickleLoadConfig" }

  override predicate isSource(DataFlow::Node source) {
    // Fuente: cualquier llamada a open()
    exists(CallNode openCall |
      openCall = API::moduleImport("builtins").getMember("open").getACall() and
      source = openCall
    )
  }

  override predicate isSink(DataFlow::Node sink) {
    // Sink: argumento de pickle.load() o pickle.loads()
    exists(CallNode pickleCall |
      pickleCall = API::moduleImport("pickle").getMember(["load", "loads"]).getACall() and
      sink = pickleCall.getArg(0)
    )
  }
  
  override predicate isSanitizer(DataFlow::Node node) {
    // Si hay validación de hash, considerar sanitizado
    exists(CallNode hashCall |
      hashCall.getFunction().(Name).getId() in ["hashlib", "sha256", "md5"] and
      node = hashCall.getArg(0)
    )
  }
}

from PickleLoadConfig config, DataFlow::PathNode source, DataFlow::PathNode sink
where config.hasFlowPath(source, sink)
select sink.getNode(), source, sink,
  "Insecure pickle deserialization from $@. Validate file integrity before loading.",
  source.getNode(), "file open"
```

### Explicación Avanzada

```ql
// 1. Definir configuración de taint tracking
class PickleLoadConfig extends TaintTracking::Configuration

// 2. Definir SOURCE (origen de datos)
isSource() {
  // Datos vienen de open()
}

// 3. Definir SINK (uso peligroso)
isSink() {
  // Datos van a pickle.load()
}

// 4. Definir SANITIZER (validación)
isSanitizer() {
  // Si se validó con hash, es seguro
}

// 5. Encontrar FLUJO de source → sink
hasFlowPath(source, sink)
```

### Ejemplo que detectará

```python
# ❌ Detectado por la query
def load_model_unsafe(path):
    with open(path, 'rb') as f:  # ← SOURCE
        model = pickle.load(f)   # ← SINK
    return model

# ✅ No detectado (sanitizado)
def load_model_safe(path, expected_hash):
    with open(path, 'rb') as f:
        data = f.read()
        actual_hash = hashlib.sha256(data).hexdigest()  # ← SANITIZER
        
        if actual_hash != expected_hash:
            raise ValueError("Hash mismatch")
        
        model = pickle.loads(data)  # OK, validado
    return model
```

---

## 📊 Paso 4: Query Banking - PII en Logs (5 min)

### Problema Específico de Banking

No debemos loggear PII (emails, DNI, números de cuenta).

### Query Custom

`.github/codeql/queries/python/pii-in-logs.ql`

```ql
/**
 * @name PII in log statements
 * @description Logging Personally Identifiable Information violates privacy regulations
 * @kind problem
 * @problem.severity warning
 * @precision medium
 * @id banking/pii-in-logs
 * @tags security
 *       privacy
 *       gdpr
 *       compliance
 */

import python

/**
 * Predicado: es una llamada a logging?
 */
predicate isLoggingCall(Call call) {
  exists(Attribute attr |
    attr = call.getFunc() and
    attr.getObject().(Name).getId() = "logger" and
    attr.getName() in ["info", "debug", "warning", "error"]
  )
  or
  exists(Name func |
    func = call.getFunc() and
    func.getId() in ["print", "log"]
  )
}

/**
 * Predicado: contiene PII?
 */
predicate containsPII(Expr expr) {
  exists(Attribute attr |
    attr = expr and
    attr.getName() in [
      "email", "dni", "ssn", "account_number",
      "card_number", "cvv", "password", "token",
      "phone", "address", "ip_address"
    ]
  )
  or
  exists(Subscript sub |
    sub = expr and
    sub.getIndex().(StrConst).getText() in [
      "email", "dni", "ssn", "account_number",
      "card_number", "cvv", "password"
    ]
  )
}

from Call call, Expr arg
where
  isLoggingCall(call) and
  arg = call.getAnArg() and
  containsPII(arg)
select call, 
  "Potential PII exposure in log statement: $@",
  arg, arg.toString()
```

### Ejemplos detectados

```python
# ❌ Detectado
logger.info(f"Processing user: {user.email}")
logger.debug(f"Card: {payment.card_number}")
print(f"Account: {customer['account_number']}")

# ✅ No detectado
logger.info(f"Processing user: {user.id}")  # ID no es PII
logger.debug(f"Card: ****{card[-4:]}")      # Enmascarado
```

---

## 🔄 Paso 5: Integrar en Workflow (3 min)

### Actualizar workflow de CodeQL

`.github/workflows/codeql-analysis.yml`

```yaml
name: CodeQL Analysis

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  analyze:
    name: Analyze
    runs-on: ubuntu-latest

    strategy:
      matrix:
        language: [python]

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Initialize CodeQL
        uses: github/codeql-action/init@v3
        with:
          languages: ${{ matrix.language }}
          
          # ✅ Agregar queries custom
          queries: |
            security-extended
            .github/codeql/queries
          
          # Configuración custom
          config-file: .github/codeql/codeql-config.yml

      - name: Autobuild
        uses: github/codeql-action/autobuild@v3

      - name: Perform CodeQL Analysis
        uses: github/codeql-action/analyze@v3
        with:
          category: "/language:${{ matrix.language }}"
```

### Crear configuración

`.github/codeql/codeql-config.yml`

```yaml
name: "Custom CodeQL Config"

queries:
  - uses: security-extended
  - uses: ./.github/codeql/queries/python
  
# Excluir archivos de test
paths-ignore:
  - tests/**
  - '**/*_test.py'
  - '**/test_*.py'

# Incluir solo código de producción
paths:
  - src/**
  - app/**
  - api/**
```

---

## 📚 Biblioteca de Queries Custom

### Query: Detectar hardcoded IPs

```ql
/**
 * @name Hardcoded IP addresses
 * @description IP addresses should be in configuration, not hardcoded
 */

import python

from StrConst str
where
  str.getText().regexpMatch("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")
select str, "Hardcoded IP address found"
```

### Query: Weak random for security

```ql
/**
 * @name Use of weak random for security
 * @description random.random() is not cryptographically secure
 */

import python

from Call call
where
  call.getFunc().(Attribute).getName() in ["random", "randint", "choice"] and
  call.getFunc().(Attribute).getObject().(Name).getId() = "random"
select call, 
  "Weak random used. For security, use secrets module instead."
```

### Query: Missing rate limiting

```ql
/**
 * @name API endpoint without rate limiting
 * @description Public APIs should have rate limiting
 */

import python

from FunctionDef func
where
  // Es un endpoint de Flask
  exists(Decorator dec |
    dec = func.getADecorator() and
    dec.getName() = "route"
  ) and
  // No tiene decorador de rate limit
  not exists(Decorator rl |
    rl = func.getADecorator() and
    rl.getName() in ["limiter", "rate_limit", "throttle"]
  )
select func, 
  "API endpoint without rate limiting. Consider adding @limiter.limit() decorator."
```

---

## ✅ Ejercicio Final: Tu Propia Query

### Desafío

Crea una query que detecte:

**"Modelos ML sin versioning"**

Debe detectar:
```python
# ❌ Malo
pickle.dump(model, open('model.pkl', 'wb'))

# ✅ Bueno
version = "v1.2.3"
metadata = {'version': version, 'timestamp': datetime.now()}
pickle.dump({'model': model, 'metadata': metadata}, open(f'model_{version}.pkl', 'wb'))
```

### Template

```ql
/**
 * @name ML model without versioning
 * @description Models should include version metadata
 * @kind problem
 * @problem.severity warning
 * @precision medium
 * @id banking-ml/unversioned-model
 * @tags ml-ops
 *       maintainability
 */

import python

// TU CÓDIGO AQUÍ
from Call dumpCall
where
  // 1. Es llamada a pickle.dump()
  // 2. No hay metadata de versión
  // 3. No hay timestamp
select dumpCall, "Model saved without version metadata"
```

<details>
<summary>💡 Ver solución</summary>

```ql
import python

from Call dumpCall, Expr modelArg
where
  // Es pickle.dump()
  dumpCall.getFunc().(Attribute).getName() = "dump" and
  dumpCall.getFunc().(Attribute).getObject().(Name).getId() = "pickle" and
  
  // Primer argumento es el modelo
  modelArg = dumpCall.getArg(0) and
  
  // No es un dict con 'metadata' o 'version'
  not exists(DictExpr dict |
    dict = modelArg and
    (dict.getAKey().(StrConst).getText() in ["metadata", "version", "timestamp"])
  )
  
select dumpCall, "Model saved without version metadata. Include version, timestamp, and training info."
```
</details>

---

## 🧪 Paso 6: Testing de Queries (bonus)

### Crear tests para queries

`.github/codeql/queries/test/insecure-pickle-load.qltest`

```python
# Test cases para insecure-pickle-load.ql

import pickle

def test_vulnerable():
    # query-problem: Debería detectar esto
    with open('model.pkl', 'rb') as f:
        model = pickle.load(f)

def test_safe():
    import hashlib
    
    # query-ok: No debería detectar (hay validación)
    with open('model.pkl', 'rb') as f:
        data = f.read()
        hash_val = hashlib.sha256(data).hexdigest()
        
        if hash_val == expected:
            model = pickle.loads(data)
```

### Ejecutar tests

```bash
codeql test run .github/codeql/queries/test/
```

---

## ✅ Checklist de Validación

- [ ] Entiendo la estructura de una query CodeQL
- [ ] Creé al menos 1 query custom
- [ ] Integré queries en el workflow
- [ ] Probé la query con ejemplos vulnerable y seguro
- [ ] Documenté la query con metadata completo

---

## ❓ Preguntas Frecuentes

**P1: ¿Dónde aprendo más sobre QL?**
R: 
- [CodeQL Docs](https://codeql.github.com/docs/)
- [QL Language Reference](https://codeql.github.com/docs/ql-language-reference/)
- [CodeQL for Python](https://codeql.github.com/docs/codeql-language-guides/codeql-for-python/)

**P2: ¿Cómo debug una query?**
R: Usa `codeql query run` localmente con `--debug`

**P3: ¿Puedo compartir queries con otros equipos?**
R: Sí, opciones:
1. Publicar en GitHub como package
2. Incluir en repositorio compartido
3. Contribuir a CodeQL standard library

**P4: ¿Cuánto tiempo toma escribir una query?**
R:
- Simple: 30 min - 1 hora
- Media: 2-4 horas
- Compleja (taint tracking): 1-2 días

---

## 💡 Best Practices

### 1. Empezar Simple

```
Iteration 1: Detectar eval()
   ↓
Iteration 2: Detectar eval() con tainted input
   ↓
Iteration 3: Agregar sanitizers
   ↓
Iteration 4: Reducir false positives
```

### 2. Precision vs Recall

```
High Precision (precision: high):
- Pocos false positives
- Puede perder algunos casos
- Usar para blocking checks

High Recall (precision: medium):
- Detecta más casos
- Más false positives
- Usar para auditoría/learning
```

### 3. Documentar Bien

```ql
/**
 * METADATA COMPLETO
 * 
 * @name - Descriptivo pero conciso
 * @description - Explicar QUÉ detecta y POR QUÉ es malo
 * @tags - Facilita búsqueda y categorización
 * @precision - Sea honesto: high/medium/low
 * 
 * EJEMPLOS en comentarios:
 * 
 * Vulnerable:
 *   eval(user_input)
 * 
 * Safe:
 *   ast.literal_eval(user_input)
 */
```

---

## 📚 Recursos Adicionales

- [CodeQL Query Console](https://lgtm.com/query) - Probar queries online
- [CodeQL CTF](https://github.com/github/securitylab) - Challenges
- [Query Examples](https://github.com/github/codeql/tree/main/python/ql/src/Security)
- [Standard Library](https://codeql.github.com/codeql-standard-libraries/python/)

---

**¡Felicidades! Completaste Lab 6 y todo el Taller 7** 🎉🎊

Has dominado:
- ✅ CodeQL básico y avanzado
- ✅ Dependabot y gestión de dependencias
- ✅ Security policies y branch protection
- ✅ Security dashboards y métricas
- ✅ Remediación con Copilot Autofix
- ✅ Custom queries para tu dominio

🚀 **Próximos pasos:**
1. Aplicar en tu proyecto real
2. Compartir conocimiento con el equipo
3. Contribuir queries a la comunidad
4. ¡Seguir aprendiendo!

---

**Mi Banco | Taller 7 - GitHub Advanced Security**
