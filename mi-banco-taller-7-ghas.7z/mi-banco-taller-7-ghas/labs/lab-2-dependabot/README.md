# Lab 2: Dependabot - Gestión Automática de Dependencias

**Duración:** 15 minutos | **Nivel:** ⭐ | **Objetivo:** Configurar y usar Dependabot para mantener dependencias seguras

---

## 🎯 Objetivo del Lab

En este lab aprenderás a:
- ✅ Configurar Dependabot para Python/JavaScript
- ✅ Revisar y aprobar PRs de Dependabot
- ✅ Agrupar updates relacionados
- ✅ Auto-merge de security patches
- ✅ Gestionar breaking changes

---

## 📋 Requisitos Previos

- Repositorio con GHAS habilitado
- Archivos `requirements.txt` o `package.json`
- Permisos de admin en el repositorio

---

## 🚀 Paso 1: Habilitar Dependabot (3 min)

### Opción A: Desde GitHub UI

1. Ve a **Settings** → **Code security & analysis**
2. Habilita **Dependabot alerts**
3. Habilita **Dependabot security updates**
4. Habilita **Dependabot version updates**

### Opción B: Con configuración manual

Crea `.github/dependabot.yml`:

```yaml
version: 2
updates:
  # Python dependencies
  - package-ecosystem: "pip"
    directory: "/"
    schedule:
      interval: "weekly"
      day: "monday"
    open-pull-requests-limit: 5
    reviewers:
      - "mi-banco-team"
    labels:
      - "dependencies"
      - "python"
    
  # JavaScript dependencies  
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"
    groups:
      # Agrupar updates relacionados
      dev-dependencies:
        dependency-type: "development"
      production-dependencies:
        dependency-type: "production"
```

---

## 🔍 Paso 2: Entender Vulnerabilidades (4 min)

### Ejemplo de Alerta

```
🚨 CRITICAL: SQL Injection in sqlparse
Package: sqlparse
Affected versions: < 0.4.4
Fixed in: 0.4.4
CVE: CVE-2023-30608

Description:
sqlparse contains a regular expression that is vulnerable 
to Regular Expression Denial of Service (ReDoS)
```

### Tipos de Alertas

| Severity | Color | Acción | Tiempo |
|----------|-------|--------|--------|
| 🔴 CRITICAL | Rojo | Actualizar HOY | < 24h |
| 🟠 HIGH | Naranja | Esta semana | < 7 días |
| 🟡 MEDIUM | Amarillo | Este mes | < 30 días |
| 🔵 LOW | Azul | Próximo sprint | Flexible |

---

## ✅ Paso 3: Revisar PR de Dependabot (4 min)

### ¿Qué revisar?

Cuando Dependabot crea un PR, verifica:

#### 1. **Changelog**
```markdown
# What changed?
- pandas 1.5.0 → 2.0.1
- Breaking changes: DataFrame.append() removed
- New features: PyArrow support
```

#### 2. **Tests**
```bash
✅ All checks passed
   - Unit tests: 150/150
   - Integration tests: 45/45
   - Security scan: No new issues
```

#### 3. **Compatibility Score**
```
🟢 95% Compatibility
   - 1,234 repos use this update
   - 23 issues reported
   - 98% success rate
```

### Ejemplo: Revisar PR de numpy

```python
# Antes: numpy 1.21.0
import numpy as np
arr = np.array([1, 2, 3])

# Después: numpy 1.24.0
# ¿Cambió algo?
# Ver CHANGELOG:
# - Deprecated aliases removed
# - Performance improvements
# - No breaking changes en API común
```

**Decisión:** ✅ Safe to merge

---

## 🔄 Paso 4: Agrupar Updates (2 min)

### Problema: Muchos PRs

```
❌ Sin agrupar:
PR #1: Update pytest 7.0.0 → 7.0.1
PR #2: Update pytest-cov 3.0.0 → 3.0.1
PR #3: Update pytest-mock 3.6.0 → 3.6.1
→ 3 PRs separados 😓
```

### Solución: Grupos

```yaml
groups:
  testing:
    patterns:
      - "pytest*"
      - "coverage"
    update-types:
      - "minor"
      - "patch"
```

```
✅ Con grupos:
PR #1: Update testing dependencies
  - pytest 7.0.0 → 7.0.1
  - pytest-cov 3.0.0 → 3.0.1
  - pytest-mock 3.6.0 → 3.6.1
→ 1 PR consolidado 🎉
```

---

## ⚡ Paso 5: Auto-merge de Security Patches (2 min)

### Configurar Auto-merge

Crea `.github/workflows/dependabot-auto-merge.yml`:

```yaml
name: Dependabot Auto-Merge
on: pull_request

jobs:
  auto-merge:
    runs-on: ubuntu-latest
    if: github.actor == 'dependabot[bot]'
    
    steps:
      - name: Check if security update
        id: check
        run: |
          TITLE="${{ github.event.pull_request.title }}"
          if [[ $TITLE == *"security"* ]] || [[ $TITLE == *"CVE"* ]]; then
            echo "is_security=true" >> $GITHUB_OUTPUT
          fi
      
      - name: Enable auto-merge for security
        if: steps.check.outputs.is_security == 'true'
        run: |
          gh pr merge --auto --squash "$PR_URL"
        env:
          PR_URL: ${{ github.event.pull_request.html_url }}
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Approve PR
        run: gh pr review --approve "$PR_URL"
        env:
          PR_URL: ${{ github.event.pull_request.html_url }}
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

### Reglas de Auto-merge

```
✅ Auto-merge SI:
   - Security patch (CVE fix)
   - Patch version (1.2.3 → 1.2.4)
   - Tests pasan
   - Compatibilidad > 95%

❌ NO auto-merge SI:
   - Major version (1.x → 2.x)
   - Breaking changes
   - Tests fallan
   - Múltiples vulnerabilidades
```

---

## 🎓 Ejercicio Práctico

### Escenario: Update de scikit-learn

Dependabot crea PR:
```
Update scikit-learn from 1.0.2 to 1.3.0

Changes:
- RandomForestClassifier: n_estimators default changed 100 → 50
- train_test_split: shuffle default changed True → False
- Deprecated: sklearn.externals removed
```

**Pregunta 1:** ¿Es breaking change?
<details>
<summary>Ver respuesta</summary>
✅ SÍ - Los defaults cambiaron, puede afectar reproducibilidad
</details>

**Pregunta 2:** ¿Qué hacer?
<details>
<summary>Ver respuesta</summary>

1. No auto-merge
2. Revisar código que usa sklearn
3. Actualizar código:
   ```python
   # Explicitar defaults
   RandomForestClassifier(n_estimators=100)
   train_test_split(shuffle=True)
   ```
4. Ejecutar tests completos
5. Validar reproducibilidad
6. Merge manual
</details>

---

## 📊 Paso 6: Monitoring (bonus)

### Dashboard de Dependencias

Ve a: **Insights** → **Dependency graph**

Verás:
- 📦 Total dependencies: 45
- 🚨 Vulnerabilities: 3 (2 high, 1 medium)
- 📈 Updates available: 12
- ⏰ Last scanned: 2 hours ago

### Alertas por Email

Configurar en: **Settings** → **Notifications**
```
☑️ Email me when:
   - New vulnerability found
   - Security update available
   - Dependabot PR created
```

---

## ✅ Checklist de Validación

- [ ] Dependabot habilitado en mi repo
- [ ] Creé archivo `dependabot.yml`
- [ ] Configuré grupos de dependencias
- [ ] Entiendo cómo revisar PRs
- [ ] Configuré auto-merge para security patches
- [ ] Sé cuándo NO hacer auto-merge

---

## ❓ Preguntas Frecuentes

**P1: ¿Dependabot crea PRs automáticamente?**
R: Sí, según el schedule configurado (daily/weekly/monthly)

**P2: ¿Puedo ignorar ciertas dependencias?**
R: Sí, usa `ignore` en dependabot.yml:
```yaml
ignore:
  - dependency-name: "numpy"
    update-types: ["version-update:semver-major"]
```

**P3: ¿Qué pasa si tests fallan?**
R: Dependabot marca el PR como failing. No hacer merge hasta corregir.

**P4: ¿Cómo gestiono breaking changes en ML?**
R: 
1. Leer changelog completo
2. Validar reproducibilidad del modelo
3. Comparar predicciones antes/después
4. Usar script `validate-ml-dependencies.py`

---

## 🛠️ Para Data Scientists

### Validar Updates de ML Libraries

Usa el script del taller:

```powershell
# Guardar requirements actual
cp requirements.txt requirements.txt.old

# Después del update de Dependabot
python scripts/validate-ml-dependencies.py `
  --old requirements.txt.old `
  --new requirements.txt `
  --model examples/python/credit_model.pkl `
  --test-data examples/python/test_data.csv
```

Esto verifica:
- ✅ Compatibilidad entre librerías
- ✅ Reproducibilidad del modelo
- ✅ Performance no degrada
- ✅ APIs no deprecated

---

## 💡 Best Practices

### 1. Review Schedule
```yaml
# Producción: weekly
# Dev/test: daily
schedule:
  interval: "weekly"
  day: "monday"
  time: "09:00"  # Hora local del repo
```

### 2. Límites de PRs
```yaml
# No saturar el equipo
open-pull-requests-limit: 5
```

### 3. Assignees y Reviewers
```yaml
assignees:
  - "tech-lead"
reviewers:
  - "senior-dev"
  - "security-team"
```

### 4. Labels Descriptivos
```yaml
labels:
  - "dependencies"
  - "automated"
  - "security"  # Si es security update
```

---

## 📚 Recursos Adicionales

- [Dependabot Docs](https://docs.github.com/en/code-security/dependabot)
- [dependabot.yml Reference](https://docs.github.com/en/code-security/dependabot/dependabot-version-updates/configuration-options-for-the-dependabot.yml-file)
- [Advisory Database](https://github.com/advisories)

---

**¡Felicidades! Completaste Lab 2** 🎉

¿Listo para Lab 3? → `cd ../lab-3-policies && cat README.md`
