#!/usr/bin/env python3
"""
Código vulnerable para demostración en TALLER 7 - Lab 1
Propósito: Mostrar qué CodeQL puede detectar
"""

import sqlite3
import subprocess
import pickle
from cryptography.fernet import Fernet
import hashlib

# ============================================================
# VULNERABILIDAD 1: SQL Injection
# ============================================================

def get_user_by_email(email):
    """❌ VULNERABLE: SQL Injection"""
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Construcción insegura de query
    query = f"SELECT * FROM users WHERE email = '{email}'"
    cursor.execute(query)
    return cursor.fetchall()

# Ejemplo de ataque:
# email = "' OR '1'='1"
# Resultado: SELECT * FROM users WHERE email = '' OR '1'='1'


# ============================================================
# VULNERABILIDAD 2: Command Injection
# ============================================================

def process_file(filename):
    """❌ VULNERABLE: Command Injection"""
    # Usuario puede inyectar comandos
    cmd = f"cat {filename}"
    result = subprocess.run(cmd, shell=True, capture_output=True)
    return result.stdout.decode()

# Ejemplo de ataque:
# filename = "test.txt; rm -rf /"
# Resultado: ¡Se ejecuta comando malicioso!


# ============================================================
# VULNERABILIDAD 3: Deserialization
# ============================================================

def deserialize_user(data):
    """❌ VULNERABLE: Insecure Deserialization"""
    # pickle.loads() puede ejecutar código arbitrario
    return pickle.loads(data)

# El atacante puede serializar un objeto que ejecute código


# ============================================================
# VULNERABILIDAD 4: Weak Cryptography
# ============================================================

def hash_password(password):
    """❌ VULNERABLE: Weak Hashing"""
    # SHA-1 es débil, no es para passwords
    return hashlib.sha1(password.encode()).hexdigest()

def hash_password_md5(password):
    """❌ VULNERABLE: MD5 es aún peor"""
    return hashlib.md5(password.encode()).hexdigest()


# ============================================================
# VULNERABILIDAD 5: Hardcoded Secrets
# ============================================================

API_KEY = "sk_test_4eC39HqLyjWDarhtT657tZ06"
DATABASE_PASSWORD = "admin123"
FERNET_KEY = "2lflwN0yNwEF_TNS_ysBvv2ilnz84XoQy4JAxGP8mV4="


# ============================================================
# VULNERABILIDAD 6: Dangerous Imports
# ============================================================

import os
import sys

def run_command(cmd):
    """❌ VULNERABLE: Using os.system()"""
    os.system(cmd)


# ============================================================
# VULNERABILIDAD 7: Path Traversal
# ============================================================

def read_file_from_user_path(user_input):
    """❌ VULNERABLE: Path Traversal"""
    filepath = f"/var/www/documents/{user_input}"
    with open(filepath, 'r') as f:
        return f.read()

# Ejemplo de ataque:
# user_input = "../../etc/passwd"
# Resultado: Lee /etc/passwd (información sensible)


# ============================================================
# VULNERABILIDAD 8: Unsafe Logging
# ============================================================

import logging

logger = logging.getLogger(__name__)

def login_user(username, password):
    """❌ VULNERABLE: Logging sensitive data"""
    logger.info(f"User {username} login with password: {password}")
    # Se registra la contraseña en logs


if __name__ == "__main__":
    # Demostraciones (NO ejecutar en producción)
    print("Archivo vulnerable para análisis con CodeQL")
    print("Ver: labs/lab-1-codeql/README.md para soluciones")
