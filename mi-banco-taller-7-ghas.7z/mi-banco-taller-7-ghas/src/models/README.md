# Models Storage

Esta carpeta está destinada para almacenar modelos de Machine Learning entrenados.

## 📦 Qué almacenar aquí

### Modelos Entrenados
- `*.pkl` - Modelos serializados con pickle
- `*.joblib` - Modelos serializados con joblib (preferido)
- `*.h5` - Modelos de Keras/TensorFlow
- `*.pt` / `*.pth` - Modelos de PyTorch
- `*.onnx` - Modelos en formato ONNX (interoperabilidad)

### Metadata
- `model_metadata.json` - Información de versión y configuración
- `training_config.yaml` - Configuración de entrenamiento
- `feature_names.json` - Nombres de features del modelo

## ⚠️ Seguridad: NO almacenar modelos grandes en Git

### Problema
Los modelos ML pueden ser muy grandes (MB a GB) y **no deben** estar en el repositorio Git.

### Solución 1: Git LFS (Large File Storage)

```bash
# Instalar Git LFS
git lfs install

# Trackear archivos de modelos
git lfs track "*.pkl"
git lfs track "*.joblib"
git lfs track "*.h5"

# Commit del .gitattributes
git add .gitattributes
git commit -m "Add Git LFS tracking for ML models"
```

### Solución 2: .gitignore (Recomendado para este taller)

Los modelos grandes deben estar en `.gitignore` y almacenarse externamente:

```gitignore
# En .gitignore
src/models/*.pkl
src/models/*.joblib
src/models/*.h5
src/models/*.pt
src/models/*.pth

# Permitir solo archivos pequeños
!src/models/*.json
!src/models/*.yaml
!src/models/README.md
```

### Solución 3: Almacenamiento Externo

**Opciones recomendadas:**
- **Azure Blob Storage** - Para producción en MI Banco
- **MLflow Model Registry** - Para tracking y versionado
- **DVC (Data Version Control)** - Para versionado de datos/modelos
- **GitHub Releases** - Para modelos específicos de releases

## 🏗️ Estructura Recomendada

```
src/models/
├── README.md                    # Este archivo
├── .gitkeep                     # Mantener carpeta en Git
├── production/                  # Modelos en producción
│   ├── credit_model_v1.0.0.joblib
│   └── credit_model_v1.0.0.json
├── staging/                     # Modelos en staging
│   ├── credit_model_v1.1.0.joblib
│   └── credit_model_v1.1.0.json
├── experiments/                 # Modelos experimentales
│   └── credit_model_exp_*.joblib
└── archived/                    # Modelos antiguos
    └── credit_model_v0.*.joblib
```

## 📋 Ejemplo: Model Metadata

```json
{
  "model_name": "credit_scoring_model",
  "version": "1.0.0",
  "created_at": "2024-01-15T10:30:00Z",
  "framework": "scikit-learn",
  "framework_version": "1.3.0",
  "model_type": "RandomForestClassifier",
  "features": [
    "age",
    "income",
    "credit_history_length",
    "num_open_accounts",
    "debt_to_income_ratio"
  ],
  "target": "credit_approved",
  "performance": {
    "accuracy": 0.87,
    "precision": 0.85,
    "recall": 0.82,
    "f1_score": 0.83,
    "auc_roc": 0.91
  },
  "fairness_metrics": {
    "disparate_impact": 0.92,
    "equal_opportunity_difference": 0.08
  },
  "training_data": {
    "dataset": "credit_applications_2023",
    "size": 50000,
    "date_range": "2023-01-01 to 2023-12-31"
  },
  "hyperparameters": {
    "n_estimators": 100,
    "max_depth": 10,
    "min_samples_split": 5,
    "random_state": 42
  },
  "dependencies": {
    "python": "3.9.0",
    "scikit-learn": "1.3.0",
    "pandas": "2.0.0",
    "numpy": "1.24.0"
  }
}
```

## 🔒 Seguridad con Pickle

**⚠️ IMPORTANTE:** Los archivos `.pkl` pueden contener código malicioso.

### Mejores Prácticas

1. **Nunca** deserializar pickles de fuentes no confiables
2. Usar `joblib` en lugar de `pickle` cuando sea posible
3. Validar checksums antes de cargar modelos
4. Implementar sandboxing en producción

### Código Seguro

```python
import joblib
import hashlib
import json

def load_model_securely(model_path, metadata_path):
    """Cargar modelo con validación de integridad"""
    
    # 1. Cargar metadata
    with open(metadata_path, 'r') as f:
        metadata = json.load(f)
    
    # 2. Verificar checksum
    with open(model_path, 'rb') as f:
        model_bytes = f.read()
        actual_checksum = hashlib.sha256(model_bytes).hexdigest()
    
    expected_checksum = metadata.get('checksum')
    if actual_checksum != expected_checksum:
        raise ValueError("Model checksum mismatch! Possible tampering.")
    
    # 3. Cargar modelo
    model = joblib.load(model_path)
    
    return model, metadata

# Uso
model, metadata = load_model_securely(
    'src/models/production/credit_model_v1.0.0.joblib',
    'src/models/production/credit_model_v1.0.0.json'
)
```

## 🔄 Versionado de Modelos

### Semantic Versioning para ML

```
v<MAJOR>.<MINOR>.<PATCH>

MAJOR: Cambio de arquitectura, features incompatibles
MINOR: Nuevo entrenamiento, mejora de performance
PATCH: Bugfix, ajuste de hiperparámetros
```

**Ejemplos:**
- `v1.0.0` - Modelo inicial en producción
- `v1.1.0` - Reentrenamiento con datos nuevos
- `v1.1.1` - Fix en preprocesamiento
- `v2.0.0` - Nueva arquitectura (RandomForest → XGBoost)

## 📊 MLflow Integration (Opcional)

```python
import mlflow
import mlflow.sklearn

# Configurar tracking
mlflow.set_tracking_uri("https://mlflow.mibanco.com")
mlflow.set_experiment("credit-scoring")

# Loguear modelo
with mlflow.start_run():
    mlflow.sklearn.log_model(model, "model")
    mlflow.log_params(hyperparameters)
    mlflow.log_metrics(performance_metrics)
    mlflow.log_artifact("src/models/credit_model_metadata.json")
```

## 🚀 Deployment

### Cargar modelo en API

```python
from flask import Flask
import joblib

app = Flask(__name__)

# Cargar modelo al iniciar
MODEL = joblib.load('src/models/production/credit_model_v1.0.0.joblib')

@app.route('/predict', methods=['POST'])
def predict():
    # Usar MODEL para predicciones
    pass
```

---

**Nota:** Esta carpeta está lista para recibir modelos. Recuerda **NO** subir modelos grandes directamente a Git. Usa Git LFS, Azure Blob Storage, o MLflow Registry.
