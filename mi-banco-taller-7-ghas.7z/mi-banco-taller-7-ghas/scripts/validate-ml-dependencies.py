#!/usr/bin/env python3
"""
Validate ML Dependencies - Validación de Compatibilidad de Dependencias
========================================================================

Script para validar que updates de dependencias no rompan modelos ML.
Verifica compatibilidad, reproducibilidad y performance.

Autor: Mi Banco - Data Science Team
Taller: GitHub Advanced Security para Data Science
Versión: 1.0.0

Uso:
    python validate-ml-dependencies.py --old requirements.txt.old \
        --new requirements.txt --model model.pkl --test-data test.csv

Validaciones:
    - Version compatibility entre librerías
    - Model reproducibility (predicciones idénticas)
    - Performance benchmarks (tiempo, memoria)
    - API compatibility (funciones deprecated)
"""

import argparse
import pickle
import sys
import time
import tracemalloc
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import pkg_resources


class DependencyValidator:
    """Validador de compatibilidad de dependencias ML."""
    
    # Thresholds de tolerancia
    PREDICTION_TOLERANCE = 0.001
    TIME_INCREASE_THRESHOLD = 0.10  # 10%
    MEMORY_INCREASE_THRESHOLD = 0.15  # 15%
    
    def __init__(self, old_reqs: str, new_reqs: str, model_path: Optional[str] = None, test_data: Optional[str] = None):
        """
        Inicializa el validador.
        
        Args:
            old_reqs: Ruta a requirements.txt anterior
            new_reqs: Ruta a requirements.txt nuevo
            model_path: Ruta a modelo pickle para validar reproducibilidad
            test_data: Ruta a datos de test
        """
        self.old_reqs = Path(old_reqs)
        self.new_reqs = Path(new_reqs)
        self.model_path: Optional[Path] = Path(model_path) if model_path else None
        self.test_data: Optional[Path] = Path(test_data) if test_data else None
        
        self.old_deps: Dict[str, str] = {}
        self.new_deps: Dict[str, str] = {}
        self.issues: List[str] = []
        
    def parse_requirements(self, req_file: Path) -> Dict[str, str]:
        """
        Parsea archivo requirements.txt.
        
        Args:
            req_file: Ruta al archivo requirements.txt
            
        Returns:
            Dict con {package: version}
        """
        deps = {}
        
        try:
            with open(req_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Parsear linea: package==version
                        if '==' in line:
                            pkg, version = line.split('==', 1)
                            deps[pkg.strip()] = version.strip()
                        elif '>=' in line or '<=' in line or '>' in line or '<' in line:
                            # Constraints con operadores
                            for op in ['>=', '<=', '>', '<']:
                                if op in line:
                                    pkg = line.split(op)[0].strip()
                                    deps[pkg] = line  # Guardar constraint completo
                                    break
                        else:
                            # Sin versión especificada
                            deps[line] = 'any'
        except Exception as e:
            print(f"❌ Error al parsear {req_file}: {e}")
            sys.exit(1)
        
        return deps
    
    def compare_versions(self) -> None:
        """Compara versiones entre old y new requirements."""
        print("\n📊 COMPARACIÓN DE VERSIONES")
        print("=" * 70)
        
        self.old_deps = self.parse_requirements(self.old_reqs)
        self.new_deps = self.parse_requirements(self.new_reqs)
        
        # Paquetes actualizados
        updated = []
        for pkg, old_ver in self.old_deps.items():
            if pkg in self.new_deps and self.new_deps[pkg] != old_ver:
                updated.append((pkg, old_ver, self.new_deps[pkg]))
        
        # Paquetes nuevos
        new_pkgs = [pkg for pkg in self.new_deps if pkg not in self.old_deps]
        
        # Paquetes removidos
        removed = [pkg for pkg in self.old_deps if pkg not in self.new_deps]
        
        # Mostrar cambios
        if updated:
            print("\n🔄 PAQUETES ACTUALIZADOS:")
            for pkg, old_ver, new_ver in updated:
                print(f"   {pkg}: {old_ver} → {new_ver}")
        
        if new_pkgs:
            print("\n➕ PAQUETES NUEVOS:")
            for pkg in new_pkgs:
                print(f"   {pkg}: {self.new_deps[pkg]}")
        
        if removed:
            print("\n➖ PAQUETES REMOVIDOS:")
            for pkg in removed:
                print(f"   {pkg}: {self.old_deps[pkg]}")
        
        # Guardar para validaciones posteriores
        self.updated_packages = updated
        self.new_packages = new_pkgs
        self.removed_packages = removed
    
    def check_compatibility(self) -> None:
        """Verifica compatibilidad entre paquetes críticos de ML."""
        print("\n🔍 VERIFICACIÓN DE COMPATIBILIDAD")
        print("=" * 70)
        
        # Reglas de compatibilidad conocidas
        compatibility_rules = {
            'numpy': {
                'pandas': self._check_numpy_pandas_compat,
                'scikit-learn': self._check_numpy_sklearn_compat,
            },
            'tensorflow': {
                'keras': self._check_tensorflow_keras_compat,
            }
        }
        
        for pkg1, rules in compatibility_rules.items():
            if pkg1 in self.new_deps:
                for pkg2, check_func in rules.items():
                    if pkg2 in self.new_deps:
                        is_compat = check_func(self.new_deps[pkg1], self.new_deps[pkg2])
                        if not is_compat:
                            issue = f"⚠️ Incompatibilidad detectada: {pkg1} {self.new_deps[pkg1]} <-> {pkg2} {self.new_deps[pkg2]}"
                            print(f"   {issue}")
                            self.issues.append(issue)
        
        if not self.issues:
            print("   ✅ No se detectaron incompatibilidades conocidas")
    
    def _check_numpy_pandas_compat(self, numpy_ver: str, pandas_ver: str) -> bool:
        """Verifica compatibilidad numpy-pandas."""
        # Simplificado: pandas >= 1.0 requiere numpy >= 1.17
        try:
            np_major = int(numpy_ver.split('.')[0]) if '.' in numpy_ver else 1
            pd_major = int(pandas_ver.split('.')[0]) if '.' in pandas_ver else 1
            
            if pd_major >= 1 and np_major < 1:
                return False
            return True
        except:
            return True  # No podemos verificar, asumir compatible
    
    def _check_numpy_sklearn_compat(self, numpy_ver: str, sklearn_ver: str) -> bool:
        """Verifica compatibilidad numpy-scikit-learn."""
        # Simplificado: sklearn >= 1.0 requiere numpy >= 1.17
        try:
            np_ver = numpy_ver.replace('==', '').strip()
            sk_ver = sklearn_ver.replace('==', '').strip()
            
            # Validación básica de versiones
            return True  # Por defecto, asumir compatible
        except:
            return True
    
    def _check_tensorflow_keras_compat(self, tf_ver: str, keras_ver: str) -> bool:
        """Verifica compatibilidad tensorflow-keras."""
        # TensorFlow >= 2.0 incluye Keras, no necesita keras separado
        try:
            tf_major = int(tf_ver.split('.')[0]) if '.' in tf_ver else 2
            if tf_major >= 2 and keras_ver not in ['any', 'integrated']:
                issue = "⚠️ TensorFlow 2.x incluye Keras, no instalar keras separado"
                if issue not in self.issues:
                    self.issues.append(issue)
                return False
            return True
        except:
            return True
    
    def validate_reproducibility(self) -> bool:
        """
        Valida que el modelo produzca predicciones idénticas.
        
        Returns:
            True si es reproducible, False si no
        """
        if not self.model_path or not self.test_data:
            print("\n⏭️ Saltando validación de reproducibilidad (no se proporcionó modelo o datos)")
            return True
        
        print("\n🔄 VALIDACIÓN DE REPRODUCIBILIDAD")
        print("=" * 70)
        
        try:
            # Cargar modelo
            with open(self.model_path, 'rb') as f:
                model = pickle.load(f)
            
            # Cargar datos
            data = pd.read_csv(self.test_data)
            
            # Separar features (asumir que última columna es target)
            X = data.iloc[:, :-1]
            
            # Predecir dos veces
            pred1 = model.predict(X)
            pred2 = model.predict(X)
            
            # Comparar
            max_diff = abs(pred1 - pred2).max()
            
            print(f"   Diferencia máxima entre predicciones: {max_diff:.10f}")
            print(f"   Threshold: {self.PREDICTION_TOLERANCE}")
            
            if max_diff > self.PREDICTION_TOLERANCE:
                issue = f"❌ REPRODUCIBILIDAD FALLIDA: diferencia {max_diff} > {self.PREDICTION_TOLERANCE}"
                print(f"   {issue}")
                self.issues.append(issue)
                return False
            else:
                print("   ✅ Reproducibilidad verificada")
                return True
                
        except Exception as e:
            print(f"   ⚠️ Error en validación de reproducibilidad: {e}")
            return True  # No fallar por error de validación
    
    def benchmark_performance(self) -> Dict:
        """
        Benchmarks de performance (tiempo y memoria).
        
        Returns:
            Dict con métricas de performance
        """
        if not self.model_path or not self.test_data:
            print("\n⏭️ Saltando benchmarks de performance")
            return {}
        
        print("\n⚡ BENCHMARKS DE PERFORMANCE")
        print("=" * 70)
        
        try:
            # Cargar modelo y datos
            with open(self.model_path, 'rb') as f:
                model = pickle.load(f)
            data = pd.read_csv(self.test_data)
            X = data.iloc[:, :-1]
            
            # Benchmark de tiempo
            start = time.time()
            for _ in range(10):  # 10 iteraciones
                _ = model.predict(X)
            end = time.time()
            avg_time = (end - start) / 10
            
            # Benchmark de memoria
            tracemalloc.start()
            _ = model.predict(X)
            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            
            metrics = {
                'avg_prediction_time': avg_time,
                'peak_memory_mb': peak / 1024 / 1024
            }
            
            print(f"   Tiempo promedio de predicción: {avg_time:.4f} segundos")
            print(f"   Memoria pico: {metrics['peak_memory_mb']:.2f} MB")
            
            return metrics
            
        except Exception as e:
            print(f"   ⚠️ Error en benchmarks: {e}")
            return {}
    
    def check_deprecated_apis(self) -> None:
        """Verifica uso de APIs deprecated."""
        print("\n🔍 VERIFICACIÓN DE APIs DEPRECATED")
        print("=" * 70)
        
        # Esta es una verificación simplificada
        # En producción, usaríamos AST parsing para analizar el código
        
        deprecated_warnings = []
        
        # Ejemplos de APIs deprecated conocidas
        if 'scikit-learn' in self.new_deps:
            sklearn_ver = self.new_deps['scikit-learn']
            if sklearn_ver.startswith('1.'):
                deprecated_warnings.append(
                    "⚠️ scikit-learn 1.x: sklearn.externals.joblib está deprecated, usar joblib directamente"
                )
        
        if deprecated_warnings:
            for warning in deprecated_warnings:
                print(f"   {warning}")
                self.issues.append(warning)
        else:
            print("   ✅ No se detectaron APIs deprecated conocidas")
    
    def generate_report(self) -> str:
        """
        Genera reporte de validación.
        
        Returns:
            String con el reporte
        """
        report = "\n" + "=" * 70 + "\n"
        report += "📋 REPORTE DE VALIDACIÓN DE DEPENDENCIAS\n"
        report += "=" * 70 + "\n\n"
        
        report += f"Old requirements: {self.old_reqs}\n"
        report += f"New requirements: {self.new_reqs}\n\n"
        
        if hasattr(self, 'updated_packages'):
            report += f"Paquetes actualizados: {len(self.updated_packages)}\n"
            report += f"Paquetes nuevos: {len(self.new_packages)}\n"
            report += f"Paquetes removidos: {len(self.removed_packages)}\n\n"
        
        if self.issues:
            report += f"⚠️ ISSUES DETECTADAS: {len(self.issues)}\n\n"
            for i, issue in enumerate(self.issues, 1):
                report += f"{i}. {issue}\n"
        else:
            report += "✅ NO SE DETECTARON ISSUES\n"
        
        report += "\n" + "=" * 70 + "\n"
        
        return report


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(
        description='Validar compatibilidad de dependencias ML',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  python validate-ml-dependencies.py --old requirements.txt.old --new requirements.txt
  python validate-ml-dependencies.py --old old.txt --new new.txt --model model.pkl --test-data test.csv
        """
    )
    
    parser.add_argument('--old', required=True, help='Requirements.txt anterior')
    parser.add_argument('--new', required=True, help='Requirements.txt nuevo')
    parser.add_argument('--model', help='Modelo pickle para validar reproducibilidad')
    parser.add_argument('--test-data', help='Datos de test (CSV)')
    
    args = parser.parse_args()
    
    # Inicializar validator
    validator = DependencyValidator(args.old, args.new, args.model, args.test_data)
    
    # Ejecutar validaciones
    validator.compare_versions()
    validator.check_compatibility()
    validator.validate_reproducibility()
    validator.benchmark_performance()
    validator.check_deprecated_apis()
    
    # Generar reporte
    report = validator.generate_report()
    print(report)
    
    # Exit code
    exit_code = 1 if validator.issues else 0
    print(f"{'❌' if exit_code else '✅'} Validación completada con código: {exit_code}")
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
