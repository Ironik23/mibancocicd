#!/usr/bin/env python3
"""
Detect Model Bias - Análisis de Fairness en Modelos ML
========================================================

Script para detectar y medir bias en modelos de Machine Learning.
Calcula métricas de fairness según regulaciones bancarias (SBS, GDPR).

Autor: Mi Banco - Data Science Team
Taller: GitHub Advanced Security para Data Science
Versión: 1.0.0

Uso:
    python detect-model-bias.py --model <model.pkl> --data <data.csv> \
        --protected-attrs gender,age --output report.html

Métricas calculadas:
    - Disparate Impact (DI)
    - Equal Opportunity Difference (EOD)
    - Average Odds Difference (AOD)
    - Statistical Parity Difference (SPD)
"""

import argparse
import pickle
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix


class BiasDetector:
    """Detector de bias en modelos ML con métricas de fairness."""
    
    # Thresholds según regulación bancaria
    DISPARATE_IMPACT_MIN = 0.8
    DISPARATE_IMPACT_MAX = 1.25
    EQUAL_OPPORTUNITY_THRESHOLD = 0.10
    STATISTICAL_PARITY_THRESHOLD = 0.10
    
    def __init__(self, model_path: str, data_path: str, protected_attributes: List[str]):
        """
        Inicializa el detector de bias.
        
        Args:
            model_path: Ruta al modelo pickle
            data_path: Ruta a los datos de test
            protected_attributes: Lista de atributos protegidos (ej: ['gender', 'age'])
        """
        self.model_path = model_path
        self.data_path = data_path
        self.protected_attributes = protected_attributes
        self.model: Optional[object] = None
        self.data: Optional[pd.DataFrame] = None
        self.predictions: Optional[np.ndarray] = None
        self.results: Dict = {}
        
    def load_model(self) -> None:
        """Carga el modelo desde archivo pickle."""
        try:
            with open(self.model_path, 'rb') as f:
                self.model = pickle.load(f)
            print(f"✅ Modelo cargado desde: {self.model_path}")
        except Exception as e:
            print(f"❌ Error al cargar modelo: {e}")
            sys.exit(1)
    
    def load_data(self) -> None:
        """Carga los datos de test."""
        try:
            self.data = pd.read_csv(self.data_path)
            print(f"✅ Datos cargados: {self.data.shape[0]} registros, {self.data.shape[1]} columnas")
        except Exception as e:
            print(f"❌ Error al cargar datos: {e}")
            sys.exit(1)
    
    def generate_predictions(self, target_col: str = 'target') -> None:
        """
        Genera predicciones con el modelo.
        
        Args:
            target_col: Nombre de la columna target (default: 'target')
        """
        try:
            # Separar features y target
            feature_cols = [col for col in self.data.columns 
                          if col != target_col and col not in self.protected_attributes]
            
            X = self.data[feature_cols]
            y_true = self.data[target_col]
            
            # Predecir
            y_pred = self.model.predict(X)
            
            # Agregar a dataframe
            self.data['y_true'] = y_true
            self.data['y_pred'] = y_pred
            
            print(f"✅ Predicciones generadas para {len(y_pred)} registros")
        except Exception as e:
            print(f"❌ Error al generar predicciones: {e}")
            sys.exit(1)
    
    def calculate_disparate_impact(self, protected_attr: str) -> Dict:
        """
        Calcula Disparate Impact (DI).
        
        DI = P(Y=1|protected=True) / P(Y=1|protected=False)
        
        Threshold: 0.8 <= DI <= 1.25 (4/5 rule)
        
        Args:
            protected_attr: Atributo protegido a analizar
            
        Returns:
            Dict con resultados de DI por grupo
        """
        results = {}
        groups = self.data[protected_attr].unique()
        
        for group in groups:
            mask = self.data[protected_attr] == group
            positive_rate = self.data.loc[mask, 'y_pred'].mean()
            results[str(group)] = positive_rate
        
        # Calcular ratios entre grupos
        values = list(results.values())
        if len(values) >= 2:
            di_ratio = min(values) / max(values)
            results['disparate_impact_ratio'] = di_ratio
            results['passes_threshold'] = (
                self.DISPARATE_IMPACT_MIN <= di_ratio <= self.DISPARATE_IMPACT_MAX
            )
        
        return results
    
    def calculate_equal_opportunity(self, protected_attr: str) -> Dict:
        """
        Calcula Equal Opportunity Difference (EOD).
        
        EOD = TPR(protected=True) - TPR(protected=False)
        
        Threshold: |EOD| < 0.10
        
        Args:
            protected_attr: Atributo protegido a analizar
            
        Returns:
            Dict con TPR por grupo y diferencia
        """
        results = {}
        groups = self.data[protected_attr].unique()
        
        tprs = {}
        for group in groups:
            mask = self.data[protected_attr] == group
            group_data = self.data[mask]
            
            # Solo considerar casos positivos (y_true=1)
            positive_cases = group_data[group_data['y_true'] == 1]
            if len(positive_cases) > 0:
                tpr = positive_cases['y_pred'].mean()
                tprs[str(group)] = tpr
        
        results['true_positive_rates'] = tprs
        
        if len(tprs) >= 2:
            values = list(tprs.values())
            eod = max(values) - min(values)
            results['equal_opportunity_difference'] = eod
            results['passes_threshold'] = eod < self.EQUAL_OPPORTUNITY_THRESHOLD
        
        return results
    
    def calculate_statistical_parity(self, protected_attr: str) -> Dict:
        """
        Calcula Statistical Parity Difference (SPD).
        
        SPD = P(Y=1|protected=True) - P(Y=1|protected=False)
        
        Threshold: |SPD| < 0.10
        
        Args:
            protected_attr: Atributo protegido a analizar
            
        Returns:
            Dict con tasas de predicción positiva y diferencia
        """
        results = {}
        groups = self.data[protected_attr].unique()
        
        positive_rates = {}
        for group in groups:
            mask = self.data[protected_attr] == group
            pos_rate = self.data.loc[mask, 'y_pred'].mean()
            positive_rates[str(group)] = pos_rate
        
        results['positive_rates'] = positive_rates
        
        if len(positive_rates) >= 2:
            values = list(positive_rates.values())
            spd = max(values) - min(values)
            results['statistical_parity_difference'] = spd
            results['passes_threshold'] = spd < self.STATISTICAL_PARITY_THRESHOLD
        
        return results
    
    def calculate_confusion_matrices(self, protected_attr: str) -> Dict:
        """
        Calcula matrices de confusión por grupo.
        
        Args:
            protected_attr: Atributo protegido a analizar
            
        Returns:
            Dict con matrices por grupo
        """
        results = {}
        groups = self.data[protected_attr].unique()
        
        for group in groups:
            mask = self.data[protected_attr] == group
            group_data = self.data[mask]
            
            cm = confusion_matrix(group_data['y_true'], group_data['y_pred'])
            
            results[str(group)] = {
                'confusion_matrix': cm.tolist(),
                'tn': int(cm[0, 0]) if cm.shape == (2, 2) else 0,
                'fp': int(cm[0, 1]) if cm.shape == (2, 2) else 0,
                'fn': int(cm[1, 0]) if cm.shape == (2, 2) else 0,
                'tp': int(cm[1, 1]) if cm.shape == (2, 2) else 0
            }
        
        return results
    
    def analyze_all(self) -> Dict:
        """
        Ejecuta análisis completo de bias para todos los atributos protegidos.
        
        Returns:
            Dict con todos los resultados
        """
        print("\n" + "="*60)
        print("ANÁLISIS DE BIAS - FAIRNESS METRICS")
        print("="*60)
        
        all_results = {}
        
        for attr in self.protected_attributes:
            print(f"\n📊 Analizando atributo protegido: {attr}")
            print("-" * 60)
            
            attr_results = {
                'disparate_impact': self.calculate_disparate_impact(attr),
                'equal_opportunity': self.calculate_equal_opportunity(attr),
                'statistical_parity': self.calculate_statistical_parity(attr),
                'confusion_matrices': self.calculate_confusion_matrices(attr)
            }
            
            all_results[attr] = attr_results
            
            # Mostrar resumen
            self._print_summary(attr, attr_results)
        
        self.results = all_results
        return all_results
    
    def _print_summary(self, attr: str, results: Dict) -> None:
        """Imprime resumen de resultados para un atributo."""
        print(f"\n1️⃣ DISPARATE IMPACT (DI)")
        di = results['disparate_impact']
        for group, rate in di.items():
            if group not in ['disparate_impact_ratio', 'passes_threshold']:
                print(f"   - {group}: {rate:.4f}")
        if 'disparate_impact_ratio' in di:
            ratio = di['disparate_impact_ratio']
            status = "✅ PASS" if di['passes_threshold'] else "❌ FAIL"
            print(f"   → Ratio: {ratio:.4f} {status}")
            print(f"   → Threshold: {self.DISPARATE_IMPACT_MIN} - {self.DISPARATE_IMPACT_MAX}")
        
        print(f"\n2️⃣ EQUAL OPPORTUNITY DIFFERENCE (EOD)")
        eo = results['equal_opportunity']
        for group, tpr in eo['true_positive_rates'].items():
            print(f"   - TPR {group}: {tpr:.4f}")
        if 'equal_opportunity_difference' in eo:
            diff = eo['equal_opportunity_difference']
            status = "✅ PASS" if eo['passes_threshold'] else "❌ FAIL"
            print(f"   → Difference: {diff:.4f} {status}")
            print(f"   → Threshold: < {self.EQUAL_OPPORTUNITY_THRESHOLD}")
        
        print(f"\n3️⃣ STATISTICAL PARITY DIFFERENCE (SPD)")
        sp = results['statistical_parity']
        for group, rate in sp['positive_rates'].items():
            print(f"   - Positive rate {group}: {rate:.4f}")
        if 'statistical_parity_difference' in sp:
            diff = sp['statistical_parity_difference']
            status = "✅ PASS" if sp['passes_threshold'] else "❌ FAIL"
            print(f"   → Difference: {diff:.4f} {status}")
            print(f"   → Threshold: < {self.STATISTICAL_PARITY_THRESHOLD}")
    
    def has_bias(self) -> bool:
        """
        Determina si el modelo tiene bias significativo.
        
        Returns:
            True si se detecta bias, False si no
        """
        for attr, results in self.results.items():
            if not results['disparate_impact'].get('passes_threshold', True):
                return True
            if not results['equal_opportunity'].get('passes_threshold', True):
                return True
            if not results['statistical_parity'].get('passes_threshold', True):
                return True
        return False
    
    def generate_report(self, output_path: str) -> None:
        """
        Genera reporte HTML con resultados.
        
        Args:
            output_path: Ruta del archivo HTML de salida
        """
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Bias Detection Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        h1 {{ color: #2c3e50; }}
        h2 {{ color: #34495e; margin-top: 30px; }}
        .metric {{ margin: 20px 0; padding: 15px; border-left: 4px solid #3498db; background: #ecf0f1; }}
        .pass {{ border-left-color: #27ae60; }}
        .fail {{ border-left-color: #e74c3c; }}
        table {{ border-collapse: collapse; width: 100%; margin: 15px 0; }}
        th, td {{ border: 1px solid #bdc3c7; padding: 10px; text-align: left; }}
        th {{ background: #34495e; color: white; }}
        .status-pass {{ color: #27ae60; font-weight: bold; }}
        .status-fail {{ color: #e74c3c; font-weight: bold; }}
    </style>
</head>
<body>
    <h1>🔍 Bias Detection Report</h1>
    <p><strong>Modelo:</strong> {self.model_path}</p>
    <p><strong>Datos:</strong> {self.data_path}</p>
    <p><strong>Fecha:</strong> {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
    
    <h2>📊 Resumen General</h2>
    <div class="metric {'fail' if self.has_bias() else 'pass'}">
        <p><strong>Status:</strong> <span class="{'status-fail' if self.has_bias() else 'status-pass'}">
            {'❌ BIAS DETECTADO' if self.has_bias() else '✅ NO SE DETECTÓ BIAS SIGNIFICATIVO'}
        </span></p>
    </div>
"""
        
        for attr, results in self.results.items():
            html += f"""
    <h2>Atributo Protegido: {attr}</h2>
    
    <h3>1. Disparate Impact</h3>
    <table>
        <tr><th>Grupo</th><th>Tasa Positiva</th></tr>
"""
            for group, rate in results['disparate_impact'].items():
                if group not in ['disparate_impact_ratio', 'passes_threshold']:
                    html += f"<tr><td>{group}</td><td>{rate:.4f}</td></tr>"
            
            if 'disparate_impact_ratio' in results['disparate_impact']:
                ratio = results['disparate_impact']['disparate_impact_ratio']
                passes = results['disparate_impact']['passes_threshold']
                html += f"""
    </table>
    <div class="metric {'pass' if passes else 'fail'}">
        <p><strong>Ratio:</strong> {ratio:.4f}</p>
        <p><strong>Threshold:</strong> {self.DISPARATE_IMPACT_MIN} - {self.DISPARATE_IMPACT_MAX}</p>
        <p><strong>Status:</strong> <span class="{'status-pass' if passes else 'status-fail'}">
            {'✅ PASS' if passes else '❌ FAIL'}
        </span></p>
    </div>
"""
        
        html += """
</body>
</html>
"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"\n📄 Reporte generado: {output_path}")


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(
        description='Detectar bias en modelos de Machine Learning',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  python detect-model-bias.py --model model.pkl --data test.csv --protected-attrs gender,age
  python detect-model-bias.py --model model.pkl --data test.csv --protected-attrs gender --output report.html
        """
    )
    
    parser.add_argument('--model', required=True, help='Ruta al modelo pickle')
    parser.add_argument('--data', required=True, help='Ruta a los datos de test (CSV)')
    parser.add_argument('--protected-attrs', required=True, 
                       help='Atributos protegidos separados por coma (ej: gender,age)')
    parser.add_argument('--target', default='target', 
                       help='Nombre de la columna target (default: target)')
    parser.add_argument('--output', default='bias_report.html',
                       help='Ruta del reporte HTML (default: bias_report.html)')
    
    args = parser.parse_args()
    
    # Parsear atributos protegidos
    protected_attrs = [attr.strip() for attr in args.protected_attrs.split(',')]
    
    # Inicializar detector
    detector = BiasDetector(args.model, args.data, protected_attrs)
    
    # Cargar modelo y datos
    detector.load_model()
    detector.load_data()
    
    # Generar predicciones
    detector.generate_predictions(args.target)
    
    # Analizar bias
    detector.analyze_all()
    
    # Generar reporte
    detector.generate_report(args.output)
    
    # Exit code
    exit_code = 1 if detector.has_bias() else 0
    print(f"\n{'❌' if exit_code else '✅'} Proceso completado con código: {exit_code}")
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
