#!/usr/bin/env python3
"""
Clean Notebook Secrets - Limpieza de Secrets en Jupyter Notebooks
===================================================================

Script para detectar y remover secrets (API keys, passwords, tokens) de notebooks
antes de hacer commit. Puede usarse como pre-commit hook.

Autor: Mi Banco - Data Science Team
Taller: GitHub Advanced Security para Data Science
Versión: 1.0.0

Uso:
    python clean-notebook-secrets.py notebook.ipynb
    python clean-notebook-secrets.py notebook.ipynb --fail-on-secrets
    python clean-notebook-secrets.py notebook.ipynb --output cleaned.ipynb

Detecta:
    - API keys (AWS, OpenAI, Stripe, etc.)
    - Passwords y tokens
    - Database credentials
    - Connection strings
    - Emails y números de teléfono (PII)
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class NotebookSecretsCleaner:
    """Limpiador de secrets en Jupyter Notebooks."""
    
    # Patrones regex para detectar secrets
    SECRET_PATTERNS = {
        'aws_access_key': (
            r'AKIA[0-9A-Z]{16}',
            'AWS Access Key'
        ),
        'aws_secret_key': (
            r'aws_secret.*[=:]\s*["\']([a-zA-Z0-9/+=]{40})["\']',
            'AWS Secret Key'
        ),
        'openai_key': (
            r'sk-[a-zA-Z0-9]{48}',
            'OpenAI API Key'
        ),
        'stripe_key': (
            r'sk_live_[a-zA-Z0-9]{24,}',
            'Stripe Secret Key'
        ),
        'github_token': (
            r'ghp_[a-zA-Z0-9]{36}',
            'GitHub Personal Access Token'
        ),
        'generic_api_key': (
            r'(?i)api[_-]?key.*[=:]\s*["\']([a-zA-Z0-9_\-]{20,})["\']',
            'Generic API Key'
        ),
        'password': (
            r'(?i)password.*[=:]\s*["\']([^"\'\s]{8,})["\']',
            'Password'
        ),
        'token': (
            r'(?i)token.*[=:]\s*["\']([a-zA-Z0-9_\-\.]{20,})["\']',
            'Token'
        ),
        'db_connection': (
            r'(?i)(postgresql|mysql|mongodb)://[^:]+:[^@]+@[\w\.\-]+',
            'Database Connection String'
        ),
        'private_key': (
            r'-----BEGIN (RSA |EC )?PRIVATE KEY-----',
            'Private Key'
        ),
        'email': (
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'Email (PII)'
        ),
        'phone': (
            r'(?:\+?51\s?)?(?:9\d{2}\s?\d{3}\s?\d{3})',
            'Phone Number (PII)'
        ),
    }
    
    def __init__(self, notebook_path: str, output_path: Optional[str] = None, fail_on_secrets: bool = False):
        """
        Inicializa el limpiador.
        
        Args:
            notebook_path: Ruta al notebook
            output_path: Ruta del notebook limpio (None = sobrescribir)
            fail_on_secrets: Si True, falla con exit code 1 si encuentra secrets
        """
        self.notebook_path = Path(notebook_path)
        self.output_path = Path(output_path) if output_path else self.notebook_path
        self.fail_on_secrets = fail_on_secrets
        self.notebook: Optional[Dict] = None
        self.secrets_found: List[Dict] = []
        
    def load_notebook(self) -> None:
        """Carga el notebook desde archivo."""
        try:
            with open(self.notebook_path, 'r', encoding='utf-8') as f:
                self.notebook = json.load(f)
            print(f"✅ Notebook cargado: {self.notebook_path}")
        except Exception as e:
            print(f"❌ Error al cargar notebook: {e}")
            sys.exit(1)
    
    def scan_cell(self, cell_index: int, cell: Dict) -> List[Dict]:
        """
        Escanea una celda en busca de secrets.
        
        Args:
            cell_index: Índice de la celda
            cell: Diccionario con datos de la celda
            
        Returns:
            Lista de secrets encontrados
        """
        findings = []
        
        # Solo escanear celdas de código
        if cell.get('cell_type') != 'code':
            return findings
        
        # Obtener código fuente
        source = cell.get('source', [])
        if isinstance(source, list):
            source = ''.join(source)
        
        # Buscar cada patrón
        for secret_type, (pattern, description) in self.SECRET_PATTERNS.items():
            matches = re.finditer(pattern, source)
            for match in matches:
                # Encontrar número de línea dentro de la celda
                line_num = source[:match.start()].count('\n') + 1
                
                finding = {
                    'cell_index': cell_index,
                    'line_in_cell': line_num,
                    'secret_type': secret_type,
                    'description': description,
                    'matched_text': match.group(0),
                    'context': self._get_context(source, match.start(), match.end())
                }
                findings.append(finding)
        
        return findings
    
    def _get_context(self, text: str, start: int, end: int, context_chars: int = 50) -> str:
        """
        Obtiene contexto alrededor del match.
        
        Args:
            text: Texto completo
            start: Inicio del match
            end: Fin del match
            context_chars: Caracteres de contexto a cada lado
            
        Returns:
            String con contexto
        """
        context_start = max(0, start - context_chars)
        context_end = min(len(text), end + context_chars)
        
        context = text[context_start:context_end]
        # Reemplazar el secret con [REDACTED]
        secret_start = start - context_start
        secret_end = secret_start + (end - start)
        context = context[:secret_start] + '[REDACTED]' + context[secret_end:]
        
        return context.strip()
    
    def scan_all_cells(self) -> List[Dict]:
        """
        Escanea todas las celdas del notebook.
        
        Returns:
            Lista de todos los secrets encontrados
        """
        print("\n🔍 Escaneando notebook en busca de secrets...")
        
        all_findings = []
        cells = self.notebook.get('cells', [])
        
        for i, cell in enumerate(cells):
            findings = self.scan_cell(i, cell)
            all_findings.extend(findings)
        
        self.secrets_found = all_findings
        return all_findings
    
    def clean_cell(self, cell: Dict) -> Dict:
        """
        Limpia secrets de una celda.
        
        Args:
            cell: Diccionario con datos de la celda
            
        Returns:
            Celda limpia
        """
        if cell.get('cell_type') != 'code':
            return cell
        
        source = cell.get('source', [])
        if isinstance(source, list):
            source = ''.join(source)
        
        # Reemplazar cada patrón
        for secret_type, (pattern, description) in self.SECRET_PATTERNS.items():
            if secret_type in ['aws_access_key', 'openai_key', 'stripe_key', 'github_token']:
                # Reemplazar con placeholder
                source = re.sub(pattern, '[REDACTED_SECRET]', source)
            elif secret_type in ['generic_api_key', 'password', 'token']:
                # Reemplazar con os.getenv()
                source = re.sub(
                    pattern,
                    lambda m: f'{m.group(0).split("=")[0]}= os.getenv("{secret_type.upper()}")',
                    source
                )
            elif secret_type == 'db_connection':
                # Reemplazar con variable de entorno
                source = re.sub(pattern, 'os.getenv("DATABASE_URL")', source)
            elif secret_type == 'private_key':
                source = re.sub(pattern, '[REDACTED_PRIVATE_KEY]', source)
            elif secret_type in ['email', 'phone']:
                # Anonymizar PII
                source = re.sub(pattern, '[REDACTED_PII]', source)
        
        # Convertir de vuelta a lista si es necesario
        if isinstance(cell.get('source', []), list):
            cell['source'] = source.split('\n')
            # Agregar \n al final de cada línea excepto la última
            cell['source'] = [line + '\n' for line in cell['source'][:-1]] + [cell['source'][-1]]
        else:
            cell['source'] = source
        
        return cell
    
    def clean_all_cells(self) -> None:
        """Limpia secrets de todas las celdas."""
        print("\n🧹 Limpiando secrets del notebook...")
        
        cells = self.notebook.get('cells', [])
        cleaned_cells = []
        
        for cell in cells:
            cleaned_cell = self.clean_cell(cell)
            cleaned_cells.append(cleaned_cell)
        
        self.notebook['cells'] = cleaned_cells
        print(f"✅ {len(cleaned_cells)} celdas procesadas")
    
    def save_notebook(self) -> None:
        """Guarda el notebook limpio."""
        try:
            with open(self.output_path, 'w', encoding='utf-8') as f:
                json.dump(self.notebook, f, indent=1, ensure_ascii=False)
            print(f"✅ Notebook guardado: {self.output_path}")
        except Exception as e:
            print(f"❌ Error al guardar notebook: {e}")
            sys.exit(1)
    
    def generate_report(self) -> str:
        """
        Genera reporte de secrets encontrados.
        
        Returns:
            String con el reporte
        """
        if not self.secrets_found:
            return "\n✅ No se encontraron secrets en el notebook.\n"
        
        report = f"\n{'='*70}\n"
        report += f"🚨 SECRETS DETECTADOS: {len(self.secrets_found)}\n"
        report += f"{'='*70}\n\n"
        
        for i, finding in enumerate(self.secrets_found, 1):
            report += f"{i}. {finding['description']}\n"
            report += f"   📍 Celda: {finding['cell_index']}, Línea: {finding['line_in_cell']}\n"
            report += f"   🔍 Tipo: {finding['secret_type']}\n"
            report += f"   📝 Contexto: ...{finding['context']}...\n"
            report += "\n"
        
        report += f"{'='*70}\n"
        report += "RECOMENDACIONES:\n"
        report += "1. Usar variables de entorno con python-dotenv\n"
        report += "2. Crear archivo .env (agregarlo a .gitignore)\n"
        report += "3. Crear .env.example con placeholders\n"
        report += "4. Ejecutar `python scripts/clean-notebook-secrets.py` para limpiar\n"
        report += f"{'='*70}\n"
        
        return report
    
    def generate_env_example(self) -> str:
        """
        Genera contenido para archivo .env.example.
        
        Returns:
            Contenido del archivo
        """
        env_vars = set()
        
        for finding in self.secrets_found:
            secret_type = finding['secret_type']
            
            if 'aws' in secret_type:
                env_vars.add('AWS_ACCESS_KEY_ID')
                env_vars.add('AWS_SECRET_ACCESS_KEY')
            elif 'openai' in secret_type:
                env_vars.add('OPENAI_API_KEY')
            elif 'stripe' in secret_type:
                env_vars.add('STRIPE_SECRET_KEY')
            elif 'github' in secret_type:
                env_vars.add('GITHUB_TOKEN')
            elif secret_type in ['generic_api_key', 'password', 'token']:
                env_vars.add(secret_type.upper())
            elif 'db' in secret_type:
                env_vars.add('DATABASE_URL')
        
        content = "# Environment Variables - Template\n"
        content += "# Copy this file to .env and fill with actual values\n"
        content += "# DO NOT commit .env to git!\n\n"
        
        for var in sorted(env_vars):
            content += f"{var}=your_{var.lower()}_here\n"
        
        return content


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(
        description='Limpiar secrets de Jupyter Notebooks',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  python clean-notebook-secrets.py notebook.ipynb
  python clean-notebook-secrets.py notebook.ipynb --fail-on-secrets
  python clean-notebook-secrets.py notebook.ipynb --output cleaned.ipynb
  python clean-notebook-secrets.py notebook.ipynb --generate-env
        """
    )
    
    parser.add_argument('notebook', help='Ruta al notebook .ipynb')
    parser.add_argument('--output', help='Ruta del notebook limpio (default: sobrescribir)')
    parser.add_argument('--fail-on-secrets', action='store_true',
                       help='Fallar con exit code 1 si encuentra secrets')
    parser.add_argument('--generate-env', action='store_true',
                       help='Generar archivo .env.example')
    
    args = parser.parse_args()
    
    # Inicializar cleaner
    cleaner = NotebookSecretsCleaner(
        args.notebook,
        args.output,
        args.fail_on_secrets
    )
    
    # Cargar notebook
    cleaner.load_notebook()
    
    # Escanear
    cleaner.scan_all_cells()
    
    # Mostrar reporte
    report = cleaner.generate_report()
    print(report)
    
    # Generar .env.example si se solicita
    if args.generate_env and cleaner.secrets_found:
        env_content = cleaner.generate_env_example()
        env_path = Path('.env.example')
        with open(env_path, 'w') as f:
            f.write(env_content)
        print(f"📄 Archivo generado: {env_path}")
    
    # Limpiar si se encontraron secrets
    if cleaner.secrets_found:
        cleaner.clean_all_cells()
        cleaner.save_notebook()
    
    # Exit code
    if args.fail_on_secrets and cleaner.secrets_found:
        print("\n❌ FAIL: Se encontraron secrets en el notebook")
        sys.exit(1)
    else:
        print("\n✅ Proceso completado exitosamente")
        sys.exit(0)


if __name__ == '__main__':
    main()
