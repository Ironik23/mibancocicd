/**
 * CÓDIGO VULNERABLE PARA PROPÓSITOS EDUCATIVOS
 * Este código contiene 20 vulnerabilidades de seguridad intencionales
 * para ser detectadas por GitHub Advanced Security (CodeQL)
 * 
 * ⚠️ NO USAR EN PRODUCCIÓN
 * 
 * Tecnologías: Node.js + Express + MySQL
 */

const express = require('express');
const mysql = require('mysql');
const crypto = require('crypto');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// VULNERABILIDAD 1: Credenciales hardcodeadas
const DB_PASSWORD = 'Admin123!';
const API_KEY = 'sk-1234567890abcdef';
const JWT_SECRET = 'mySecretKey123';
const GITHUB_TOKEN = 'ghp_1234567890abcdefghijklmnopqrstuvwxyz';

// VULNERABILIDAD 2: Configuración de DB insegura
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: DB_PASSWORD,
    database: 'banking'
});

db.connect((err) => {
    if (err) {
        console.log('DB Error:', err);
        console.log('Password:', DB_PASSWORD); // VULNERABILIDAD 3: Password en logs
    }
});

/**
 * VULNERABILIDAD 4: SQL Injection
 * No usa prepared statements, concatena input directamente
 */
app.get('/api/account/:userId', (req, res) => {
    const userId = req.params.userId;
    
    // SQL Injection vulnerable
    const query = `SELECT * FROM accounts WHERE user_id = '${userId}'`;
    
    db.query(query, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

/**
 * VULNERABILIDAD 5: SQL Injection en login
 * VULNERABILIDAD 6: No valida credenciales correctamente
 */
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    // SQL Injection vulnerable - bypass con: admin' OR '1'='1
    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
    
    db.query(query, (err, results) => {
        if (err) throw err;
        
        if (results.length > 0) {
            const token = generateToken(username);
            res.json({ success: true, token: token });
        } else {
            res.json({ success: false });
        }
    });
});

/**
 * VULNERABILIDAD 7: Generación de token insegura
 * Usa Math.random() que no es criptográficamente seguro
 */
function generateToken(username) {
    // VULNERABILIDAD: Math.random() no es seguro
    const randomValue = Math.random().toString(36).substring(7);
    return `${username}_${randomValue}`;
}

/**
 * VULNERABILIDAD 8: Command Injection
 * Ejecuta comandos del sistema con input del usuario sin validación
 */
app.get('/api/export/:filename', (req, res) => {
    const filename = req.params.filename;
    
    // Command Injection vulnerable
    const command = `tar -czf /exports/${filename}.tar.gz /data`;
    
    exec(command, (error, stdout, stderr) => {
        if (error) {
            res.status(500).send(`Error: ${error.message}`);
            return;
        }
        res.send(`Export started for: ${filename}`);
    });
});

/**
 * VULNERABILIDAD 9: Path Traversal
 * Permite acceder a archivos fuera del directorio permitido
 */
app.get('/api/download/:filename', (req, res) => {
    const filename = req.params.filename;
    
    // Path Traversal vulnerable - puede usar: ../../etc/passwd
    const filePath = path.join('/app/documents/', filename);
    
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.status(404).send('File not found');
            return;
        }
        res.send(data);
    });
});

/**
 * VULNERABILIDAD 10: eval() con input del usuario
 * Permite ejecución de código arbitrario
 */
app.post('/api/calculate', (req, res) => {
    const { expression } = req.body;
    
    // eval() vulnerable - puede ejecutar: require('child_process').exec('rm -rf /')
    try {
        const result = eval(expression);
        res.json({ result: result });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

/**
 * VULNERABILIDAD 11: XSS (Cross-Site Scripting)
 * No sanitiza output que se renderiza en HTML
 */
app.get('/api/profile/:username', (req, res) => {
    const username = req.params.username;
    
    // XSS vulnerable - puede inyectar: <script>alert('XSS')</script>
    res.send(`<html><body><h1>Profile: ${username}</h1></body></html>`);
});

/**
 * VULNERABILIDAD 12: Prototype Pollution
 * Modifica Object.prototype sin validación
 */
app.post('/api/config/update', (req, res) => {
    const { key, value } = req.body;
    
    // Prototype Pollution vulnerable
    let config = {};
    config[key] = value; // Si key es "__proto__", contamina el prototype
    
    res.json({ message: 'Config updated', config: config });
});

/**
 * VULNERABILIDAD 13: NoSQL Injection (si usara MongoDB)
 * VULNERABILIDAD 14: Información sensible en logs
 */
app.post('/api/transfer', (req, res) => {
    const { fromAccount, toAccount, amount, pin } = req.body;
    
    // VULNERABILIDAD: Loguea información sensible
    console.log(`Transfer from: ${fromAccount} to: ${toAccount} amount: ${amount} PIN: ${pin}`);
    
    // VULNERABILIDAD 15: No usa transacciones
    const debit = `UPDATE accounts SET balance = balance - ${amount} WHERE account_number = '${fromAccount}'`;
    const credit = `UPDATE accounts SET balance = balance + ${amount} WHERE account_number = '${toAccount}'`;
    
    db.query(debit, (err1) => {
        if (err1) throw err1;
        
        // Si falla aquí, el dinero se pierde
        db.query(credit, (err2) => {
            if (err2) throw err2;
            res.json({ success: true });
        });
    });
});

/**
 * VULNERABILIDAD 16: Race Condition
 * No sincroniza acceso a balance
 */
app.post('/api/withdraw', (req, res) => {
    const { accountNumber, amount } = req.body;
    
    // Lee balance
    const query = `SELECT balance FROM accounts WHERE account_number = '${accountNumber}'`;
    
    db.query(query, (err, results) => {
        if (err) throw err;
        
        if (results.length > 0) {
            const balance = results[0].balance;
            
            // VULNERABILIDAD: Race condition
            if (balance >= amount) {
                // Actualiza balance (sin lock)
                const update = `UPDATE accounts SET balance = balance - ${amount} WHERE account_number = '${accountNumber}'`;
                
                db.query(update, (err2) => {
                    if (err2) throw err2;
                    res.json({ success: true });
                });
            } else {
                res.json({ success: false, message: 'Insufficient funds' });
            }
        }
    });
});

/**
 * VULNERABILIDAD 17: Weak Cryptography
 * Usa MD5 para hashear passwords (inseguro)
 */
app.post('/api/register', (req, res) => {
    const { username, password } = req.body;
    
    // VULNERABILIDAD: MD5 es débil y no usa salt
    const hash = crypto.createHash('md5').update(password).digest('hex');
    
    const query = `INSERT INTO users (username, password) VALUES ('${username}', '${hash}')`;
    
    db.query(query, (err) => {
        if (err) throw err;
        res.json({ success: true });
    });
});

/**
 * VULNERABILIDAD 18: Server-Side Request Forgery (SSRF)
 * Hace requests a URLs proporcionadas por el usuario
 */
app.get('/api/fetch', (req, res) => {
    const { url } = req.query;
    
    // SSRF vulnerable - puede acceder a: http://localhost:8080/admin
    const https = require('https');
    const http = require('http');
    
    const protocol = url.startsWith('https') ? https : http;
    
    protocol.get(url, (response) => {
        let data = '';
        response.on('data', (chunk) => {
            data += chunk;
        });
        response.on('end', () => {
            res.send(data);
        });
    }).on('error', (err) => {
        res.status(500).send(err.message);
    });
});

/**
 * VULNERABILIDAD 19: Información sensible expuesta
 * Endpoint de debug que expone configuración
 */
app.get('/api/debug/config', (req, res) => {
    const config = {
        db_password: DB_PASSWORD,
        api_key: API_KEY,
        jwt_secret: JWT_SECRET,
        github_token: GITHUB_TOKEN,
        db_host: 'localhost',
        db_user: 'root'
    };
    
    res.json(config);
});

/**
 * VULNERABILIDAD 20: ReDoS (Regular Expression Denial of Service)
 * Usa regex vulnerable a catastrophic backtracking
 */
app.post('/api/validate/email', (req, res) => {
    const { email } = req.body;
    
    // ReDoS vulnerable con input como: aaaaaaaaaaaaaaaaaaaaaaaaa!
    const emailRegex = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    
    const isValid = emailRegex.test(email);
    res.json({ valid: isValid });
});

/**
 * VULNERABILIDAD ADICIONAL: No valida Content-Type
 * Vulnerable a CSRF
 */
app.post('/api/process', (req, res) => {
    // No valida Content-Type ni tiene protección CSRF
    res.json({ message: 'Processed' });
});

/**
 * VULNERABILIDAD ADICIONAL: CORS mal configurado
 * Permite cualquier origen
 */
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // Vulnerable
    res.header('Access-Control-Allow-Headers', '*');
    res.header('Access-Control-Allow-Methods', '*');
    next();
});

/**
 * VULNERABILIDAD ADICIONAL: No limita rate
 * Vulnerable a DoS
 */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`API Key: ${API_KEY}`); // Credencial en logs
});

module.exports = app;
