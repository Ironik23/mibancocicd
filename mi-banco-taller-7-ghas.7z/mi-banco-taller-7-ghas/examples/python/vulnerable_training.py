"""
Ejemplo de código de ML vulnerable - Model Training Pipeline
=============================================================

Este archivo contiene vulnerabilidades comunes en pipelines de ML.

Vulnerabilidades:
- Data leakage
- No reproducibility (missing seeds)
- Insecure model storage
- No validation
- Bias not measured
"""

import numpy as np
import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# ❌ VULNERABILIDAD 1: No random seeds - resultados no reproducibles
# np.random.seed(42)  # Comentado!


def load_data():
    """Carga datos de clientes para credit scoring."""
    # Simular datos
    n_samples = 1000
    
    data = pd.DataFrame({
        'customer_id': range(1, n_samples + 1),
        'income': np.random.randint(1000, 10000, n_samples),
        'age': np.random.randint(18, 70, n_samples),
        'employment_years': np.random.randint(0, 40, n_samples),
        'credit_history': np.random.randint(300, 850, n_samples),
        'num_accounts': np.random.randint(1, 10, n_samples),
        'debt_ratio': np.random.uniform(0, 1, n_samples),
    })
    
    # Target: 1 = aprobado, 0 = rechazado
    data['approved'] = (data['credit_history'] > 600).astype(int)
    
    return data


def engineer_features(data):
    """
    Feature engineering con data leakage.
    
    ❌ VULNERABILIDADES:
    - Data leakage
    - Features usando información del futuro
    """
    # ❌ VULNERABILIDAD 2: Data leakage - usar información del futuro
    # En realidad, estos datos NO existirían al momento de decidir
    data['total_future_payments'] = np.random.randint(0, 24, len(data))
    data['default_next_year'] = np.random.choice([0, 1], len(data), p=[0.9, 0.1])
    
    # ❌ VULNERABILIDAD 3: Target leakage - feature derivado del target
    data['risk_score'] = data['approved'].map({0: 100, 1: 500})
    
    # ❌ VULNERABILIDAD 4: Look-ahead bias - usar estadísticas del futuro
    # Calcular mean de todo el dataset (incluye test set)
    data['income_ratio'] = data['income'] / data['income'].mean()
    
    return data


def split_data(data):
    """
    Split data sin estratificación ni validación.
    
    ❌ VULNERABILIDADES:
    - No stratification (puede crear desbalance)
    - No random seed
    """
    features = [
        'income', 'age', 'employment_years', 'credit_history',
        'num_accounts', 'debt_ratio',
        'total_future_payments',  # ❌ Data leakage!
        'default_next_year',      # ❌ Data leakage!
        'risk_score',             # ❌ Target leakage!
        'income_ratio'            # ❌ Look-ahead bias!
    ]
    
    X = data[features]
    y = data['approved']
    
    # ❌ VULNERABILIDAD 5: Sin random_state - no reproducible
    # ❌ VULNERABILIDAD 6: Sin stratify - puede crear desbalance
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, 
        test_size=0.2
        # random_state=42,  # Comentado!
        # stratify=y        # Comentado!
    )
    
    return X_train, X_test, y_train, y_test


def train_model(X_train, y_train):
    """
    Entrena modelo sin reproducibilidad ni validación.
    
    ❌ VULNERABILIDADES:
    - No random seed en modelo
    - No cross-validation
    - No hyperparameter tuning
    - No bias measurement
    """
    # ❌ VULNERABILIDAD 7: Sin random_state en modelo
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10
        # random_state=42  # Comentado!
    )
    
    # Entrenar sin validación cruzada
    model.fit(X_train, y_train)
    
    return model


def evaluate_model(model, X_test, y_test):
    """
    Evalúa modelo sin métricas de fairness.
    
    ❌ VULNERABILIDADES:
    - Solo accuracy (no precision, recall)
    - No fairness metrics
    - No bias detection
    """
    y_pred = model.predict(X_test)
    
    # ❌ VULNERABILIDAD 8: Solo accuracy - métricas incompletas
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"Model Accuracy: {accuracy:.4f}")
    
    # ❌ VULNERABILIDAD 9: No fairness metrics
    # Deberíamos medir:
    # - Disparate impact
    # - Equal opportunity
    # - Statistical parity
    
    return accuracy


def save_model(model, path='model.pkl'):
    """
    Guarda modelo sin metadata ni validación.
    
    ❌ VULNERABILIDADES:
    - No model versioning
    - No metadata (hyperparams, metrics, data version)
    - No hash/signature para validar integridad
    """
    # ❌ VULNERABILIDAD 10: Solo pickle, sin metadata
    with open(path, 'wb') as f:
        pickle.dump(model, f)
    
    print(f"Model saved to {path}")
    
    # ❌ VULNERABILIDAD 11: No guardar metadata
    # Deberíamos guardar:
    # - Hyperparameters
    # - Training metrics
    # - Data version/hash
    # - Git commit
    # - Timestamp
    # - Model signature/hash


def load_model_production(path='model.pkl'):
    """
    Carga modelo sin validar integridad.
    
    ❌ VULNERABILIDAD: Pickle inseguro
    """
    # ❌ VULNERABILIDAD 12: Cargar pickle sin validar hash
    with open(path, 'rb') as f:
        model = pickle.load(f)
    
    # No verificamos:
    # - Hash del archivo
    # - Signature digital
    # - Version compatibility
    
    return model


def predict_batch(model, data_path):
    """
    Predicciones batch sin logging ni monitoreo.
    
    ❌ VULNERABILIDADES:
    - No input validation
    - No logging de predicciones
    - No drift detection
    """
    # ❌ VULNERABILIDAD 13: No validar input
    data = pd.read_csv(data_path)
    
    # ❌ VULNERABILIDAD 14: Asumir que features están presentes
    predictions = model.predict(data)
    
    # ❌ VULNERABILIDAD 15: No logging para auditoría
    # Deberíamos loggear:
    # - Input data (sin PII)
    # - Predictions
    # - Confidence scores
    # - Timestamp
    # - Model version
    
    return predictions


def main():
    """Pipeline de entrenamiento con múltiples vulnerabilidades."""
    print("="*60)
    print("Training Credit Scoring Model")
    print("⚠️  WARNING: Este código contiene vulnerabilidades")
    print("="*60)
    
    # Cargar datos
    print("\n1. Loading data...")
    data = load_data()
    
    # Feature engineering con leakage
    print("2. Engineering features...")
    data = engineer_features(data)
    
    # Split sin reproducibilidad
    print("3. Splitting data...")
    X_train, X_test, y_train, y_test = split_data(data)
    
    print(f"   Train: {X_train.shape}, Test: {X_test.shape}")
    print(f"   ⚠️  Sin random seed - split no es reproducible!")
    
    # Entrenar modelo
    print("\n4. Training model...")
    model = train_model(X_train, y_train)
    print("   ⚠️  Modelo entrenado sin random seed!")
    
    # Evaluar
    print("\n5. Evaluating model...")
    accuracy = evaluate_model(model, X_test, y_test)
    print("   ⚠️  Solo accuracy - faltan métricas de fairness!")
    
    # Guardar modelo
    print("\n6. Saving model...")
    save_model(model, 'credit_model.pkl')
    print("   ⚠️  Guardado sin metadata ni hash!")
    
    print("\n" + "="*60)
    print("✅ Training completado")
    print("❌ ADVERTENCIA: Este modelo tiene múltiples problemas:")
    print("   - Data leakage en features")
    print("   - No reproducible (sin seeds)")
    print("   - No se midió bias/fairness")
    print("   - Sin metadata de modelo")
    print("   - Pickle inseguro")
    print("="*60)


if __name__ == '__main__':
    main()
