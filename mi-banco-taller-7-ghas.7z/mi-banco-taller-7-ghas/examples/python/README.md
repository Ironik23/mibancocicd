# Ejemplos Python - Taller 7: GHAS para Data Science

Esta carpeta contiene ejemplos de código Python para el taller, incluyendo código vulnerable intencionalmente para propósitos educativos.

## 📁 Archivos

### Notebooks
- **`vulnerable_ml_notebook.ipynb`** - Notebook con 12 vulnerabilidades para identificar y corregir
  - API keys hardcoded
  - SQL injection
  - PII expuesta
  - Data leakage
  - Pickle inseguro
  - Uso de eval/exec

### Scripts de ejemplo
- **`vulnerable_api.py`** - API Flask con vulnerabilidades de seguridad
  - Endpoints sin autenticación
  - SQL injection
  - File upload inseguro
  - Code injection

- **`vulnerable_training.py`** - Pipeline de ML con problemas
  - Data leakage
  - Sin reproducibilidad
  - No medición de bias
  - Pickle inseguro

### Datos
- **`test_data.csv`** - Datos de ejemplo para credit scoring
  - 30 registros de clientes ficticios
  - Incluye atributos protegidos (género, región)
  - Para validar fairness metrics

### Utilidades
- **`create_sample_model.py`** - Script para generar modelo de ejemplo
  - Entrena RandomForest con datos de test
  - Genera `credit_model.pkl` para usar en ejercicios

## 🚀 Uso Rápido

### 1. Crear modelo de ejemplo
```powershell
cd examples/python
python create_sample_model.py
```

Esto genera `credit_model.pkl` que puedes usar en los ejercicios.

### 2. Analizar notebook vulnerable
```powershell
# Abrir con Jupyter
jupyter notebook vulnerable_ml_notebook.ipynb

# O con VS Code
code vulnerable_ml_notebook.ipynb
```

### 3. Detectar bias en modelo
```powershell
python ../../scripts/detect-model-bias.py `
  --model credit_model.pkl `
  --data test_data.csv `
  --protected-attrs gender,region `
  --output bias_report.html
```

### 4. Limpiar secrets del notebook
```powershell
python ../../scripts/clean-notebook-secrets.py `
  vulnerable_ml_notebook.ipynb `
  --fail-on-secrets
```

### 5. Validar dependencias
```powershell
# Simular cambio de versión
cp ../../requirements.txt requirements.txt.old
# Editar requirements.txt para cambiar versión

python ../../scripts/validate-ml-dependencies.py `
  --old requirements.txt.old `
  --new ../../requirements.txt `
  --model credit_model.pkl `
  --test-data test_data.csv
```

## ⚠️ Vulnerabilidades Intencionadas

Todos los archivos en esta carpeta contienen vulnerabilidades **intencionalmente** para propósitos educativos:

### vulnerable_ml_notebook.ipynb (12 vulnerabilidades)
1. ✅ API keys hardcoded
2. ✅ Database credentials expuestas
3. ✅ SQL Injection vulnerable
4. ✅ PII expuesta en logs
5. ✅ Data leakage (features con información del futuro)
6. ✅ Sin reproducibilidad (no random seeds)
7. ✅ Sin random seeds en modelo
8. ✅ Uso peligroso de eval()
9. ✅ Pickle inseguro (sin validación)
10. ✅ Uso de exec()
11. ✅ Logging excesivo con información sensible
12. ✅ Dependencias sin versión fija

### vulnerable_api.py (16 vulnerabilidades)
1. ✅ Hardcoded credentials
2. ✅ Debug mode en producción
3. ✅ SQL injection en endpoint
4. ✅ Logging de PII
5. ✅ Insecure pickle loading
6. ✅ No authentication en endpoints críticos
7. ✅ No file validation en uploads
8. ✅ Arbitrary pickle loading
9. ✅ eval() con input de usuario
10. ✅ exec() con código arbitrario
11. ✅ SQL injection en query params
12. ✅ Exposing error details
13. ✅ Timing attack en validación
14. ✅ Secrets en código
15. ✅ Weak random para tokens
16. ✅ Running on 0.0.0.0 con debug

### vulnerable_training.py (15 vulnerabilidades)
1. ✅ No random seeds
2. ✅ Data leakage (features del futuro)
3. ✅ Target leakage (features derivados del target)
4. ✅ Look-ahead bias
5. ✅ Sin random_state en split
6. ✅ Sin stratification
7. ✅ Sin random_state en modelo
8. ✅ Solo accuracy (métricas incompletas)
9. ✅ No fairness metrics
10. ✅ No model versioning
11. ✅ No metadata
12. ✅ Pickle sin hash
13. ✅ No input validation
14. ✅ Asumir features presentes
15. ✅ No logging para auditoría

## 🎯 Ejercicios del Taller

### Ejercicio 1: Análisis estático con CodeQL
1. Configurar CodeQL para Python DS
2. Ejecutar análisis en estos archivos
3. Revisar alertas en GitHub Security

### Ejercicio 2: Detección de bias
1. Ejecutar script de detección de bias
2. Analizar métricas de fairness
3. Proponer mitigaciones

### Ejercicio 3: Limpieza de secrets
1. Escanear notebook con clean-notebook-secrets.py
2. Migrar secrets a variables de entorno
3. Crear .env.example

### Ejercicio 4: Validación de dependencias
1. Simular update de scikit-learn
2. Validar reproducibilidad
3. Verificar performance

### Ejercicio 5: Corrección de vulnerabilidades
1. Crear versión segura de cada archivo
2. Implementar best practices
3. Agregar tests de seguridad

## 📚 Referencias

- **GUIA_EJECUCION_GHAS_DS.md** - Guía completa del taller
- **LIBRERIA_PROMPTS_GHAS.md** - Prompts de Copilot para cada ejercicio
- **EJEMPLOS_GHAS_CODIGO.md** - Ejemplos de código corregido

## 🔐 IMPORTANTE

**NO usar este código en producción.** Todos los archivos contienen vulnerabilidades intencionalmente para propósitos educativos.

Para código seguro, ver:
- `src/secure/` - Ejemplos de código seguro
- **EJEMPLOS_GHAS_CODIGO.md** - Patrones seguros documentados

---

**Mi Banco DS Team | Taller 7 - GHAS**
