package com.mibanco.api;

import java.sql.*;
import java.io.*;
import java.security.*;
import java.util.*;
import javax.servlet.http.*;
import javax.servlet.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * CÓDIGO VULNERABLE PARA PROPÓSITOS EDUCATIVOS
 * Este código contiene 18 vulnerabilidades de seguridad intencionales
 * para ser detectadas por GitHub Advanced Security (CodeQL)
 * 
 * ⚠️ NO USAR EN PRODUCCIÓN
 */

@SpringBootApplication
@RestController
@RequestMapping("/api")
public class VulnerableBankingAPI {

    // VULNERABILIDAD 1: Credenciales hardcodeadas
    private static final String DB_PASSWORD = "Admin123!";
    private static final String API_KEY = "sk-1234567890abcdef";
    private static final String JWT_SECRET = "mySecretKey123";
    
    // VULNERABILIDAD 2: Configuración insegura de base de datos
    private static final String DB_URL = "jdbc:mysql://localhost:3306/banking?useSSL=false";
    private static final String DB_USER = "root";

    public static void main(String[] args) {
        SpringApplication.run(VulnerableBankingAPI.class, args);
    }

    /**
     * VULNERABILIDAD 3: SQL Injection
     * No usa PreparedStatement, concatena input del usuario directamente
     */
    @GetMapping("/account/{userId}")
    public String getAccount(@PathVariable String userId) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        
        // SQL Injection vulnerable
        String query = "SELECT * FROM accounts WHERE user_id = '" + userId + "'";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        
        StringBuilder result = new StringBuilder();
        while (rs.next()) {
            result.append(rs.getString("account_number"));
            result.append(": $").append(rs.getDouble("balance"));
        }
        
        return result.toString();
    }

    /**
     * VULNERABILIDAD 4: SQL Injection en login
     * VULNERABILIDAD 5: No valida credenciales correctamente
     */
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        
        // SQL Injection vulnerable - permite bypass con: admin' OR '1'='1
        String query = "SELECT * FROM users WHERE username = '" + username + 
                      "' AND password = '" + password + "'";
        
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        
        if (rs.next()) {
            return "Login successful. Token: " + generateToken(username);
        }
        return "Login failed";
    }

    /**
     * VULNERABILIDAD 6: Generación de token insegura
     * Usa algoritmo débil y semilla predecible
     */
    private String generateToken(String username) {
        Random random = new Random(12345); // Semilla hardcodeada
        return username + "_" + random.nextInt();
    }

    /**
     * VULNERABILIDAD 7: Command Injection
     * Ejecuta comandos del sistema con input del usuario sin validación
     */
    @GetMapping("/export/{filename}")
    public String exportData(@PathVariable String filename) throws IOException {
        // Command Injection vulnerable
        String command = "tar -czf /exports/" + filename + ".tar.gz /data";
        Process process = Runtime.getRuntime().exec(command);
        
        return "Export started for: " + filename;
    }

    /**
     * VULNERABILIDAD 8: Path Traversal
     * Permite acceder a archivos fuera del directorio permitido
     */
    @GetMapping("/download/{filename}")
    public void downloadFile(@PathVariable String filename, HttpServletResponse response) 
            throws IOException {
        // Path Traversal vulnerable - puede usar: ../../etc/passwd
        File file = new File("/app/documents/" + filename);
        
        FileInputStream fis = new FileInputStream(file);
        OutputStream os = response.getOutputStream();
        
        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = fis.read(buffer)) != -1) {
            os.write(buffer, 0, bytesRead);
        }
        
        fis.close();
        os.close();
    }

    /**
     * VULNERABILIDAD 9: Deserialization insegura
     * Acepta objetos serializados sin validación
     */
    @PostMapping("/session/restore")
    public String restoreSession(@RequestBody byte[] sessionData) 
            throws IOException, ClassNotFoundException {
        // Deserialization vulnerable
        ByteArrayInputStream bis = new ByteArrayInputStream(sessionData);
        ObjectInputStream ois = new ObjectInputStream(bis);
        Object session = ois.readObject(); // Puede ejecutar código malicioso
        
        return "Session restored: " + session.toString();
    }

    /**
     * VULNERABILIDAD 10: XSS (Cross-Site Scripting)
     * No sanitiza output que se renderiza en HTML
     */
    @GetMapping("/profile/{username}")
    public String getProfile(@PathVariable String username) {
        // XSS vulnerable - puede inyectar: <script>alert('XSS')</script>
        return "<html><body><h1>Profile: " + username + "</h1></body></html>";
    }

    /**
     * VULNERABILIDAD 11: Información sensible en logs
     * Loguea información confidencial
     */
    @PostMapping("/transfer")
    public String transfer(@RequestParam String fromAccount, 
                          @RequestParam String toAccount,
                          @RequestParam double amount,
                          @RequestParam String pin) throws SQLException {
        
        // VULNERABILIDAD: Loguea información sensible
        System.out.println("Transfer from: " + fromAccount + 
                          " to: " + toAccount + 
                          " amount: " + amount + 
                          " PIN: " + pin); // ⚠️ PIN en logs
        
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        
        // VULNERABILIDAD 12: No usa transacciones
        String debit = "UPDATE accounts SET balance = balance - " + amount + 
                      " WHERE account_number = '" + fromAccount + "'";
        String credit = "UPDATE accounts SET balance = balance + " + amount + 
                       " WHERE account_number = '" + toAccount + "'";
        
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(debit);
        // Si falla aquí, el dinero se pierde
        stmt.executeUpdate(credit);
        
        return "Transfer completed";
    }

    /**
     * VULNERABILIDAD 13: Race condition
     * No sincroniza acceso a balance
     */
    @PostMapping("/withdraw")
    public String withdraw(@RequestParam String accountNumber, @RequestParam double amount) 
            throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        
        // Lee balance
        String query = "SELECT balance FROM accounts WHERE account_number = '" + accountNumber + "'";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        
        if (rs.next()) {
            double balance = rs.getDouble("balance");
            
            // VULNERABILIDAD: Race condition - dos threads pueden pasar la validación
            if (balance >= amount) {
                // Actualiza balance (sin lock)
                String update = "UPDATE accounts SET balance = balance - " + amount + 
                               " WHERE account_number = '" + accountNumber + "'";
                stmt.executeUpdate(update);
                return "Withdrawal successful";
            }
        }
        
        return "Insufficient funds";
    }

    /**
     * VULNERABILIDAD 14: Weak cryptography
     * Usa MD5 para hashear passwords (inseguro)
     */
    @PostMapping("/register")
    public String register(@RequestParam String username, @RequestParam String password) 
            throws Exception {
        // VULNERABILIDAD: MD5 es débil y no usa salt
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hash = md.digest(password.getBytes());
        
        String hashedPassword = Base64.getEncoder().encodeToString(hash);
        
        Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        String query = "INSERT INTO users (username, password) VALUES ('" + 
                      username + "', '" + hashedPassword + "')";
        
        Statement stmt = conn.createStatement();
        stmt.executeUpdate(query);
        
        return "User registered";
    }

    /**
     * VULNERABILIDAD 15: LDAP Injection
     * Construye query LDAP con input del usuario sin validación
     */
    @GetMapping("/ldap/search/{username}")
    public String ldapSearch(@PathVariable String username) {
        // LDAP Injection vulnerable
        String filter = "(uid=" + username + ")";
        
        // Simula búsqueda LDAP
        return "LDAP Filter: " + filter;
    }

    /**
     * VULNERABILIDAD 16: XML External Entity (XXE)
     * Parsea XML sin deshabilitar entidades externas
     */
    @PostMapping("/xml/process")
    public String processXml(@RequestBody String xmlData) throws Exception {
        // XXE vulnerable
        javax.xml.parsers.DocumentBuilderFactory dbf = 
            javax.xml.parsers.DocumentBuilderFactory.newInstance();
        // No deshabilita entidades externas
        javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();
        
        ByteArrayInputStream bis = new ByteArrayInputStream(xmlData.getBytes());
        org.w3c.dom.Document doc = db.parse(bis);
        
        return "XML processed";
    }

    /**
     * VULNERABILIDAD 17: Server-Side Request Forgery (SSRF)
     * Hace requests a URLs proporcionadas por el usuario
     */
    @GetMapping("/fetch")
    public String fetchUrl(@RequestParam String url) throws IOException {
        // SSRF vulnerable - puede acceder a: http://localhost:8080/admin
        java.net.URL fetchUrl = new java.net.URL(url);
        java.io.BufferedReader reader = new java.io.BufferedReader(
            new java.io.InputStreamReader(fetchUrl.openStream())
        );
        
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line);
        }
        reader.close();
        
        return content.toString();
    }

    /**
     * VULNERABILIDAD 18: Información sensible expuesta
     * Endpoint de debug que expone configuración
     */
    @GetMapping("/debug/config")
    public Map<String, String> getConfig() {
        Map<String, String> config = new HashMap<>();
        
        // Expone información sensible
        config.put("db_password", DB_PASSWORD);
        config.put("api_key", API_KEY);
        config.put("jwt_secret", JWT_SECRET);
        config.put("db_url", DB_URL);
        
        return config;
    }

    /**
     * VULNERABILIDAD ADICIONAL: No valida tamaño de input
     * Vulnerable a DoS por consumo de memoria
     */
    @PostMapping("/process/large")
    public String processLargeData(@RequestBody String data) {
        // No valida tamaño - puede causar OutOfMemoryError
        byte[] processedData = new byte[data.length() * 1000];
        return "Processed " + processedData.length + " bytes";
    }
}
