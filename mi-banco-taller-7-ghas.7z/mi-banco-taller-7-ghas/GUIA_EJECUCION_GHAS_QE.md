# 🔐 Guía de Ejecución Práctica - Taller 7: GitHub Advanced Security para QE

**Facilitador:** GitHub Copilot  
**Objetivo:** Implementar seguridad en aplicaciones bancarias usando GHAS para equipos de QA  
**Duración:** 2 horas (120 minutos)  
**Tecnologías:** GitHub Advanced Security, CodeQL, Dependabot, Copilot Autofix  

**🔹 IMPORTANTE:** Este taller utiliza **GitHub Advanced Security (GHAS) en la nube**. Todo el análisis se ejecuta automáticamente en GitHub Actions y los resultados se visualizan en el Security tab de GitHub. **No requiere instalación local de CodeQL CLI**.

**Requisitos Previos:**
- ✅ **Cuenta GitHub con GHAS habilitado** (OBLIGATORIO)
- ✅ VS Code con extensión Copilot Chat
- ✅ Python 3.8+ instalado
- ✅ Git configurado
- ✅ Conocimientos básicos de testing QA
- ✅ Repositorio `mi-banco-taller-7-ghas` clonado y pusheado a GitHub
- ✅ Familiaridad con Postman y APIs REST

💡 **TIP:** Abre `LIBRERIA_PROMPTS_GHAS.md` en paralelo para consultar prompts mientras trabajas.

---

## ⚡ QUICKSTART (Primeros 5 minutos)

### Paso 1: Prepara el entorno

```powershell
# En VS Code
code .

# Abre Copilot Chat
Ctrl + Shift + I

# Autentica tu cuenta GitHub
Ctrl + Shift + P → "Copilot: Sign In"
```

### Paso 2: Verifica archivos existentes
- **src/vulnerable/** - Aplicaciones con vulnerabilidades intencionales ⚠️
- **src/secure/** - Aplicaciones corregidas ✅
- **labs/** - Laboratorios prácticos
- **tests/** - Tests de seguridad automatizados

### Paso 3: Estructura del taller

| Módulo | Tema | Duración | Enfoque QE |
|--------|------|----------|------------|
| 1 | Fundamentos GHAS | 15 min | Entender herramientas de seguridad |
| 2 | Code Scanning con CodeQL | 25 min | Detectar vulnerabilidades en código |
| 3 | Dependency Review | 20 min | Validar dependencias en PR |
| 4 | Quality Gates de Seguridad | 25 min | Automatizar gates de seguridad |
| 5 | Security Testing Automation | 25 min | Integrar seguridad en tests |
| 6 | Reportes de Seguridad | 10 min | Comunicar resultados a stakeholders |

---

## 📚 FLUJO POR MÓDULO

### MÓDULO 1: Fundamentos GitHub Advanced Security (15 minutos)

#### Actividad 1A: Entender GHAS desde perspectiva QE (8 min)

**PASO 1:** Abre Copilot Chat (`Ctrl + Shift + I`)

**PASO 2:** Copia este prompt PACES:

```
PROPÓSITO: Explicar GitHub Advanced Security para QE bancario
AUDIENCIA: QE con experiencia en testing funcional/API que necesita agregar seguridad
CONTEXTO: Proyecto Mi Banco, necesitamos validar seguridad además de funcionalidad
EJEMPLOS: Test funcional → Test funcional + seguridad, Manual QA → Automated Security QA
SCOPE: Conceptos fundamentales GHAS, rol del QE en seguridad, máx 4 párrafos

---

Explica GitHub Advanced Security para un QE:

1. ¿Qué es GHAS y por qué importa en QA bancaria?
2. Componentes clave para QE:
   - Code Scanning (encontrar bugs de seguridad)
   - Dependency Review (validar librerías)
   - Secret Scanning (evitar exponer credenciales)
   - Security Overview (métricas de seguridad)
3. ¿Cómo se integra en el proceso de QA?
4. Diferencia entre bug funcional vs vulnerabilidad de seguridad

Usa analogías del testing tradicional.
```

**PASO 3:** Lee la explicación y documenta los conceptos clave

**PASO 4:** Pregunta a Copilot sobre el rol del QE en seguridad:

```
PROPÓSITO: Definir responsabilidades de QE en seguridad
AUDIENCIA: QE tradicional ampliando scope
CONTEXTO: Equipo bancario con regulación SBS
EJEMPLOS: Validar que login funcione → Validar que login sea seguro contra SQL injection
SCOPE: 5 responsabilidades concretas de QE en seguridad

---

Lista las 5 responsabilidades principales de un QE en seguridad:

Para cada una incluye:
- Descripción breve
- Ejemplo práctico en banking
- Herramienta GHAS que ayuda
- Impacto si no se hace

Formato tabla Markdown.
```

**VALIDACIÓN:**
- [ ] Conceptos GHAS comprendidos
- [ ] 5 responsabilidades documentadas
- [ ] Diferencia entre bug funcional y vulnerabilidad clara

**TIEMPO:** 8 minutos

---

#### Actividad 1B: Explorar el proyecto vulnerable (7 min)

**PASO 1:** Abre el archivo `src/vulnerable/vulnerable_app.py`

**PASO 2:** En Copilot Chat, analiza el código:

```
PROPÓSITO: Identificar vulnerabilidades en código Python
AUDIENCIA: QE aprendiendo a leer código con ojo de seguridad
CONTEXTO: Aplicación bancaria con vulnerabilidades intencionales
EJEMPLOS: Ver código → detectar SQL injection, XSS, command injection
SCOPE: Listar todas las vulnerabilidades con explicación para QE

---

Analiza el archivo src/vulnerable/vulnerable_app.py:

1. Lista todas las vulnerabilidades encontradas
2. Para cada una explica:
   - ¿Qué es? (en términos simples)
   - ¿Por qué es peligrosa en un banco?
   - ¿Cómo la explotaría un atacante?
   - ¿Cómo debería corregirse?
3. Clasificación: CRÍTICA, ALTA, MEDIA
4. Prioridad de remediación

Enfócate en impacto de negocio, no solo técnico.
```

**PASO 3:** Compara con `src/secure/secure_app.py` para ver las correcciones

**VALIDACIÓN:**
- [ ] Vulnerabilidades identificadas (mínimo 5)
- [ ] Impacto de negocio entendido
- [ ] Diferencias entre código vulnerable y seguro claras

**TIEMPO:** 7 minutos

---

### MÓDULO 2: Code Scanning con CodeQL (25 minutos)

> **📌 NOTA:** Este módulo usa **CodeQL en GitHub Actions** (en la nube). Los análisis se ejecutan automáticamente en cada push/PR y los resultados aparecen en `GitHub → Security → Code scanning alerts`. No necesitas instalar nada localmente.

#### Actividad 2A: Configurar CodeQL (10 min)

**PASO 1:** En Copilot Chat, solicita ayuda para configurar CodeQL:

```
PROPÓSITO: Configurar CodeQL en repositorio para análisis automático
AUDIENCIA: QE configurando seguridad en CI/CD
CONTEXTO: Proyecto Python, necesito detectar vulnerabilidades en cada PR
EJEMPLOS: Push código → CodeQL analiza → Alertas en PR
SCOPE: Workflow YAML funcional para Python

---

Crea workflow de CodeQL para Python:

REQUISITOS:
1️⃣ Triggers
   - push a main/develop
   - pull_request a main
   - schedule: análisis diario a las 2 AM

2️⃣ Lenguajes
   - Python

3️⃣ Queries
   - security-extended (incluye OWASP Top 10)
   - Queries custom si detectas patrones bancarios

4️⃣ Configuración
   - Subir resultados a GitHub Security
   - Fallar el build si hay CRITICAL

5️⃣ Comentarios en español

ENTREGA: Archivo .github/workflows/codeql-analysis.yml
```

**Referencias:**
- Lab: `labs/lab-1-codeql/README.md`
- Código vulnerable: `src/vulnerable/vulnerable_app.py`

**PASO 2:** Crea el archivo en `.github/workflows/codeql-analysis.yml`

**PASO 3:** Haz commit y push para activar CodeQL en GitHub

```powershell
git add .github/workflows/codeql-analysis.yml
git commit -m "feat: Agregar CodeQL analysis para Python"
git push origin main
```

**PASO 4:** Verifica ejecución en GitHub:

1. Ve a tu repositorio en GitHub.com
2. Click en tab **"Actions"**
3. Verifica que el workflow "CodeQL Analysis" se está ejecutando
4. Espera 3-5 minutos a que termine
5. Ve a tab **"Security" → "Code scanning"**
6. Deberías ver alertas detectadas en el código vulnerable

**VALIDACIÓN:**
- [ ] Workflow creado y ejecutado **en GitHub Actions**
- [ ] CodeQL ejecutado exitosamente
- [ ] Alertas visibles en **GitHub Security tab**
- [ ] Puedes ver detalles de cada alerta (severidad, ubicación, CWE)

**TIEMPO:** 10 minutos

---

#### Actividad 2B: Analizar Alertas de CodeQL (15 min)

> **📌 WORKFLOW:** Las alertas se analizan directamente en **GitHub.com**. Desde ahí puedes ver detalles, usar Copilot Autofix, y crear test cases.

**PASO 1:** Navega a **GitHub.com → Tu Repositorio → Security → Code scanning alerts**

**PASO 2:** Selecciona una alerta y revisa:
- 📍 Ubicación exacta del código vulnerable
- 📊 Severidad y CWE
- 📝 Explicación de CodeQL
- 💡 Botón "Generate fix with Copilot" (opcional)

**PASO 3:** Para entender la alerta desde perspectiva QE, usa Copilot Chat en VS Code:

```
PROPÓSITO: Entender alertas de CodeQL como QE
AUDIENCIA: QE analizando alertas de seguridad por primera vez
CONTEXTO: Alerta de CodeQL en Python bancario
EJEMPLOS: Alerta técnica → impacto funcional
SCOPE: Explicación simple + test case para validar fix

---

Explica esta alerta de CodeQL:

[PEGA LA ALERTA AQUÍ]

1. ¿Qué significa en términos simples?
2. ¿Cómo impacta la funcionalidad del banco?
3. ¿Qué escenario de prueba expondría esta vulnerabilidad?
4. ¿Cómo validar que el fix funciona?
5. Test case en formato Gherkin

Incluye ejemplo de request malicioso.
```

**PASO 3:** Para cada alerta, crea un test case

**PASO 4:** Documenta en `reports/codeql-analysis-qe.md`:

```markdown
# Análisis CodeQL - Perspectiva QE

## Alerta 1: [NOMBRE]
- **Severidad:** CRÍTICA
- **CWE:** CWE-89 (SQL Injection)
- **Línea:** 45
- **Impacto:** Exposición de datos de clientes
- **Test Case:**
  ```gherkin
  Scenario: SQL Injection en login
    Given el endpoint /login
    When envío payload malicioso en username: "admin' OR '1'='1"
    Then debería rechazar el request
    And devolver error 400
    And NO exponer datos de usuarios
  ```
```

**VALIDACIÓN:**
- [ ] Todas las alertas analizadas
- [ ] Test cases creados para cada una
- [ ] Impacto de negocio documentado

**TIEMPO:** 15 minutos

---

### MÓDULO 3: Dependency Review y Dependabot (20 minutos)

📌 **NOTA:** Dependabot se configura y ejecuta en GitHub (en la nube). Las alertas y PRs automáticos se gestionan desde la interfaz web de GitHub.

#### Actividad 3A: Configurar Dependabot (10 min)

**PASO 1:** En Copilot Chat, solicita configuración:

```
PROPÓSITO: Configurar Dependabot para monitoreo de dependencias
AUDIENCIA: QE validando seguridad de librerías
CONTEXTO: Proyecto Python bancario, requirements.txt con dependencias
EJEMPLOS: Dependencia vulnerable → Alerta → PR automático
SCOPE: Archivo dependabot.yml funcional

---

Crea configuración de Dependabot:

REQUISITOS:
1️⃣ Ecosistema: pip (Python)
2️⃣ Directorio: / (raíz)
3️⃣ Schedule: weekly
4️⃣ Revisores automáticos: @mi-banco-qe-team
5️⃣ Labels: dependencies, security
6️⃣ Límite PRs abiertos: 5
7️⃣ Prefijo commits: "chore(deps):"

ENTREGA: .github/dependabot.yml
```

**PASO 2:** Crea el archivo `.github/dependabot.yml`

**PASO 3:** Habilita Dependabot en GitHub Settings

1. Ve a **Settings** → **Code security and analysis**
2. Habilita **Dependabot alerts** (si no está activo)
3. Habilita **Dependabot security updates**

**PASO 4:** Valida que Dependabot esté activo en GitHub

1. Ve a la pestaña **Security** de tu repositorio
2. Haz clic en **Dependabot** en el menú lateral
3. Verifica que veas alertas de dependencias vulnerables (pueden tardar 1-2 minutos)
4. Revisa la pestaña **Pull requests** - Dependabot crea PRs automáticos para actualizar dependencias vulnerables

**VALIDACIÓN:**
- [ ] Dependabot configurado en `.github/dependabot.yml`
- [ ] Dependabot habilitado en GitHub Settings
- [ ] Alertas visibles en **GitHub → Security → Dependabot**
- [ ] PRs automáticos generados (si hay vulnerabilidades detectadas)

**TIEMPO:** 10 minutos

---

#### Actividad 3B: Crear Quality Gate de Dependencias (10 min)

**PASO 1:** Crea script para validar dependencias en PR

```
PROPÓSITO: Crear script que valide dependencias en PR
AUDIENCIA: QE automatizando validación de seguridad
CONTEXTO: CI/CD bancario, necesito gate que bloquee dependencias vulnerables
EJEMPLOS: PR con dep vulnerable → Gate FAIL → PR bloqueado
SCOPE: Script Python ejecutable en GitHub Actions

---

Crea scripts/validate-dependencies.py:

REQUISITOS:
1️⃣ Leer dependencias de requirements.txt
2️⃣ Consultar GitHub API por vulnerabilidades
3️⃣ Evaluar severidad: CRITICAL, HIGH, MEDIUM, LOW
4️⃣ Gate rules:
   - CRITICAL: 0 permitidas → FAIL
   - HIGH: 0 permitidas → FAIL
   - MEDIUM: max 2 → WARNING
   - LOW: reportar solo
5️⃣ Output JSON con resultados
6️⃣ Exit code: 0=OK, 1=FAIL, 2=WARNING
7️⃣ Comentarios en español

ENTREGA: Script Python completo
```

**Referencias:**
- Prompts: `LIBRERIA_PROMPTS_GHAS.md` → "Quality Gates de Dependencias"

**PASO 2:** Integra en workflow de PR

```yaml
# Agregar a .github/workflows/pr-checks.yml
- name: Validar Dependencias
  run: |
    python scripts/validate-dependencies.py
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

**VALIDACIÓN:**
- [ ] Script creado
- [ ] Integrado en workflow
- [ ] Gate funciona correctamente

**TIEMPO:** 10 minutos

---

### MÓDULO 4: Quality Gates de Seguridad (25 minutos)

📌 **NOTA:** Los quality gates se ejecutan en GitHub Actions (en la nube). Los resultados se visualizan en la pestaña Actions y en los checks de cada PR en GitHub.

#### Actividad 4A: Definir Gates de Seguridad para QE (10 min)

**PASO 1:** En Copilot Chat, define gates específicos:

```
PROPÓSITO: Definir quality gates de seguridad para proyecto bancario
AUDIENCIA: QE Lead estableciendo estándares de seguridad
CONTEXTO: Proyecto Mi Banco, regulación SBS, tolerancia cero a vulnerabilidades críticas
EJEMPLOS: Gate SQL injection, gate de autenticación, gate de encriptación
SCOPE: 8-10 gates específicos con thresholds

---

Define quality gates de seguridad para QE bancario:

ÁREAS A CUBRIR:
1. Vulnerabilidades de código (CodeQL)
2. Dependencias vulnerables
3. Secrets expuestos
4. Compliance (SBS, PCI DSS)
5. Autenticación/Autorización
6. Encriptación de datos
7. Logging y Auditoría
8. APIs REST security

Para cada gate incluir:
- Nombre descriptivo
- Threshold exacto
- ¿Bloquea merge? (Sí/No)
- Test de validación
- Herramienta GHAS que lo valida

Formato tabla Markdown.
```

**PASO 2:** Documenta en `config/security-gates.json`

**PASO 3:** Revisa con el equipo y ajusta thresholds

**VALIDACIÓN:**
- [ ] 8+ gates definidos
- [ ] Thresholds claros
- [ ] Tests de validación especificados

**TIEMPO:** 10 minutos

---

#### Actividad 4B: Implementar Evaluador de Gates (15 min)

**PASO 1:** Crea script evaluador de gates de seguridad:

```
PROPÓSITO: Crear evaluador de security gates para CI/CD
AUDIENCIA: QE automatizando validación de seguridad
CONTEXTO: Gates definidos, necesito script que los evalúe en PR
EJEMPLOS: JSON results → evaluación → PASS/FAIL/WARNING
SCOPE: Script Python con exit codes y reporte

---

Crea scripts/evaluate-security-gates.py:

GATES A EVALUAR:
1️⃣ codeql_critical_vulnerabilities
   - Threshold: 0
   - Bloquea: SÍ
   - Input: GitHub API CodeQL alerts

2️⃣ dependency_critical_vulnerabilities
   - Threshold: 0
   - Bloquea: SÍ
   - Input: Dependabot alerts

3️⃣ secrets_exposed
   - Threshold: 0
   - Bloquea: SÍ
   - Input: Secret scanning alerts

4️⃣ auth_tests_passing
   - Threshold: 100%
   - Bloquea: SÍ
   - Input: Test results

5️⃣ encryption_compliance
   - Threshold: 100%
   - Bloquea: SÍ
   - Input: Compliance checks

6️⃣ audit_logging_enabled
   - Threshold: TRUE
   - Bloquea: NO (warning)
   - Input: Code analysis

REQUISITOS:
- Leer datos de GitHub API
- Evaluar cada gate
- Mostrar ✅/❌/⚠️ en consola
- Generar JSON detallado
- Exit codes: 0=OK, 1=FAIL, 2=WARNING

ENTREGA: Script Python ejecutable
```

**Referencias:**
- Ejemplo: `EJEMPLOS_CICD_AUTOMATION.md` → "EJEMPLO 4: QUALITY GATES EVALUATOR" (adaptar para seguridad)

**PASO 2:** Prueba localmente con mock data

```powershell
# Mock data de prueba
$mockData = @{
    codeql_alerts = @{critical = 0; high = 2}
    dependabot_alerts = @{critical = 0; high = 1}
    secrets_exposed = 0
    auth_tests = @{passed = 50; total = 50}
} | ConvertTo-Json | Out-File reports/security-mock.json

# Ejecutar evaluador
python scripts/evaluate-security-gates.py reports/security-mock.json
```

**VALIDACIÓN:**
- [ ] Script funcional
- [ ] Todos los gates evaluados
- [ ] Reportes generados correctamente

**TIEMPO:** 15 minutos

---

### MÓDULO 5: Security Testing Automation (25 minutos)

📌 **NOTA:** Los security tests se automatizan en GitHub Actions (en la nube). Los resultados se publican como comentarios en PRs y artifacts en GitHub.

#### Actividad 5A: Crear Tests de Seguridad con Postman (15 min)

**PASO 1:** En Copilot Chat, genera tests de seguridad:

```
PROPÓSITO: Crear tests de seguridad para APIs bancarias en Postman
AUDIENCIA: QE creando security test cases
CONTEXTO: APIs REST de Mi Banco, necesito validar OWASP Top 10
EJEMPLOS: Test funcional → Test de SQL injection, XSS, Auth bypass
SCOPE: Colección Postman con 10+ security tests

---

Genera tests de seguridad para Postman collection:

VULNERABILIDADES A TESTEAR:
1. SQL Injection en login
2. XSS en campos de formulario
3. Authentication bypass
4. Authorization flaws (IDOR)
5. Command injection
6. Path traversal
7. CSRF
8. Rate limiting
9. Input validation
10. Error disclosure

Para cada test incluir:
- Request con payload malicioso
- Assertions esperadas
- Test script en JavaScript
- Documentación de qué busca

FORMATO: JSON Postman Collection v2.1
```

**PASO 2:** Importa la colección en Postman

**PASO 3:** Ejecuta los tests contra `src/vulnerable/vulnerable_app.py`

```powershell
# Levantar app vulnerable
cd src/vulnerable
python vulnerable_app.py

# En otra terminal, ejecutar tests de seguridad
newman run collections/security-tests.json `
  --environment environments/testing.json `
  --reporters cli,json `
  --reporter-json-export reports/security-test-results.json
```

**PASO 4:** Documenta vulnerabilidades encontradas

**VALIDACIÓN:**
- [ ] 10+ tests de seguridad creados
- [ ] Vulnerabilidades detectadas
- [ ] Reporte generado

**TIEMPO:** 15 minutos

---

#### Actividad 5B: Automatizar Security Tests en CI/CD (10 min)

**PASO 1:** Crea workflow para security testing:

```
PROPÓSITO: Crear workflow que ejecute security tests en cada PR
AUDIENCIA: QE integrando security testing en CI/CD
CONTEXTO: Colección Postman con security tests, necesito ejecutarla automáticamente
EJEMPLOS: PR abierto → Security tests → Resultados en PR comment
SCOPE: Workflow YAML con Newman + reporting

---

Crea .github/workflows/security-tests.yml:

REQUISITOS:
1️⃣ Trigger: pull_request
2️⃣ Levantar aplicación en localhost
3️⃣ Ejecutar Newman con security-tests collection
4️⃣ Evaluar resultados:
   - 0 vulnerabilidades = ✅ PASS
   - 1+ vulnerabilidades = ❌ FAIL
5️⃣ Comentar en PR con resumen
6️⃣ Upload reporte como artifact

ENTREGA: Workflow completo
```

**PASO 2:** Integra con quality gates

**VALIDACIÓN:**
- [ ] Workflow funcional
- [ ] Tests ejecutados en PR
- [ ] Comentarios automáticos generados

**TIEMPO:** 10 minutos

---

### MÓDULO 6: Reportes de Seguridad (10 minutos)

📌 **NOTA:** Los reportes de seguridad se visualizan en la pestaña **Security** de GitHub. El script generador se ejecuta en GitHub Actions y los reportes se guardan como artifacts.

#### Actividad 6A: Generar Reporte Ejecutivo de Seguridad (10 min)

**PASO 1:** Crea generador de reportes de seguridad:

```
PROPÓSITO: Crear reporte de seguridad para stakeholders no técnicos
AUDIENCIA: QE Manager, Security Officer, CTO
CONTEXTO: Resultados de CodeQL, Dependabot, Security tests
EJEMPLOS: Métricas técnicas → Riesgos de negocio
SCOPE: Script Python que genera Markdown ejecutivo

---

Crea scripts/generate-security-report.py:

SECCIONES:
1️⃣ Resumen Ejecutivo
   - Estado general de seguridad (🟢🟡🔴)
   - Vulnerabilidades críticas
   - Nivel de riesgo: BAJO/MEDIO/ALTO/CRÍTICO
   - Recomendación: Deploy/Hold/Block

2️⃣ Métricas Clave
   | Métrica | Valor | Threshold | Status |
   |---------|-------|-----------|--------|
   | Vulnerabilidades Críticas | 0 | 0 | ✅ |
   | Dependencias Vulnerables | 1 | 0 | ❌ |
   | Secrets Expuestos | 0 | 0 | ✅ |
   | Tests Seguridad Pasados | 48/50 | 100% | ⚠️ |

3️⃣ Top 5 Riesgos
   - Lista priorizada
   - Impacto en negocio
   - Acción recomendada

4️⃣ Compliance Status
   - SBS: ✅/❌
   - PCI DSS: ✅/❌
   - GDPR: ✅/❌

5️⃣ Próximos Pasos
   - Acciones inmediatas
   - Plazo recomendado

FORMATO: Markdown con emojis y tablas
```

**PASO 2:** Ejecuta el generador

```powershell
python scripts/generate-security-report.py `
  --codeql reports/codeql-results.json `
  --dependabot reports/dependabot-alerts.json `
  --security-tests reports/security-test-results.json `
  --output reports/security-executive-report.md
```

**VALIDACIÓN:**
- [ ] Reporte generado
- [ ] Métricas claras
- [ ] Recomendaciones accionables

**TIEMPO:** 10 minutos

---

## 🎯 ENTREGABLES FINALES

Al finalizar el taller, deberías tener:

### Workflows ✅
- [ ] `.github/workflows/codeql-analysis.yml` - CodeQL automático
- [ ] `.github/workflows/security-tests.yml` - Security testing
- [ ] `.github/workflows/pr-checks.yml` - Quality gates en PR

### Scripts 🐍
- [ ] `scripts/validate-dependencies.py` - Validador de dependencias
- [ ] `scripts/evaluate-security-gates.py` - Evaluador de gates
- [ ] `scripts/generate-security-report.py` - Generador de reportes

### Configuración ⚙️
- [ ] `.github/dependabot.yml` - Dependabot configurado
- [ ] `config/security-gates.json` - Gates definidos

### Documentación 📄
- [ ] `reports/codeql-analysis-qe.md` - Análisis de alertas
- [ ] `reports/security-executive-report.md` - Reporte ejecutivo

### Tests 🧪
- [ ] `collections/security-tests.json` - Tests de seguridad Postman
- [ ] Test cases en Gherkin para cada vulnerabilidad

---

## 📊 CHECKLIST DE CALIDAD

### Seguridad Implementada (en GitHub)
- [ ] CodeQL analiza código en cada PR (visible en **GitHub → Security → Code scanning**)
- [ ] Dependabot monitorea vulnerabilidades (visible en **GitHub → Security → Dependabot**)
- [ ] Security tests automatizados en **GitHub Actions**
- [ ] Secrets scanning activo (visible en **GitHub → Security → Secret scanning**)
- [ ] Quality gates bloquean PRs inseguros (visible en checks del PR en GitHub)

### Automatización
- [ ] Análisis automático en push/PR
- [ ] Reportes generados automáticamente
- [ ] Comentarios en PR con resultados
- [ ] Alertas en tiempo real

### Calidad de Tests
- [ ] 10+ security test cases
- [ ] Cobertura de OWASP Top 10
- [ ] Tests ejecutables localmente
- [ ] Tests integrados en CI/CD

### Documentación
- [ ] Todos los gates documentados
- [ ] Test cases documentados
- [ ] Reportes comprensibles para no técnicos
- [ ] Runbooks para remediación

---

## 💡 TIPS PARA QE

### Best Practices de Security Testing

1. **Piensa como un atacante**
   - ¿Qué haría un hacker con este endpoint?
   - ¿Qué pasa si envío datos maliciosos?

2. **No confíes en el frontend**
   - Valida en backend
   - Bypasea el UI y testea APIs directamente

3. **Datos sensibles**
   - Nunca en logs
   - Siempre encriptados
   - Mínimo privilegio

4. **False sense of security**
   - No basta con validar formato
   - Sanitiza y escapa siempre
   - Defiende en profundidad

5. **Mantén actualizado**
   - Dependencias al día
   - CVEs conocidos parcheados
   - Suscríbete a security advisories

### Vulnerabilidades Comunes en Banking

| Vulnerabilidad | Riesgo en Banking | Test QE |
|----------------|-------------------|---------|
| SQL Injection | Exposición de datos de clientes | Payload: `' OR '1'='1` en login |
| XSS | Robo de sesiones | Payload: `<script>alert(1)</script>` |
| IDOR | Acceso a cuentas ajenas | Cambiar `account_id` en URL |
| Auth Bypass | Acceso no autorizado | Request sin token JWT |
| Command Injection | Control del servidor | Payload: `; rm -rf /` |

---

## 🔗 RECURSOS ADICIONALES

### Documentación
- [OWASP Top 10 2024](https://owasp.org/www-project-top-ten/)
- [GitHub Advanced Security Docs](https://docs.github.com/en/code-security)
- [CodeQL Queries](https://codeql.github.com/docs/codeql-language-guides/codeql-for-python/)

### Labs
- `labs/lab-1-codeql/` - Deep dive en CodeQL
- `labs/lab-2-dependabot/` - Gestión de dependencias
- `labs/lab-5-remediation/` - Remediación de vulnerabilidades

### Herramientas
- [Burp Suite Community](https://portswigger.net/burp/communitydownload) - Testing manual
- [OWASP ZAP](https://www.zaproxy.org/) - Security scanner
- [Postman](https://www.postman.com/) - API testing con security

---

## ❓ PREGUNTAS FRECUENTES

**P: ¿Debo ser desarrollador para hacer security testing?**  
R: No. Como QE, enfócate en el impacto funcional y de negocio de las vulnerabilidades.

**P: ¿Cómo priorizo las vulnerabilidades?**  
R: CRITICAL → HIGH (afectan datos/dinero) → MEDIUM → LOW. Usa CVSS score + contexto bancario.

**P: ¿Qué hago si encuentro una vulnerabilidad en producción?**  
R: Reporta inmediatamente al Security Officer, documenta, no la divulgues públicamente.

**P: ¿CodeQL reemplaza el testing manual de seguridad?**  
R: No. CodeQL encuentra bugs comunes, pero necesitas testing manual para lógica de negocio.

**P: ¿Cómo sé si mis security tests son buenos?**  
R: Si detectan las vulnerabilidades conocidas en `src/vulnerable/`, funcionan correctamente.

---

## 🎓 PRÓXIMOS PASOS

Después del taller:

1. **Implementa en tu proyecto real**
   - Aplica los workflows
   - Adapta los gates a tu contexto
   - Entrena a tu equipo

2. **Expande tu conocimiento**
   - Toma curso de OWASP Top 10
   - Aprende más sobre CodeQL queries
   - Practica con CTF challenges

3. **Comparte con el equipo**
   - Presenta findings
   - Crea runbooks
   - Documenta casos de uso

4. **Mejora continua**
   - Revisa métricas mensualmente
   - Ajusta gates según learnings
   - Automatiza más

---

**¡Felicidades! Has completado el Taller 7: GitHub Advanced Security para QE** 🎉

**Mi Banco QE Team | Taller 7 - GHAS**
