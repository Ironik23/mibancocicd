# Tests

Esta carpeta está preparada para contener pruebas automatizadas del proyecto.

## 🧪 Estructura de Testing Recomendada

```
tests/
├── unit/              # Pruebas unitarias
│   ├── test_models.py
│   ├── test_utils.py
│   └── test_security.py
├── integration/       # Pruebas de integración
│   ├── test_api.py
│   └── test_database.py
├── security/          # Pruebas de seguridad
│   ├── test_codeql.py
│   ├── test_secrets.py
│   └── test_vulnerabilities.py
├── ml/                # Pruebas específicas de ML
│   ├── test_bias_detection.py
│   ├── test_model_validation.py
│   └── test_reproducibility.py
├── fixtures/          # Datos de prueba
│   ├── sample_data.json
│   └── mock_models.pkl
└── conftest.py        # Configuración de pytest
```

## 🚀 Ejecutar Tests

### Con pytest

```bash
# Instalar dependencias de testing
pip install pytest pytest-cov pytest-mock

# Ejecutar todos los tests
pytest

# Ejecutar con cobertura
pytest --cov=src --cov-report=html

# Ejecutar tests específicos
pytest tests/unit/test_models.py
pytest tests/security/ -v

# Ejecutar con marcadores
pytest -m "not slow"
pytest -m "security"
```

### Con GitHub Actions

Los tests se ejecutan automáticamente en CI/CD:
- En cada push a `main`
- En cada pull request
- Antes de deployments

## 📋 Ejemplo: Test de Bias Detection

```python
# tests/ml/test_bias_detection.py
import pytest
import pandas as pd
from scripts.detect_model_bias import BiasDetector

@pytest.fixture
def sample_data():
    return pd.DataFrame({
        'age': [25, 35, 45, 55, 65],
        'income': [30000, 50000, 70000, 90000, 110000],
        'prediction': [0, 1, 1, 1, 0],
        'actual': [0, 1, 0, 1, 0],
        'gender': ['M', 'F', 'M', 'F', 'M']
    })

def test_disparate_impact(sample_data):
    detector = BiasDetector(model=None, test_data=sample_data)
    di = detector.calculate_disparate_impact('gender', 'F', 'prediction')
    assert 0.0 <= di <= 2.0, "Disparate Impact debe estar entre 0 y 2"

def test_equal_opportunity(sample_data):
    detector = BiasDetector(model=None, test_data=sample_data)
    eo = detector.calculate_equal_opportunity('gender', 'F', 'prediction', 'actual')
    assert -1.0 <= eo <= 1.0, "Equal Opportunity debe estar entre -1 y 1"
```

## 🔒 Security Testing

```python
# tests/security/test_vulnerabilities.py
import pytest
from src.vulnerable.vulnerable_app import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_sql_injection_detected(client):
    """Verificar que CodeQL detecta SQL injection"""
    # Este test verifica que las vulnerabilidades EXISTEN
    # (para propósitos educativos del taller)
    response = client.post('/predict', json={
        'user_id': "1' OR '1'='1"
    })
    # Esperamos que falle de forma controlada
    assert response.status_code in [400, 500]

def test_hardcoded_secrets_detected():
    """Verificar que Secret Scanning detecta credenciales"""
    import src.vulnerable.vulnerable_app as vuln
    # Verificar que existen (para el taller)
    assert hasattr(vuln, 'DB_PASSWORD')
```

## 🎯 Coverage Goals

- **Unit Tests:** > 80% coverage
- **Integration Tests:** Rutas críticas cubiertas
- **Security Tests:** Todas las vulnerabilidades conocidas validadas
- **ML Tests:** Bias, reproducibilidad, performance

## 🔧 Configuración

### pytest.ini

```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
markers =
    slow: marks tests as slow (deselect with '-m "not slow"')
    security: marks tests as security-related
    ml: marks tests as machine learning-related
    integration: marks tests as integration tests
addopts = 
    --strict-markers
    --tb=short
    --disable-warnings
```

### conftest.py

```python
import pytest
import sys
from pathlib import Path

# Agregar src al path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

@pytest.fixture(scope="session")
def test_data_path():
    return Path(__file__).parent / "fixtures"

@pytest.fixture
def mock_model():
    """Mock de un modelo ML para testing"""
    class MockModel:
        def predict(self, X):
            return [0] * len(X)
    return MockModel()
```

## 📊 CI/CD Integration

Los tests están integrados con GitHub Actions:

```yaml
name: Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.9'
      - run: pip install -r requirements.txt
      - run: pip install pytest pytest-cov
      - run: pytest --cov=src --cov-report=xml
      - uses: codecov/codecov-action@v3
```

---

**Nota:** Esta carpeta está lista para recibir tests. Los tests son fundamentales para validar que las remediaciones de seguridad no rompan funcionalidad.
